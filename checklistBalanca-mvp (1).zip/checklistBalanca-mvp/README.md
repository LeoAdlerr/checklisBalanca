# checklistBalanca
projeto onde o checklist da balança deixará de ser manual e manuscrito para ser web evitando assim arquivos físicos e rasuras


rojeto Checklist Alfandegário UAGA - Backend
Este repositório contém o backend da aplicação de checklist alfandegário, desenvolvido com NestJS (TypeScript) e MySQL. A aplicação é conteinerizada usando Podman para facilitar o desenvolvimento e o deploy.

Sumário
Estrutura do Projeto

Pré-requisitos

Configuração do Banco de Dados (MySQL)

Criação da Rede Podman

Build da Imagem MySQL

Execução do Contêiner MySQL

Configuração do Backend (NestJS)

Build da Imagem NestJS (Desenvolvimento)

Execução do Contêiner NestJS (Desenvolvimento com Hot-Reload)

Desenvolvimento Local (Opcional)

Testando a Aplicação

Variáveis de Ambiente

Resolução de Problemas Comuns

1. Estrutura do Projeto
O projeto está organizado em dois diretórios principais, cada um com seu próprio Containerfile:

checklistBalanca/
├── bdChecklistBalanca/       # Contém o Containerfile para o banco de dados MySQL
│   ├── Containerfile
│   └── init.sql              # Script SQL para criação do esquema e dados iniciais
└── backChecklistBalanca/     # Contém o Containerfile para o backend NestJS
    ├── Containerfile.dev     # Containerfile para ambiente de desenvolvimento
    ├── Containerfile         # Containerfile para ambiente de produção (futuro)
    ├── package.json
    ├── tsconfig.json
    └── src/                  # Código fonte da aplicação NestJS
        ├── main.ts
        ├── app.module.ts
        ├── controllers/
        │   ├── app.controller.ts
        │   └── checklist.controller.ts
        ├── services/
        │   ├── app.service.ts
        │   └── checklist.service.ts
        ├── entities/
        │   └── checklist.entity.ts
        └── checklist/
            └── checklist.module.ts

2. Pré-requisitos
Certifique-se de ter os seguintes softwares instalados em sua máquina:

Podman: Para construir e gerenciar os contêineres.

Node.js e Yarn: Para desenvolvimento local (opcional, mas recomendado) e para que o yarn install funcione dentro do contêiner.

3. Configuração do Banco de Dados (MySQL)
O banco de dados MySQL será executado em um contêiner Podman e será acessível pelo backend NestJS através de uma rede compartilhada.

Criação da Rede Podman
É essencial que ambos os contêineres (MySQL e NestJS) estejam na mesma rede para que possam se comunicar pelo nome do serviço.

podman network create uaga-network

Você pode verificar se a rede foi criada com: podman network ls

Build da Imagem MySQL
Navegue até o diretório bdChecklistBalanca e construa a imagem do MySQL:

cd checklistBalanca/bdChecklistBalanca
podman build -t uagamysql-db-image . -f Containerfile

Execução do Contêiner MySQL
Agora, crie e inicie o contêiner MySQL na rede uaga-network.

# Opcional: Pare e remova o contêiner anterior se ele já existir
podman stop UagaMysql > /dev/null 2>&1
podman rm UagaMysql > /dev/null 2>&1

# Crie e inicie o contêiner MySQL
podman run --name UagaMysql \
  -p 3306:3306 \
  --network uaga-network \
  -e MYSQL_ROOT_PASSWORD=my_secret_password \
  -e MYSQL_DATABASE=UagaBD \
  -d uagamysql-db-image

ATENÇÃO:

Substitua sua_senha_secreta por uma senha forte e segura.

O init.sql dentro da imagem uagamysql-db-image será executado automaticamente na primeira inicialização do contêiner, criando o esquema do banco de dados UagaBD e populando as tabelas de lookup e pontos_verificacao.

Verifique se o contêiner MySQL está rodando com: podman ps

4. Configuração do Backend (NestJS)
O backend NestJS será executado em um contêiner de desenvolvimento, permitindo hot-reloading para um ciclo de desenvolvimento rápido.

Build da Imagem NestJS (Desenvolvimento)
Navegue até o diretório backChecklistBalanca e construa a imagem de desenvolvimento do NestJS:

cd checklistBalanca/backChecklistBalanca
podman build -t uaga-checklist-backend-dev-image . -f Containerfile.dev

Execução do Contêiner NestJS (Desenvolvimento com Hot-Reload)
Crie e inicie o contêiner NestJS na mesma rede uaga-network. Usaremos bind mounts para que as alterações no seu código local sejam refletidas instantaneamente no contêiner.

# Opcional: Pare e remova o contêiner de desenvolvimento anterior se ele já existir
podman stop uaga-checklist-backend-dev-container > /dev/null 2>&1
podman rm uaga-checklist-backend-dev-container > /dev/null 2>&1

# Crie e inicie o contêiner NestJS de desenvolvimento
podman run --name uaga-checklist-backend-dev-container \
  -p 8080:8080 \
  -v "$(cygpath -w "$(pwd)")":/app \
  -v /app/node_modules \
  --network uaga-network \
  -e DB_HOST=UagaMysql \
  -e DB_PORT=3306 \
  -e DB_USER=root \
  -e DB_PASSWORD=my_secret_password \
  -e DB_DATABASE=UagaBD \
  -e PORT=8080 \
  -d uaga-checklist-backend-dev-image \
  yarn start:dev

ATENÇÃO:

Substitua sua_senha_secreta pela mesma senha que você usou para o contêiner MySQL.

O $(cygpath -w "$(pwd)") é crucial para ambientes Windows (Git Bash/MINGW64) para converter o caminho Unix-like para um caminho Windows compreendido pelo Podman.

Verifique se o contêiner NestJS está rodando com: podman ps
O status deve ser Up X minutes (starting) ou Up X minutes.

Desenvolvimento Local (Opcional)
Se preferir desenvolver o backend diretamente na sua máquina (sem contêiner para o NestJS, mas ainda usando o MySQL conteinerizado), siga estes passos:

Crie um arquivo .env na raiz do diretório backChecklistBalanca com as seguintes variáveis:

PORT=8080
DB_HOST=localhost   # Ou o IP do seu Podman MySQL se não estiver na mesma rede Podman
DB_PORT=3306
DB_USER=root
DB_PASSWORD=sua_senha_secreta
DB_DATABASE=UagaBD

Instale as dependências:

cd checklistBalanca/backChecklistBalanca
yarn install

Inicie a aplicação em modo de desenvolvimento:

yarn start:dev

Isso fará com que o NestJS observe as alterações nos arquivos e recarregue a aplicação automaticamente.

5. Testando a Aplicação
Uma vez que o contêiner NestJS esteja rodando (verifique os logs para Nest application is listening on port 8080), você pode testar a aplicação:

Verificar Logs:

podman logs uaga-checklist-backend-dev-container

Procure por Nest application successfully started e Nest application is listening on port 8080.

Acessar o Endpoint Raiz:
Abra seu navegador em http://localhost:8080 ou use curl:

curl http://localhost:8080

Você deve ver: Bem-vindo ao Backend do Checklist Alfandegário UAGA!

Acessar o Endpoint de Checklists:
Abra seu navegador em http://localhost:8080/checklists ou use curl:

curl http://localhost:8080/checklists

Se você já inseriu dados no seu banco de dados MySQL (usando os casos de uso fornecidos anteriormente), você deverá ver um array JSON com os dados dos checklists.

6. Variáveis de Ambiente
As variáveis de ambiente para a conexão com o banco de dados são passadas para o contêiner via a flag -e no comando podman run. No desenvolvimento local, elas são lidas do arquivo .env.

DB_HOST: Host do servidor MySQL (e.g., UagaMysql para comunicação entre contêineres na mesma rede, ou localhost para acesso local).

DB_PORT: Porta do MySQL (padrão 3306).

DB_USER: Usuário do banco de dados (e.g., root).

DB_PASSWORD: Senha do usuário do banco de dados.

DB_DATABASE: Nome do banco de dados (e.g., UagaBD).

PORT: Porta em que a aplicação NestJS irá escutar (8080).

7. Resolução de Problemas Comuns
Error: ... name "..." is already in use: Um contêiner com o mesmo nome já existe. Use podman stop <nome_do_container> e podman rm <nome_do_container> para parar e remover o contêiner antigo antes de tentar rodar um novo.

getaddrinfo ENOTFOUND UagaMysql: O contêiner NestJS não consegue encontrar o contêiner MySQL. Certifique-se de que ambos estão na mesma rede Podman (uaga-network) e que o DB_HOST está configurado com o nome correto do contêiner MySQL (UagaMysql).

Contêiner sai imediatamente após iniciar (podman ps mostra status "Exited"): O comando principal dentro do contêiner falhou. Use podman logs <nome_do_container> para ver os logs e identificar o erro.

Problemas de Conexão com o Banco de Dados:

Verifique se a senha (DB_PASSWORD) está correta.

Verifique se o DB_HOST está correto (nome do contêiner MySQL ou localhost/IP).

Confirme se o contêiner MySQL está realmente rodando (podman ps).

Verifique os logs do contêiner NestJS para mensagens de erro do TypeORM.

Com esta documentação, qualquer usuário deverá ser capaz de configurar e rodar o ambiente de desenvolvimento do seu projeto de backend.