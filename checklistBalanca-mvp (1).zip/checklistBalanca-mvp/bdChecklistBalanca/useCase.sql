-- Início do Caso de Uso 1: Registro de Nova Inspeção Completa e Conforme
-- ==================================================================================================

-- 1. Inserir o registro principal do Checklist
INSERT INTO checklists (
    data_hora_inicio,
    data_hora_termino,
    tipo_inspecao_modalidade_id,
    operacao_id,
    tipo_unidade_id,
    n_lacre_uaga_pos_inspecao,
    n_lacre_uaga_pos_carregamento,
    nome_resp_lacre,
    assinatura_resp_lacre,
    nome_resp_deslacre_pos_carregamento,
    assinatura_resp_deslacre_pos_carregamento,
    n_lacre_armador,
    n_lacre_rfb,
    observacoes_gerais,
    providencias_tomadas,
    nome_resp_inspecao,
    assinatura_resp_inspecao,
    assinatura_motorista
) VALUES (
    '2025-05-30 10:00:00',
    '2025-05-30 10:30:00',
    1, -- Rodoviário (ID 1 do seu SELECT)
    1, -- Verde (ID 1 do seu SELECT)
    1, -- Container (ID 1 do seu SELECT)
    'UAGA12345',
    'UAGA67890',
    'Carlos Santos',
    'url_assinatura_carlos_lacre.png',
    'Ana Souza',
    'url_assinatura_ana_deslacre.png',
    'ARMADOR001',
    'RFB123',
    'Inspeção padrão sem intercorrências.',
    'N/A',
    'João Silva',
    'url_assinatura_joao_inspetor.png',
    'url_assinatura_motorista_x.png'
);
SET @last_checklist_id = LAST_INSERT_ID();

-- 2. Inserir todos os 18 Pontos de Verificação como "Conforme"
INSERT INTO checklist_itens (checklist_id, ponto_verificacao_id, status_conformidade_id, observacoes)
SELECT @last_checklist_id, id, 1, NULL -- Conforme (ID 1 do seu SELECT)
FROM pontos_verificacao;

-- 3. Inserir as informações de Lacres de Saída
INSERT INTO lacres_saida (
    checklist_id,
    lacre_rfb_id,
    lacre_armador_pos_unitizacao_id,
    fita_lacre_uaga_compartimento_id,
    nome_resp_verificacao,
    assinatura_resp_verificacao,
    data_saida
) VALUES (
    @last_checklist_id,
    2, -- OK (ID 2 do seu SELECT)
    2, -- OK (ID 2 do seu SELECT)
    1, -- N/A (ID 1 do seu SELECT)
    'Mariana Lima',
    'url_assinatura_mariana.png',
    '2025-05-30'
);

-- ==================================================================================================
-- Fim do Caso de Uso 1


-- Início do Caso de Uso 2: Registro de Inspeção com Divergências e Evidências
-- ==================================================================================================

-- 1. Inserir um novo Checklist com divergências
INSERT INTO checklists (
    data_hora_inicio,
    data_hora_termino,
    tipo_inspecao_modalidade_id,
    operacao_id,
    tipo_unidade_id,
    n_lacre_uaga_pos_inspecao,
    n_lacre_uaga_pos_carregamento,
    nome_resp_lacre,
    assinatura_resp_lacre,
    nome_resp_deslacre_pos_carregamento,
    assinatura_resp_deslacre_pos_carregamento,
    n_lacre_armador,
    n_lacre_rfb,
    observacoes_gerais,
    providencias_tomadas,
    nome_resp_inspecao,
    assinatura_resp_inspecao,
    assinatura_motorista
) VALUES (
    '2025-05-30 11:00:00',
    '2025-05-30 11:45:00',
    2, -- tipo_inspecao_modalidade_id: Aéreo
    2, -- operacao_id: Laranja
    2, -- tipo_unidade_id: Baú
    'UAGA98765',
    'UAGA54321',
    'Pedro Costa',
    'url_assinatura_pedro_lacre.png',
    'Carla Dias',
    'url_assinatura_carla_deslacre.png',
    'ARMADOR002',
    'RFB456',
    'Divergências encontradas no piso e pneus. Providências tomadas.',
    'Pneus substituídos, piso reparado.',
    'Fernanda Oliveira',
    'url_assinatura_fernanda_inspetor.png',
    'url_assinatura_motorista_y.png'
);
SET @last_checklist_id_div = LAST_INSERT_ID();

-- 2. Inserir os itens de verificação (todos como "Conforme" inicialmente)
INSERT INTO checklist_itens (checklist_id, ponto_verificacao_id, status_conformidade_id, observacoes)
SELECT @last_checklist_id_div, pv.id, 1, NULL -- status_conformidade_id: Conforme
FROM pontos_verificacao pv;

-- 3. Atualizar pontos específicos para 'Não Conforme' e adicionar observações
-- ATUALIZAÇÃO PARA PNEUS (ID 11)
UPDATE checklist_itens
SET
    status_conformidade_id = 2, -- status_conformidade_id: Não Conforme
    observacoes = 'Pneus desgastados, requerem troca imediata.'
WHERE
    checklist_id = @last_checklist_id_div AND
    ponto_verificacao_id = 11; -- ID DIRETO para Pneus

-- ATUALIZAÇÃO PARA PISO DO CAMINHÃO (ID 12)
UPDATE checklist_itens
SET
    status_conformidade_id = 2, -- status_conformidade_id: Não Conforme
    observacoes = 'Rachadura visível no piso do baú.'
WHERE
    checklist_id = @last_checklist_id_div AND
    ponto_verificacao_id = 12; -- ID DIRETO para Piso do Caminhão

-- 4. Adicionar Evidências para os Pontos Divergentes
SET @pneus_item_id = (
    SELECT id FROM checklist_itens
    WHERE checklist_id = @last_checklist_id_div AND
    ponto_verificacao_id = 11 -- ID DIRETO para Pneus
);
INSERT INTO evidencias (checklist_item_id, url_imagem, descricao)
VALUES (@pneus_item_id, 'url_foto_pneu_desgastado.jpg', 'Foto dos pneus dianteiros com desgaste excessivo.');

SET @piso_item_id = (
    SELECT id FROM checklist_itens
    WHERE checklist_id = @last_checklist_id_div AND
    ponto_verificacao_id = 12 -- ID DIRETO para Piso do Caminhão
);
INSERT INTO evidencias (checklist_item_id, url_imagem, descricao)
VALUES (@piso_item_id, 'url_foto_piso_rachado.jpg', 'Foto da rachadura no piso do baú, lado esquerdo.');

-- 5. Inserir as informações de Lacres de Saída (com divergência)
INSERT INTO lacres_saida (
    checklist_id,
    lacre_rfb_id,
    lacre_armador_pos_unitizacao_id,
    fita_lacre_uaga_compartimento_id,
    nome_resp_verificacao,
    assinatura_resp_verificacao,
    data_saida
) VALUES (
    @last_checklist_id_div,
    2, -- lacre_rfb_id: OK
    3, -- lacre_armador_pos_unitizacao_id: Não OK
    1, -- fita_lacre_uaga_compartimento_id: N/A
    'Gustavo Rocha',
    'url_assinatura_gustavo.png',
    '2025-05-30'
);

-- ==================================================================================================
-- Fim do Caso de Uso 2

-- Início do Caso de Uso 3: Recuperação e Visualização de um Checklist Completo
-- ==================================================================================================

SELECT
    c.id AS checklist_id,
    c.data_hora_inicio,
    c.data_hora_termino,
    tim.descricao AS tipo_inspecao_modalidade, -- Faz JOIN para pegar a descrição legível
    ol.descricao AS operacao,                 -- Faz JOIN para pegar a descrição legível
    tul.descricao AS tipo_unidade,            -- Faz JOIN para pegar a descrição legível
    c.n_lacre_uaga_pos_inspecao,
    c.n_lacre_uaga_pos_carregamento,
    c.nome_resp_lacre,
    c.assinatura_resp_lacre,
    c.nome_resp_deslacre_pos_carregamento,
    c.assinatura_resp_deslacre_pos_carregamento,
    c.n_lacre_armador,
    c.n_lacre_rfb,
    c.observacoes_gerais,
    c.providencias_tomadas,
    c.nome_resp_inspecao,
    c.assinatura_resp_inspecao,
    c.assinatura_motorista,
    pv.descricao AS ponto_verificacao_descricao,
    scl.descricao AS status_conformidade,     -- Faz JOIN para pegar a descrição legível
    ci.observacoes AS item_observacoes,
    -- Concatena todas as evidências para um item de checklist, se houver
    GROUP_CONCAT(DISTINCT CONCAT(e.url_imagem, ' (', e.descricao, ')') SEPARATOR '; ') AS evidencias_associadas,
    lrl.descricao AS lacre_saida_rfb,                 -- Faz JOIN para pegar a descrição legível
    laul.descricao AS lacre_saida_armador,            -- Faz JOIN para pegar a descrição legível
    flul.descricao AS lacre_saida_fita_uaga,          -- Faz JOIN para pegar a descrição legível
    ls.nome_resp_verificacao AS lacre_saida_resp_verificacao,
    ls.assinatura_resp_verificacao AS lacre_saida_assinatura_resp_verificacao,
    ls.data_saida AS lacre_saida_data_saida
FROM
    checklists c
JOIN
    tipo_inspecao_modalidade_lookup tim ON c.tipo_inspecao_modalidade_id = tim.id
JOIN
    operacao_lookup ol ON c.operacao_id = ol.id
JOIN
    tipo_unidade_lookup tul ON c.tipo_unidade_id = tul.id
LEFT JOIN
    checklist_itens ci ON c.id = ci.checklist_id
LEFT JOIN
    pontos_verificacao pv ON ci.ponto_verificacao_id = pv.id
LEFT JOIN
    status_conformidade_lookup scl ON ci.status_conformidade_id = scl.id
LEFT JOIN
    evidencias e ON ci.id = e.checklist_item_id
LEFT JOIN
    lacres_saida ls ON c.id = ls.checklist_id
LEFT JOIN
    lacre_rfb_lookup lrl ON ls.lacre_rfb_id = lrl.id
LEFT JOIN
    lacre_armador_pos_unitizacao_lookup laul ON ls.lacre_armador_pos_unitizacao_id = laul.id
LEFT JOIN
    fita_lacre_uaga_compartimento_lookup flul ON ls.fita_lacre_uaga_compartimento_id = flul.id
WHERE
    c.id = (SELECT id FROM checklists ORDER BY id DESC LIMIT 1) -- Consulta o último checklist inserido (do Caso de Uso 2 ou 4)
    -- OU, para um ID específico, use: c.id = [ID_DO_CHECKLIST_AQUI]
    -- Exemplo: c.id = 1;
GROUP BY
    c.id, ci.id, pv.id, ls.id -- Agrupa para que GROUP_CONCAT funcione corretamente
ORDER BY
    c.id DESC, pv.id ASC; -- Ordena para facilitar a leitura
-- ==================================================================================================
-- Fim do Caso de Uso 3




-----
SELECT * FROM  operacao_lookup;
-- id  descricao
-- 2	Laranja
-- 1	Verde
-- 3	Vermelho

select * from status_conformidade_lookup;

-- id  descricao
-- 1	Conforme
-- 3	N/A
-- 2	NÃ£o Conforme
		
Select * from tipo_inspecao_modalidade_lookup;

-- id  descricao
-- 2	AÃ©reo
-- 3	MarÃ­timo
-- 1 	RodoviÃ¡rio

SELECT * FROM tipo_unidade_lookup;

-- id  descricao
-- 2	BaÃº
-- 1	Container

select * from fita_lacre_uaga_compartimento_lookup;

-- id  descricao
-- 1	N/A
-- 3	NÃ£o OK
-- 2	OK
	
SELECT * FROM lacre_armador_pos_unitizacao_lookup;	

-- id  descricao
-- 1	N/A
-- 3	NÃ£o OK
-- 2	OK

SELECT * FROM lacre_rfb_lookup;	

-- id  descricao
-- 1	N/A
-- 3	NÃ£o OK
-- 2	OK
	
	