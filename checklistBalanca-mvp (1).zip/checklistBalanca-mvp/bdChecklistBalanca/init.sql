-- Desativa a checagem de chaves estrangeiras temporariamente
SET FOREIGN_KEY_CHECKS = 0;

-- Drop Tables em ordem reversa de dependência (Crucial para recriar o esquema do zero)
DROP TABLE IF EXISTS lacres_saida;
DROP TABLE IF EXISTS evidencias;
DROP TABLE IF EXISTS checklist_itens;
DROP TABLE IF EXISTS checklists;
DROP TABLE IF EXISTS pontos_verificacao;

-- DROP das Novas Tabelas de Tradução (Adicionadas para garantir um clean start)
DROP TABLE IF EXISTS tipo_inspecao_modalidade_lookup;
DROP TABLE IF EXISTS operacao_lookup;
DROP TABLE IF EXISTS tipo_unidade_lookup;
DROP TABLE IF EXISTS status_conformidade_lookup;
DROP TABLE IF EXISTS lacre_rfb_lookup;
DROP TABLE IF EXISTS lacre_armador_pos_unitizacao_lookup;
DROP TABLE IF EXISTS fita_lacre_uaga_compartimento_lookup;


-- =======================================================
-- Tabelas de Tradução (Lookup Tables)
-- =======================================================

CREATE TABLE tipo_inspecao_modalidade_lookup (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE operacao_lookup (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE tipo_unidade_lookup (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE status_conformidade_lookup (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE lacre_rfb_lookup (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE lacre_armador_pos_unitizacao_lookup (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE fita_lacre_uaga_compartimento_lookup (
    id INT PRIMARY KEY AUTO_INCREMENT,
    descricao VARCHAR(50) NOT NULL UNIQUE
);

-- =======================================================
-- Tabelas Principais (Usando Chaves Estrangeiras para Lookups)
-- =======================================================

-- Tabela principal para os Checklists
CREATE TABLE checklists (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    data_hora_inicio DATETIME NOT NULL,
    data_hora_termino DATETIME,
    -- Agora com FKs para as tabelas de lookup
    tipo_inspecao_modalidade_id INT NOT NULL,
    operacao_id INT NOT NULL,
    tipo_unidade_id INT NOT NULL,
    n_lacre_uaga_pos_inspecao VARCHAR(255),
    n_lacre_uaga_pos_carregamento VARCHAR(255),
    nome_resp_lacre VARCHAR(255),
    assinatura_resp_lacre TEXT,
    nome_resp_deslacre_pos_carregamento VARCHAR(255),
    assinatura_resp_deslacre_pos_carregamento TEXT,
    n_lacre_armador VARCHAR(255),
    n_lacre_rfb VARCHAR(255),
    observacoes_gerais TEXT,
    providencias_tomadas TEXT,
    nome_resp_inspecao VARCHAR(255) NOT NULL,
    assinatura_resp_inspecao TEXT NOT NULL,
    assinatura_motorista TEXT,

    -- Foreign Key Constraints nomeadas
    CONSTRAINT fk_checklists_tipo_inspecao_modalidade FOREIGN KEY (tipo_inspecao_modalidade_id) REFERENCES tipo_inspecao_modalidade_lookup(id),
    CONSTRAINT fk_checklists_operacao FOREIGN KEY (operacao_id) REFERENCES operacao_lookup(id),
    CONSTRAINT fk_checklists_tipo_unidade FOREIGN KEY (tipo_unidade_id) REFERENCES tipo_unidade_lookup(id)
);

-- Tabela para os Pontos de Verificação (fixos e pré-definidos)
CREATE TABLE pontos_verificacao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    descricao VARCHAR(255) NOT NULL UNIQUE
);

-- Tabela de ligação para os detalhes de cada ponto verificado em um Checklist
CREATE TABLE checklist_itens (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    checklist_id BIGINT NOT NULL,
    ponto_verificacao_id INT NOT NULL,
    status_conformidade_id INT NOT NULL, -- Agora FK para lookup
    observacoes TEXT,

    CONSTRAINT fk_checklist_itens_checklist FOREIGN KEY (checklist_id) REFERENCES checklists(id) ON DELETE CASCADE,
    CONSTRAINT fk_checklist_itens_ponto_verificacao FOREIGN KEY (ponto_verificacao_id) REFERENCES pontos_verificacao(id),
    CONSTRAINT fk_checklist_itens_status_conformidade FOREIGN KEY (status_conformidade_id) REFERENCES status_conformidade_lookup(id)
);

-- Tabela para armazenar as URLs das imagens de evidência
CREATE TABLE evidencias (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    checklist_item_id BIGINT NOT NULL,
    url_imagem VARCHAR(255) NOT NULL,
    descricao TEXT,
    CONSTRAINT fk_evidencias_checklist_item FOREIGN KEY (checklist_item_id) REFERENCES checklist_itens(id) ON DELETE CASCADE
);

-- Tabela para a Verificação de Lacres de Saída (informações específicas de saída)
CREATE TABLE lacres_saida (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    checklist_id BIGINT NOT NULL UNIQUE,
    lacre_rfb_id INT NOT NULL, -- Agora FK para lookup
    lacre_armador_pos_unitizacao_id INT NOT NULL, -- Agora FK para lookup
    fita_lacre_uaga_compartimento_id INT NOT NULL, -- Agora FK para lookup
    nome_resp_verificacao VARCHAR(255) NOT NULL,
    assinatura_resp_verificacao TEXT NOT NULL,
    data_saida DATE NOT NULL,

    CONSTRAINT fk_lacres_saida_checklist FOREIGN KEY (checklist_id) REFERENCES checklists(id) ON DELETE CASCADE,
    CONSTRAINT fk_lacres_saida_lacre_rfb FOREIGN KEY (lacre_rfb_id) REFERENCES lacre_rfb_lookup(id),
    CONSTRAINT fk_lacres_saida_lacre_armador_pos_unitizacao FOREIGN KEY (lacre_armador_pos_unitizacao_id) REFERENCES lacre_armador_pos_unitizacao_lookup(id),
    CONSTRAINT fk_lacres_saida_fita_lacre_uaga_compartimento FOREIGN KEY (fita_lacre_uaga_compartimento_id) REFERENCES fita_lacre_uaga_compartimento_lookup(id)
);

-- Reativa a checagem de chaves estrangeiras
SET FOREIGN_KEY_CHECKS = 1;

-- =======================================================
-- Inserção dos Dados nas Tabelas de Tradução (Lookup Tables)
-- =======================================================

INSERT INTO tipo_inspecao_modalidade_lookup (descricao) VALUES
('Rodoviário'),
('Aéreo'),
('Marítimo');

INSERT INTO operacao_lookup (descricao) VALUES
('Verde'),
('Laranja'),
('Vermelho');

INSERT INTO tipo_unidade_lookup (descricao) VALUES
('Container'),
('Baú');

INSERT INTO status_conformidade_lookup (descricao) VALUES
('Conforme'),
('Não Conforme'),
('N/A');

INSERT INTO lacre_rfb_lookup (descricao) VALUES
('OK'),
('Não OK');

INSERT INTO lacre_armador_pos_unitizacao_lookup (descricao) VALUES
('N/A'),
('OK'),
('Não OK');

INSERT INTO fita_lacre_uaga_compartimento_lookup (descricao) VALUES
('N/A'),
('OK'),
('Não OK');

-- =======================================================
-- Inserção dos Pontos de Verificação padrão (MESMO CONTEÚDO)
-- =======================================================
INSERT INTO pontos_verificacao (descricao) VALUES
('Seção Inferior (Parte debaixo do Contêiner ou Baú)'),
('Porta (Interior e Exterior) Incluindo Selos'),
('Lateral Direita'),
('Lateral Esquerda'),
('Parede Frontal'),
('Teto'),
('Piso/Assoalho (Interior)'),
('Identificação de Pragas Visíveis'),
('Para-choques'),
('Motor'),
('Pneus'),
('Piso do Caminhão'),
('Tanque de Combustível'),
('Cabine'),
('Tanque de Ar'),
('Eixo de Transmissão'),
('Área da 5ª Roda'),
('Sistema de Exaustão (Escapamento)');