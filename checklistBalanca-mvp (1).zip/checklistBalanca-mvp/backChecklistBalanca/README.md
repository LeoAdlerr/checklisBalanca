checklistBalanca/
└── backChecklistBalanca/
    ├── Containerfile
    ├── Containerfile.dev
    ├── package.json
    ├── tsconfig.json
    └── src/
        ├── main.ts
        ├── app.module.ts
        ├── controllers/
        │   ├── app.controller.ts
        │   └── checklist.controller.ts
        ├── services/
        │   ├── app.service.ts
        │   └── checklist.service.ts
        ├── entities/
        │   ├── checklist.entity.ts
        │   ├── TipoInspecaoModalidadeLookup.entity.ts
        │   ├── OperacaoLookup.entity.ts
        │   ├── TipoUnidadeLookup.entity.ts
        │   ├── StatusConformidadeLookup.entity.ts
        │   ├── LacreRfbLookup.entity.ts
        │   ├── LacreArmadorPosUnitizacaoLookup.entity.ts
        │   ├── FitaLacreUagaCompartimentoLookup.entity.ts
        │   ├── PontoVerificacao.entity.ts
        │   ├── ChecklistItem.entity.ts
        │   ├── Evidencia.entity.ts
        │   └── LacreSaida.entity.ts