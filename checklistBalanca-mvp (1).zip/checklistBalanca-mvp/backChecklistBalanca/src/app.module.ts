import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';

// Controllers
import { AppController } from './controllers/app.controller';
import { ChecklistController } from './controllers/checklist.controller';

// Services
import { AppService } from './services/app.service';
import { ChecklistService } from './services/checklist.service';


// Entidades (Models)
import { Checklist } from './entities/checklist.entity';
import { TipoInspecaoModalidadeLookup } from './entities/TipoInspecaoModalidadeLookup.entity';
import { OperacaoLookup } from './entities/OperacaoLookup.entity';
import { TipoUnidadeLookup } from './entities/TipoUnidadeLookup.entity';
import { StatusConformidadeLookup } from './entities/StatusConformidadeLookup.entity';
import { LacreRfbLookup } from './entities/LacreRfbLookup.entity';
import { LacreArmadorPosUnitizacaoLookup } from './entities/LacreArmadorPosUnitizacaoLookup.entity';
import { FitaLacreUagaCompartimentoLookup } from './entities/FitaLacreUagaCompartimentoLookup.entity';
import { PontoVerificacao } from './entities/PontoVerificacao.entity';
import { ChecklistItem } from './entities/ChecklistItem.entity';
import { Evidencia } from './entities/Evidencia.entity';
import { LacreSaida } from './entities/LacreSaida.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT, 10) || 3306,
      username: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || 'my_secret_password',
      database: process.env.DB_DATABASE || 'UagaBD',
      // Todas as entidades para o TypeORM carregar metadados
      entities: [
        Checklist,
        TipoInspecaoModalidadeLookup,
        OperacaoLookup,
        TipoUnidadeLookup,
        StatusConformidadeLookup,
        LacreRfbLookup,
        LacreArmadorPosUnitizacaoLookup,
        FitaLacreUagaCompartimentoLookup,
        PontoVerificacao,
        ChecklistItem,
        Evidencia,
        LacreSaida,
      ],
      synchronize: false, // MUITO IMPORTANTE: Desabilita a sincronização de esquema.
      logging: ['query', 'error'],
    }),
    // Registra as entidades que terão repositórios injetáveis nos providers abaixo
    TypeOrmModule.forFeature([
      Checklist,
      ChecklistItem,
      Evidencia,
      LacreSaida,
    ]),
  ],
  controllers: [
    AppController,
    ChecklistController, // Adiciona o ChecklistController diretamente
  ],
  providers: [
    AppService,
    ChecklistService, // Adiciona o ChecklistService diretamente
  ],
})
export class AppModule {}
