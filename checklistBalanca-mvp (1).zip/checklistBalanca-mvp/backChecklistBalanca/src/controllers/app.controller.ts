import { Controller, Get } from '@nestjs/common';
import { AppService } from '../services/app.service';
import { ApiTags, ApiResponse } from '@nestjs/swagger'; // Importa decoradores do Swagger

@ApiTags('Geral') // Agrupa este controlador sob a tag "Geral" no Swagger
@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get()
  @ApiResponse({ status: 200, description: 'Retorna uma mensagem de boas-vindas da API.' }) // Documenta a resposta 200
  getHello(): string {
    return this.appService.getHello();
  }
}
