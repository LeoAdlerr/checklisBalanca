import { Controller, Get, Param, ParseIntPipe, Post, Body, HttpCode, HttpStatus, Patch, Delete } from '@nestjs/common';
import { ChecklistService } from '../services/checklist.service';
import { Checklist } from '../entities/checklist.entity';
import { CreateChecklistDto } from '../dtos/create-checklist.dto';
import { UpdateChecklistDto } from '../dtos/update-checklist.dto';
import { ApiTags, ApiParam, ApiResponse, ApiBody, ApiOperation } from '@nestjs/swagger';

@ApiTags('Checklists')
@Controller('checklists')
export class ChecklistController {
  constructor(private readonly checklistService: ChecklistService) {}

  @Post()
  @HttpCode(HttpStatus.CREATED) // Returns 201 Created for successful creation
  @ApiOperation({ summary: 'Creates a new complete checklist' }) // Operation documentation
  @ApiBody({ type: CreateChecklistDto, description: 'Complete data to create a new checklist.' }) // Defines the request body
  @ApiResponse({ status: 201, description: 'Checklist created successfully.', type: Checklist }) // Documents success response
  @ApiResponse({ status: 400, description: 'Invalid request data.' }) // Documents validation error (e.g., missing mandatory fields)
  async create(@Body() createChecklistDto: CreateChecklistDto): Promise<Checklist> {
    return this.checklistService.create(createChecklistDto);
  }

  @Get()
  @ApiOperation({ summary: 'Returns a list of all checklists' })
  @ApiResponse({ status: 200, description: 'List of checklists returned successfully.', type: [Checklist] })
  async findAll(): Promise<Checklist[]> {
    return this.checklistService.findAll();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Returns a specific checklist by ID' })
  @ApiParam({ name: 'id', description: 'Checklist ID', type: Number })
  @ApiResponse({ status: 200, description: 'Checklist returned successfully.', type: Checklist })
  @ApiResponse({ status: 404, description: 'Checklist not found.' })
  async findOne(@Param('id', ParseIntPipe) id: number): Promise<Checklist> {
    return this.checklistService.findOne(id);
  }

  @Patch(':id')
  @ApiOperation({ summary: 'Partially updates an existing checklist' })
  @ApiParam({ name: 'id', description: 'Checklist ID to be updated', type: Number })
  @ApiBody({ type: UpdateChecklistDto, description: 'Data for partial checklist update.' })
  @ApiResponse({ status: 200, description: 'Checklist updated successfully.', type: Checklist })
  @ApiResponse({ status: 404, description: 'Checklist not found for update.' })
  @ApiResponse({ status: 400, description: 'Invalid request data.' })
  async update(@Param('id', ParseIntPipe) id: number, @Body() updateChecklistDto: UpdateChecklistDto): Promise<Checklist> {
    return this.checklistService.update(id, updateChecklistDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT) // Returns 204 No Content for successful deletion
  @ApiOperation({ summary: 'Removes an existing checklist' })
  @ApiParam({ name: 'id', description: 'Checklist ID to be removed', type: Number })
  @ApiResponse({ status: 204, description: 'Checklist removed successfully.' })
  @ApiResponse({ status: 404, description: 'Checklist not found for removal.' })
  async remove(@Param('id', ParseIntPipe) id: number): Promise<void> {
    await this.checklistService.remove(id);
  }
}
