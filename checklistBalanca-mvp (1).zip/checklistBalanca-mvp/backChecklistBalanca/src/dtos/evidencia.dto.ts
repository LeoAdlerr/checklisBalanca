import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsOptional, MaxLength } from 'class-validator';

export class EvidenciaDto {
  @ApiProperty({ description: 'URL or path of the evidence image', maxLength: 255 })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  urlImagem: string;

  @ApiProperty({ description: 'Optional description of the evidence', required: false })
  @IsString()
  @IsOptional()
  descricao?: string;
}
