import { ApiProperty } from '@nestjs/swagger';
import { IsDateString, IsInt, IsNotEmpty, IsOptional, IsString, MaxLength, ValidateNested } from 'class-validator';
import { Type } from 'class-transformer';
import { ChecklistItemDto } from './checklist-item.dto';
import { LacreSaidaDto } from './lacre-saida.dto';

export class CreateChecklistDto {
  @ApiProperty({ description: 'Inspection start date and time, ISO 8601 format (YYYY-MM-DDTHH:MM:SSZ)' })
  @IsDateString()
  @IsNotEmpty()
  dataHoraInicio: Date;

  @ApiProperty({ description: 'Inspection end date and time, ISO 8601 format (YYYY-MM-DDTHH:MM:SSZ)', required: false })
  @IsDateString()
  @IsOptional()
  dataHoraTermino?: Date;

  @ApiProperty({ description: 'ID of inspection type by modality (e.g., 1 for Road)' })
  @IsInt()
  @IsNotEmpty()
  tipoInspecaoModalidadeId: number;

  @ApiProperty({ description: 'Operation ID (e.g., 1 for Green)' })
  @IsInt()
  @IsNotEmpty()
  operacaoId: number;

  @ApiProperty({ description: 'Unit type ID (e.g., 1 for Container)' })
  @IsInt()
  @IsNotEmpty()
  tipoUnidadeId: number;

  @ApiProperty({ description: 'UAGA Seal No. (Post-Inspection)', required: false, maxLength: 255 })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  nLacreUagaPosInspecao?: string;

  @ApiProperty({ description: 'UAGA Seal No. (Post-Loading)', required: false, maxLength: 255 })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  nLacreUagaPosCarregamento?: string;

  @ApiProperty({ description: 'Name of person responsible for Sealing, Unsealing, and Resealing', required: false, maxLength: 255 })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  nomeRespLacre?: string;

  @ApiProperty({ description: 'URL or hash of digital signature of the sealing responsible', required: false })
  @IsString()
  @IsOptional()
  assinaturaRespLacre?: string;

  @ApiProperty({ description: 'Name of person responsible for Post-Loading Unsealing', required: false, maxLength: 255 })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  nomeRespDeslacrePosCarregamento?: string;

  @ApiProperty({ description: 'URL or hash of digital signature of the Post-Loading Unsealing responsible', required: false })
  @IsString()
  @IsOptional()
  assinaturaRespDeslacrePosCarregamento?: string;

  @ApiProperty({ description: 'Armador Seal No.', required: false, maxLength: 255 })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  nLacreArmador?: string;

  @ApiProperty({ description: 'RFB Seal No.', required: false, maxLength: 255 })
  @IsString()
  @IsOptional()
  @MaxLength(255)
  nLacreRfb?: string;

  @ApiProperty({ description: 'General observations of the inspection', required: false })
  @IsString()
  @IsOptional()
  observacoesGerais?: string;

  @ApiProperty({ description: 'Measures taken during the inspection', required: false })
  @IsString()
  @IsOptional()
  providenciasTomadas?: string;

  @ApiProperty({ description: 'Name of the person responsible for the inspection', maxLength: 255 })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  nomeRespInspecao: string;

  @ApiProperty({ description: 'URL or hash of the digital signature of the inspection responsible' })
  @IsString()
  @IsNotEmpty()
  assinaturaRespInspecao: string;

  @ApiProperty({ description: 'URL or hash of the digital signature of the driver', required: false })
  @IsString()
  @IsOptional()
  assinaturaMotorista?: string;

  @ApiProperty({ type: [ChecklistItemDto], description: 'List of 18 vehicle verification points' })
  @ValidateNested({ each: true })
  @Type(() => ChecklistItemDto)
  @IsNotEmpty({ each: true })
  itens: ChecklistItemDto[];

  @ApiProperty({ type: LacreSaidaDto, description: 'Final verification information for exit seals' })
  @ValidateNested()
  @Type(() => LacreSaidaDto)
  @IsNotEmpty()
  lacresSaida: LacreSaidaDto;
}
