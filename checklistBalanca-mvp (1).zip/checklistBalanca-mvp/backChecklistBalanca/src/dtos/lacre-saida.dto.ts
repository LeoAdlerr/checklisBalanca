import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsDateString, IsString, MaxLength } from 'class-validator';
import { Transform } from 'class-transformer'; // Importa Transform

export class LacreSaidaDto {
  @ApiProperty({ description: 'ID of RFB seal status (e.g., 2 for OK, 3 for Not OK)' })
  @IsInt()
  @IsNotEmpty()
  lacreRfbId: number;

  @ApiProperty({ description: 'ID of Armador seal status (e.g., 1 for N/A, 2 for OK, 3 for Not OK)' })
  @IsInt()
  @IsNotEmpty()
  lacreArmadorPosUnitizacaoId: number;

  @ApiProperty({ description: 'ID of UAGA compartment seal tape status (e.g., 1 for N/A, 2 for OK, 3 for Not OK)' })
  @IsInt()
  @IsNotEmpty()
  fitaLacreUagaCompartimentoId: number;

  @ApiProperty({ description: 'Name of the person responsible for seal verification', maxLength: 255 })
  @IsString()
  @IsNotEmpty()
  @MaxLength(255)
  nomeRespVerificacao: string;

  @ApiProperty({ description: 'URL or hash of the digital signature of the verification responsible' })
  @IsString()
  @IsNotEmpty()
  assinaturaRespVerificacao: string;

  @ApiProperty({ description: 'Exit date, YYYY-MM-DD format (e.g., 2025-01-31)' })
  // @IsDateString() // Removendo IsDateString para permitir a transformação antes da validação da string exata pelo DB
  @IsString() // Validamos como string aqui, pois será transformado
  @IsNotEmpty()
  @Transform(({ value }) => { // Transforma o valor de entrada para o formato YYYY-MM-DD
    if (value instanceof Date) {
      return value.toISOString().split('T')[0];
    }
    if (typeof value === 'string' && !isNaN(new Date(value).getTime())) {
        return new Date(value).toISOString().split('T')[0];
    }
    return value; // Retorna o valor original se não for uma data válida para transformar
  })
  dataSaida: string; // Agora o tipo é string no DTO, pois será uma string 'YYYY-MM-DD'
}
