import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsNotEmpty, IsOptional, IsString } from 'class-validator';
import { EvidenciaDto } from './evidencia.dto';
import { Type } from 'class-transformer';
import { ValidateNested } from 'class-validator';

export class ChecklistItemDto {
  @ApiProperty({ description: 'ID of the verification point (e.g., 11 for Tires, 12 for Truck Floor)' })
  @IsInt()
  @IsNotEmpty()
  pontoVerificacaoId: number;

  @ApiProperty({ description: 'ID of compliance status (e.g., 1 for Compliant, 2 for Non-Compliant)' })
  @IsInt()
  @IsNotEmpty()
  statusConformidadeId: number;

  @ApiProperty({ description: 'Additional observations for the verification point', required: false })
  @IsString()
  @IsOptional()
  observacoes?: string;

  @ApiProperty({ type: [EvidenciaDto], description: 'List of evidence (images) if the point is non-compliant', required: false })
  @ValidateNested({ each: true })
  @Type(() => EvidenciaDto)
  @IsOptional()
  evidencias?: EvidenciaDto[];
}
