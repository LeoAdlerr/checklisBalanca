import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('fita_lacre_uaga_compartimento_lookup')
export class FitaLacreUagaCompartimentoLookup {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  descricao: string;
}
