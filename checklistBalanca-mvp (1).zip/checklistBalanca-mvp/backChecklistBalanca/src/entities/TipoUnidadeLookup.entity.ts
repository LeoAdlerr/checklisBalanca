import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('tipo_unidade_lookup')
export class TipoUnidadeLookup {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  descricao: string;
}
