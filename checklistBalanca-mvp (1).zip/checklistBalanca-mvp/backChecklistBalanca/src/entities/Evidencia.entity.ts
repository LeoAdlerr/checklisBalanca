import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { ChecklistItem } from './ChecklistItem.entity';

@Entity('evidencias')
export class Evidencia {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', name: 'checklist_item_id' })
  checklistItemId: number;

  @Column({ type: 'varchar', length: 255, name: 'url_imagem' })
  urlImagem: string;

  @Column({ type: 'text', nullable: true })
  descricao?: string;

  @ManyToOne(() => ChecklistItem, checklistItem => checklistItem.evidencias)
  @JoinColumn({ name: 'checklist_item_id' })
  checklistItem: ChecklistItem;
}
