import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('status_conformidade_lookup')
export class StatusConformidadeLookup {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  descricao: string;
}
