import { Entity, PrimaryGeneratedColumn, Column, OneToMany, OneToOne, JoinColumn, ManyToOne } from 'typeorm'; // <-- CORREÇÃO AQUI: Adicionado ManyToOne, OneToOne, JoinColumn
import { ChecklistItem } from './ChecklistItem.entity';
import { LacreSaida } from './LacreSaida.entity';
import { TipoInspecaoModalidadeLookup } from './TipoInspecaoModalidadeLookup.entity';
import { OperacaoLookup } from './OperacaoLookup.entity';
import { TipoUnidadeLookup } from './TipoUnidadeLookup.entity';


@Entity('checklists')
export class Checklist {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'datetime', name: 'data_hora_inicio' })
  dataHoraInicio: Date;

  @Column({ type: 'datetime', name: 'data_hora_termino', nullable: true })
  dataHoraTermino?: Date;

  @Column({ type: 'int', name: 'tipo_inspecao_modalidade_id' })
  tipoInspecaoModalidadeId: number;

  @Column({ type: 'int', name: 'operacao_id' })
  operacaoId: number;

  @Column({ type: 'int', name: 'tipo_unidade_id' })
  tipoUnidadeId: number;

  @Column({ type: 'varchar', length: 255, name: 'n_lacre_uaga_pos_inspecao', nullable: true })
  nLacreUagaPosInspecao?: string;

  @Column({ type: 'varchar', length: 255, name: 'n_lacre_uaga_pos_carregamento', nullable: true })
  nLacreUagaPosCarregamento?: string;

  @Column({ type: 'varchar', length: 255, name: 'nome_resp_lacre', nullable: true })
  nomeRespLacre?: string;

  @Column({ type: 'text', name: 'assinatura_resp_lacre', nullable: true })
  assinaturaRespLacre?: string;

  @Column({ type: 'varchar', length: 255, name: 'nome_resp_deslacre_pos_carregamento', nullable: true })
  nomeRespDeslacrePosCarregamento?: string;

  @Column({ type: 'text', name: 'assinatura_resp_deslacre_pos_carregamento', nullable: true })
  assinaturaRespDeslacrePosCarregamento?: string;

  @Column({ type: 'varchar', length: 255, name: 'n_lacre_armador', nullable: true })
  nLacreArmador?: string;

  @Column({ type: 'varchar', length: 255, name: 'n_lacre_rfb', nullable: true })
  nLacreRfb?: string;

  @Column({ type: 'text', name: 'observacoes_gerais', nullable: true })
  observacoesGerais?: string;

  @Column({ type: 'text', name: 'providencias_tomadas', nullable: true })
  providenciasTomadas?: string;

  @Column({ type: 'varchar', length: 255, name: 'nome_resp_inspecao' })
  nomeRespInspecao: string;

  @Column({ type: 'text', name: 'assinatura_resp_inspecao' })
  assinaturaRespInspecao: string;

  @Column({ type: 'text', name: 'assinatura_motorista', nullable: true })
  assinaturaMotorista?: string;

  // Relações OneToMany com ChecklistItem
  @OneToMany(() => ChecklistItem, item => item.checklist)
  itens: ChecklistItem[];

  // Relação OneToOne com LacreSaida
  @OneToOne(() => LacreSaida, lacreSaida => lacreSaida.checklist)
  lacreSaida: LacreSaida;

  // Relações ManyToOne para as tabelas lookup (para acessar descrições diretamente)
  @ManyToOne(() => TipoInspecaoModalidadeLookup)
  @JoinColumn({ name: 'tipo_inspecao_modalidade_id' })
  tipoInspecaoModalidade: TipoInspecaoModalidadeLookup;

  @ManyToOne(() => OperacaoLookup)
  @JoinColumn({ name: 'operacao_id' })
  operacao: OperacaoLookup;

  @ManyToOne(() => TipoUnidadeLookup)
  @JoinColumn({ name: 'tipo_unidade_id' })
  tipoUnidade: TipoUnidadeLookup;
}
