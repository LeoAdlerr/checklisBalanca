import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('operacao_lookup')
export class OperacaoLookup {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  descricao: string;
}
