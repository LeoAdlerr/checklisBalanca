import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Checklist } from './checklist.entity';
import { PontoVerificacao } from './PontoVerificacao.entity';
import { StatusConformidadeLookup } from './StatusConformidadeLookup.entity';
import { Evidencia } from './Evidencia.entity';

@Entity('checklist_itens')
export class ChecklistItem {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', name: 'checklist_id' })
  checklistId: number;

  @Column({ type: 'int', name: 'ponto_verificacao_id' })
  pontoVerificacaoId: number;

  @Column({ type: 'int', name: 'status_conformidade_id' })
  statusConformidadeId: number;

  @Column({ type: 'text', nullable: true })
  observacoes?: string;

  @ManyToOne(() => Checklist, checklist => checklist.itens)
  @JoinColumn({ name: 'checklist_id' })
  checklist: Checklist;

  @ManyToOne(() => PontoVerificacao)
  @JoinColumn({ name: 'ponto_verificacao_id' })
  pontoVerificacao: PontoVerificacao;

  @ManyToOne(() => StatusConformidadeLookup)
  @JoinColumn({ name: 'status_conformidade_id' })
  statusConformidade: StatusConformidadeLookup;

  @OneToMany(() => Evidencia, evidencia => evidencia.checklistItem)
  evidencias: Evidencia[];
}
