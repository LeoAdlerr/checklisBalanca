import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn, ManyToOne, ValueTransformer } from 'typeorm'; // AGORA COM ValueTransformer
import { Checklist } from './checklist.entity';
import { LacreRfbLookup } from './LacreRfbLookup.entity';
import { LacreArmadorPosUnitizacaoLookup } from './LacreArmadorPosUnitizacaoLookup.entity';
import { FitaLacreUagaCompartimentoLookup } from './FitaLacreUagaCompartimentoLookup.entity';

// Define um transformador de valor para converter Date para string 'YYYY-MM-DD'
const dateTransformer: ValueTransformer = {
  // Converte o valor do JS (Date object) para o formato do banco (string 'YYYY-MM-DD')
  to: (entityValue: Date): string | null => {
    if (entityValue instanceof Date) {
      return entityValue.toISOString().split('T')[0]; // Pega APENAS a parte da data
    }
    return entityValue; // Retorna null ou string se já não for Date
  },
  // Converte o valor do banco (string 'YYYY-MM-DD') para o formato do JS (Date object)
  from: (databaseValue: string): Date | null => {
    if (typeof databaseValue === 'string') {
      return new Date(databaseValue); // Converte a string de volta para Date
    }
    return databaseValue; // Retorna null ou Date se já não for string
  },
};

@Entity('lacres_saida')
export class LacreSaida {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'bigint', name: 'checklist_id', unique: true })
  checklistId: number;

  @Column({ type: 'int', name: 'lacre_rfb_id' })
  lacreRfbId: number;

  @Column({ type: 'int', name: 'lacre_armador_pos_unitizacao_id' })
  lacreArmadorPosUnitizacaoId: number;

  @Column({ type: 'int', name: 'fita_lacre_uaga_compartimento_id' })
  fitaLacreUagaCompartimentoId: number;

  @Column({ type: 'varchar', length: 255, name: 'nome_resp_verificacao' })
  nomeRespVerificacao: string;

  @Column({ type: 'text', name: 'assinatura_resp_verificacao' })
  assinaturaRespVerificacao: string;

  // APLICAÇÃO DO TRANSFORMADOR NA COLUNA data_saida
  @Column({ type: 'date', name: 'data_saida', transformer: dateTransformer })
  dataSaida: Date;

  @OneToOne(() => Checklist, checklist => checklist.lacreSaida)
  @JoinColumn({ name: 'checklist_id' })
  checklist: Checklist;

  @ManyToOne(() => LacreRfbLookup)
  @JoinColumn({ name: 'lacre_rfb_id' })
  lacreRfb: LacreRfbLookup;

  @ManyToOne(() => LacreArmadorPosUnitizacaoLookup)
  @JoinColumn({ name: 'lacre_armador_pos_unitizacao_id' })
  lacreArmadorPosUnitizacao: LacreArmadorPosUnitizacaoLookup;

  @ManyToOne(() => FitaLacreUagaCompartimentoLookup)
  @JoinColumn({ name: 'fita_lacre_uaga_compartimento_id' })
  fitaLacreUagaCompartimento: FitaLacreUagaCompartimentoLookup;
}
