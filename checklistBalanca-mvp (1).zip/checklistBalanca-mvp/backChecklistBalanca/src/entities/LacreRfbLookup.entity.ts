import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('lacre_rfb_lookup')
export class LacreRfbLookup {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  descricao: string;
}
