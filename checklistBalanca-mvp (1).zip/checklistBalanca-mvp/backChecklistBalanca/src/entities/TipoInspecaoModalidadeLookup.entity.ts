import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('tipo_inspecao_modalidade_lookup')
export class TipoInspecaoModalidadeLookup {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 50, unique: true })
  descricao: string;
}
