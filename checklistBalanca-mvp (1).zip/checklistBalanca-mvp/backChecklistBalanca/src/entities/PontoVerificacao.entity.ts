import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('pontos_verificacao')
export class PontoVerificacao {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'varchar', length: 255, unique: true })
  descricao: string;
}
