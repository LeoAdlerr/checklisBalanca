import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { Checklist } from '../entities/checklist.entity';
import { ChecklistItem } from '../entities/ChecklistItem.entity';
import { Evidencia } from '../entities/Evidencia.entity';
import { LacreSaida } from '../entities/LacreSaida.entity';
import { CreateChecklistDto } from '../dtos/create-checklist.dto';
import { UpdateChecklistDto } from '../dtos/update-checklist.dto';

@Injectable()
export class ChecklistService {
  constructor(
    @InjectRepository(Checklist)
    private checklistRepository: Repository<Checklist>,
    @InjectRepository(ChecklistItem)
    private checklistItemRepository: Repository<ChecklistItem>,
    @InjectRepository(Evidencia)
    private evidenciaRepository: Repository<Evidencia>,
    @InjectRepository(LacreSaida)
    private lacreSaidaRepository: Repository<LacreSaida>,
    private dataSource: DataSource, // Injeta DataSource para transações
  ) {}

  /**
   * Busca todos os checklists com suas relações.
   * @returns Uma lista de checklists.
   */
  async findAll(): Promise<Checklist[]> {
    // Carrega todas as relações necessárias para exibir um checklist completo.
    // As lookups são carregadas através das entidades principais (Checklist, ChecklistItem, LacreSaida)
    // para que suas descrições sejam automaticamente populadas.
    return this.checklistRepository.find({
      relations: [
        'itens',
        'lacreSaida',
        'itens.pontoVerificacao',
        'itens.statusConformidade',
        'itens.evidencias',
        'lacreSaida.lacreRfb',
        'lacreSaida.lacreArmadorPosUnitizacao',
        'lacreSaida.fitaLacreUagaCompartimento',
        'tipoInspecaoModalidade', // Adiciona relações com lookups para descrições
        'operacao',
        'tipoUnidade',
      ],
    });
  }

  /**
   * Busca um checklist específico pelo ID.
   * @param id ID do checklist.
   * @returns O checklist encontrado ou lança NotFoundException.
   */
  async findOne(id: number): Promise<Checklist> {
    const checklist = await this.checklistRepository.findOne({
      where: { id },
      relations: [
        'itens',
        'lacreSaida',
        'itens.pontoVerificacao',
        'itens.statusConformidade',
        'itens.evidencias',
        'lacreSaida.lacreRfb',
        'lacreSaida.lacreArmadorPosUnitizacao',
        'lacreSaida.fitaLacreUagaCompartimento',
        'tipoInspecaoModalidade',
        'operacao',
        'tipoUnidade',
      ],
    });
    if (!checklist) {
      throw new NotFoundException(`Checklist com ID ${id} não encontrado.`);
    }
    return checklist;
  }

  /**
   * Cria um novo checklist completo, incluindo seus itens, evidências e lacres de saída.
   * Utiliza uma transação para garantir a atomicidade da operação.
   * @param createChecklistDto DTO com os dados do novo checklist.
   * @returns O checklist criado.
   */
  async create(createChecklistDto: CreateChecklistDto): Promise<Checklist> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // 1. Criar e salvar o Checklist principal
      // As datas do DTO (que já são objetos Date devido ao ValidationPipe)
      // serão processadas pelos ValueTransformers das entidades, se houver.
      const checklist = this.checklistRepository.create(createChecklistDto);
      const savedChecklist = await queryRunner.manager.save(checklist);

      // 2. Criar e salvar os ChecklistItems e suas Evidências
      for (const itemDto of createChecklistDto.itens) {
        const checklistItem = this.checklistItemRepository.create({
          ...itemDto,
          checklistId: savedChecklist.id, // Associa ao checklist recém-criado
        });
        const savedChecklistItem = await queryRunner.manager.save(checklistItem);

        if (itemDto.evidencias && itemDto.evidencias.length > 0) {
          const evidencias = itemDto.evidencias.map(evidenciaDto =>
            this.evidenciaRepository.create({
              ...evidenciaDto,
              checklistItemId: savedChecklistItem.id, // Associa a evidência ao item do checklist
            }),
          );
          await queryRunner.manager.save(evidencias);
        }
      }

      // 3. Criar e salvar o LacreSaida
      const lacreSaida = this.lacreSaidaRepository.create({
        ...createChecklistDto.lacresSaida,
        checklistId: savedChecklist.id, // Associa ao checklist recém-criado
      });
      await queryRunner.manager.save(lacreSaida);

      await queryRunner.commitTransaction();
      // Retorna o checklist completo com todas as relações para o cliente
      return this.findOne(savedChecklist.id);
    } // eslint-disable-next-line @typescript-eslint/no-explicit-any
    catch (err: any) { // Captura o erro para fazer rollback da transação
      await queryRunner.rollbackTransaction();
      throw err; // Re-lança o erro para ser tratado pelo NestJS
    } finally {
      await queryRunner.release();
    }
  }

  /**
   * Atualiza parcialmente um checklist existente.
   * Para um MVP, este método foca na atualização dos campos diretos do checklist principal.
   * Atualizações de coleções (itens, evidências) ou relações (lacresSaida)
   * são mais complexas e podem exigir lógica de "upsert", remoção/recriação,
   * ou endpoints/serviços separados para garantir a atomicidade e performance.
   * @param id ID do checklist a ser atualizado.
   * @param updateChecklistDto DTO com os dados para atualização.
   * @returns O checklist atualizado.
   */
  async update(id: number, updateChecklistDto: UpdateChecklistDto): Promise<Checklist> {
    // preload carrega a entidade existente e aplica as mudanças do DTO, mas não salva no banco
    const checklist = await this.checklistRepository.preload({ id, ...updateChecklistDto });

    if (!checklist) {
      throw new NotFoundException(`Checklist com ID ${id} não encontrado para atualização.`);
    }

    // Salva as mudanças no checklist principal
    await this.checklistRepository.save(checklist);

    // TODO: Para futuras versões, adicionar lógica para atualizar itens, evidências e lacres de saída.
    // Isso pode envolver:
    // 1. Receber os IDs dos itens/evidências a serem atualizados/removidos/criados.
    // 2. Iterar sobre eles e realizar operações de CRUD nas tabelas aninhadas.
    // 3. Garantir que tudo isso ocorra dentro de uma transação.

    return this.findOne(id); // Retorna o checklist completo após atualização
  }

  /**
   * Remove um checklist existente pelo ID.
   * A deleção em cascata (ON DELETE CASCADE no DDL do MySQL) cuidará dos itens, evidências e lacres de saída relacionados.
   * @param id ID do checklist a ser removido.
   */
  async remove(id: number): Promise<void> {
    const result = await this.checklistRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException(`Checklist com ID ${id} não encontrado para remoção.`);
    }
  }
}
