import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger'; // Importa módulos do Swagger

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  const port = process.env.PORT || 8080; // Porta padrão 8080

  // Configuração do Swagger
  const config = new DocumentBuilder()
    .setTitle('API de Checklist Alfandegário UAGA') // Título da documentação
    .setDescription('Documentação da API para o checklist 8/18 alfandegário, com suporte para registro de inspeções, observações e evidências.') // Descrição
    .setVersion('1.0') // Versão da API
    .addTag('checklists') // Tag para os endpoints de checklist
    .build();

  const document = SwaggerModule.createDocument(app, config);
  // Serve a documentação Swagger na rota /api
  SwaggerModule.setup('api', app, document);

  await app.listen(port);
  console.log(`Aplicação NestJS rodando na porta ${port}`);
  console.log(`Documentação Swagger disponível em http://localhost:${port}/api`); // Informa a URL do Swagger
}
bootstrap();
