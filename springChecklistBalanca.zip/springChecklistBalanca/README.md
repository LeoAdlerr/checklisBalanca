# ARQUITETURA


springChecklistBalanca/
├── pom.xml                                   # Configuração do Maven
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── uaga/
│   │   │           └── checklist/
│   │   │               ├── ChecklistAlfandegarioApplication.java  # Classe principal da aplicação
│   │   │               ├── config/            # Classes de configuração (ex: OpenAPI)
│   │   │               ├── entity/            # Entidades JPA (representações das tabelas do BD)
│   │   │               ├── repository/        # Interfaces JPA para acesso ao BD
│   │   │               ├── service/           # Interfaces de serviço
│   │   │               │   └── impl/          # Implementações de serviço
│   │   │               └── controller/        # Controladores REST
│   │   └── resources/
│   │       ├── application.properties         # Propriedades de configuração do Spring
│   │       └── static/                        # Recursos estáticos (se houver, para um frontend embutido)
│   └── test/
│       └── java/
│           └── com/
│               └── uaga/
│                   └── checklist/
│                       └── ... (Testes)