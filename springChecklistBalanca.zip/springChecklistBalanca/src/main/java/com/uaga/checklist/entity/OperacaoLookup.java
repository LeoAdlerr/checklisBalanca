package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "operacao_lookup")
@Data
public class OperacaoLookup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "descricao", nullable = false, unique = true, length = 50)
    private String descricao;
}
