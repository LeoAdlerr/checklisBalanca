package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "pontos_verificacao")
@Data
public class PontoVerificacao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "descricao", nullable = false, unique = true, length = 255)
    private String descricao;
}
