package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDate; // Para DATE
import java.time.LocalDateTime; // Para DATETIME

@Entity
@Table(name = "lacres_saida")
@Data
public class LacreSaida {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // BIGINT

    @Column(name = "checklist_id", nullable = false, unique = true, insertable = false, updatable = false)
    private Long checklistId;

    @Column(name = "lacre_rfb_id", nullable = false, insertable = false, updatable = false)
    private Integer lacreRfbId;

    @Column(name = "lacre_armador_pos_unitizacao_id", nullable = false, insertable = false, updatable = false)
    private Integer lacreArmadorPosUnitizacaoId;

    @Column(name = "fita_lacre_uaga_compartimento_id", nullable = false, insertable = false, updatable = false)
    private Integer fitaLacreUagaCompartimentoId;

    @Column(name = "nome_resp_verificacao", nullable = false, length = 255)
    private String nomeRespVerificacao;

    @Column(name = "assinatura_resp_verificacao", nullable = false, columnDefinition = "TEXT")
    private String assinaturaRespVerificacao;

    @Column(name = "data_saida", nullable = false)
    // O JPA geralmente mapeia LocalDate para DATE. Se houver problemas de formato,
    // podemos usar um AttributeConverter personalizado.
    private LocalDate dataSaida; // Para DATE

    // Relação OneToOne com Checklist (um checklist tem uma única entrada de lacres de saída)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "checklist_id", nullable = false, unique = true) // Mapeia a FK 'checklist_id'
    @ToString.Exclude
    private Checklist checklist;

    // Relações ManyToOne para as tabelas de lookup de lacres
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lacre_rfb_id", nullable = false)
    @ToString.Exclude
    private LacreRfbLookup lacreRfb;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lacre_armador_pos_unitizacao_id", nullable = false)
    @ToString.Exclude
    private LacreArmadorPosUnitizacaoLookup lacreArmadorPosUnitizacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "fita_lacre_uaga_compartimento_id", nullable = false)
    @ToString.Exclude
    private FitaLacreUagaCompartimentoLookup fitaLacreUagaCompartimento;
    
    
}
