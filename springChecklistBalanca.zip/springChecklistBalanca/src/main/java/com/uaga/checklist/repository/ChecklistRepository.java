package com.uaga.checklist.repository;

import com.uaga.checklist.entity.Checklist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// @Repository é opcional aqui, JpaRepository já é um estereótipo do Spring
public interface ChecklistRepository extends JpaRepository<Checklist, Long> {
    // JpaRepository<Entidade, TipoDaChavePrimaria>
    // Métodos CRUD básicos (save, findById, findAll, delete, etc.) já são fornecidos automaticamente.
    // Você pode adicionar métodos de busca personalizados aqui se precisar (ex: findByNomeRespInspecao)
}
