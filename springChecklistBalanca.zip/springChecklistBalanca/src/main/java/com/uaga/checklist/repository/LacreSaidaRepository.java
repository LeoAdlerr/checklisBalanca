package com.uaga.checklist.repository;

import com.uaga.checklist.entity.LacreSaida;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface LacreSaidaRepository extends JpaRepository<LacreSaida, Long> {
    // LacreSaida findByChecklistId(Long checklistId);
}
