package com.uaga.checklist.repository;

import com.uaga.checklist.entity.ChecklistItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface ChecklistItemRepository extends JpaRepository<ChecklistItem, Long> {
    // Métodos para buscar itens por checklistId ou pontoVerificacaoId podem ser adicionados aqui
    // List<ChecklistItem> findByChecklistId(Long checklistId);
}
