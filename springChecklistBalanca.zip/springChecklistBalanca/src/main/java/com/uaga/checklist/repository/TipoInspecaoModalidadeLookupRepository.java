package com.uaga.checklist.repository;

import com.uaga.checklist.entity.TipoInspecaoModalidadeLookup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface TipoInspecaoModalidadeLookupRepository extends JpaRepository<TipoInspecaoModalidadeLookup, Integer> {
    // Optional<TipoInspecaoModalidadeLookup> findByDescricao(String descricao);
}
