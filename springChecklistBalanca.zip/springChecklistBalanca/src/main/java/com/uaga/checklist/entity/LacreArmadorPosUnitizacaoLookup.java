package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "lacre_armador_pos_unitizacao_lookup")
@Data
public class LacreArmadorPosUnitizacaoLookup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "descricao", nullable = false, unique = true, length = 50)
    private String descricao;
}
