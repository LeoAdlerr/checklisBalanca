package com.uaga.checklist.repository;

import com.uaga.checklist.entity.FitaLacreUagaCompartimentoLookup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface FitaLacreUagaCompartimentoLookupRepository extends JpaRepository<FitaLacreUagaCompartimentoLookup, Integer> {
    // Optional<FitaLacreUagaCompartimentoLookup> findByDescricao(String descricao);
}
