package com.uaga.checklist.service.impl;

import com.uaga.checklist.dto.ChecklistItemDto;
import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.LacreSaidaDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.*;
import com.uaga.checklist.entity.*;
import com.uaga.checklist.repository.*;
import com.uaga.checklist.service.ChecklistService;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Implementação do serviço para gerenciar as operações de Checklist.
 */
@Service
public class ChecklistServiceImpl implements ChecklistService {

    private static final int STATUS_NAO_CONFORME_ID = 402;

    private final ChecklistRepository checklistRepository;
    private final ChecklistItemRepository checklistItemRepository;
    private final EvidenciaRepository evidenciaRepository;
    private final LacreSaidaRepository lacreSaidaRepository;
    private final PontoVerificacaoRepository pontoVerificacaoRepository;
    private final LookupValueDataRepository lookupValueDataRepository;

    @Autowired
    public ChecklistServiceImpl(ChecklistRepository checklistRepository,
                                  ChecklistItemRepository checklistItemRepository,
                                  EvidenciaRepository evidenciaRepository,
                                  LacreSaidaRepository lacreSaidaRepository,
                                  PontoVerificacaoRepository pontoVerificacaoRepository,
                                  LookupValueDataRepository lookupValueDataRepository) {
        this.checklistRepository = checklistRepository;
        this.checklistItemRepository = checklistItemRepository;
        this.evidenciaRepository = evidenciaRepository;
        this.lacreSaidaRepository = lacreSaidaRepository;
        this.pontoVerificacaoRepository = pontoVerificacaoRepository;
        this.lookupValueDataRepository = lookupValueDataRepository;
    }

    // ... Seus outros métodos ...
    
    @Override
    @Transactional
    public ChecklistResponseDto createChecklist(CreateChecklistDto createChecklistDto) {
        Checklist checklist = new Checklist();
        mapCreateDtoToEntity(createChecklistDto, checklist);

        Checklist savedChecklist = checklistRepository.save(checklist);

        if (createChecklistDto.getItens() != null && !createChecklistDto.getItens().isEmpty()) {
            List<ChecklistItem> checklistItems = createChecklistDto.getItens().stream()
                .map(itemDto -> createAndSaveNewItem(savedChecklist, itemDto))
                .collect(Collectors.toList());
            savedChecklist.setItens(checklistItems);
        }

        if (createChecklistDto.getLacresSaida() != null) {
            LacreSaida lacreSaida = new LacreSaida();
            lacreSaida.setChecklist(savedChecklist);
            
            LacreSaidaDto lacreDto = createChecklistDto.getLacresSaida();
            lacreSaida.setNomeRespVerificacao(lacreDto.getNomeRespVerificacao());
            lacreSaida.setAssinaturaRespVerificacao(lacreDto.getAssinaturaRespVerificacao());
            lacreSaida.setDataSaida(lacreDto.getDataSaida());
            
            lacreSaida.setLacreRfb(lookupValueDataRepository.findById(lacreDto.getLacreRfbId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "RFB Seal not found.")));
            lacreSaida.setLacreArmadorPosUnitizacao(lookupValueDataRepository.findById(lacreDto.getLacreArmadorPosUnitizacaoId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Armador Post-Unitization Seal not found.")));
            lacreSaida.setFitaLacreUagaCompartimento(lookupValueDataRepository.findById(lacreDto.getFitaLacreUagaCompartimentoId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "UAGA Compartment Seal Tape not found.")));

            lacreSaidaRepository.save(lacreSaida);
            savedChecklist.setLacreSaida(lacreSaida);
        }

        return mapChecklistToResponseDto(savedChecklist);
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<ChecklistResponseDto> getAllChecklists() {
        return checklistRepository.findAll().stream()
                .map(this::mapChecklistToResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public ChecklistResponseDto getChecklistById(Long id) {
        Checklist checklist = checklistRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found with id: " + id));
        return mapChecklistToResponseDto(checklist);
    }

    @Override
    @Transactional
    public ChecklistResponseDto updateChecklist(Long id, UpdateChecklistDto updateChecklistDto) {
        Checklist checklist = checklistRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found with id: " + id));

        if (updateChecklistDto.getItens() != null) {
            updateChecklistItems(updateChecklistDto.getItens(), checklist);
        }

        if (updateChecklistDto.getObservacoesGerais() != null) {
            checklist.setObservacoesGerais(updateChecklistDto.getObservacoesGerais());
        }
        if (updateChecklistDto.getProvidenciasTomadas() != null) {
            checklist.setProvidenciasTomadas(updateChecklistDto.getProvidenciasTomadas());
        }

        if (updateChecklistDto.getDataHoraTermino() != null) {
            validateChecklistForFinalization(checklist);
            checklist.setDataHoraTermino(updateChecklistDto.getDataHoraTermino());
        }

        return mapChecklistToResponseDto(checklistRepository.save(checklist));
    }
    
    /**
     * Exclui um checklist com base no ID, aplicando regras de negócio.
     * @param id O ID do checklist a ser excluído.
     * @throws ResponseStatusException se o checklist não for encontrado ou se já estiver finalizado.
     */
    @Override
    @Transactional
    public void deleteChecklist(Long id) {
        // 1. Busca o checklist ou lança uma exceção 404 se não encontrado.
        Checklist checklist = checklistRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found with ID: " + id));

        // 2. Aplica a regra de negócio: não é possível deletar um checklist finalizado.
        if (checklist.getDataHoraTermino() != null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Checklists finalizados não podem ser excluídos.");
        }

        // 3. Se todas as condições forem atendidas, deleta o checklist.
        checklistRepository.deleteById(id);
    }

    // --- MÉTODOS PRIVADOS AUXILIARES ---

    private void updateChecklistItems(List<ChecklistItemDto> itemDtos, Checklist checklist) {
        for (ChecklistItemDto itemDto : itemDtos) {
            Optional<ChecklistItem> existingItemOpt = checklist.getItens().stream()
                    .filter(i -> i.getPontoVerificacao() != null && i.getPontoVerificacao().getId().equals(itemDto.getPontoVerificacaoId()))
                    .findFirst();

            if (existingItemOpt.isPresent()) {
                updateExistingItem(existingItemOpt.get(), itemDto);
            } else {
                ChecklistItem newItem = createAndSaveNewItem(checklist, itemDto);
                checklist.getItens().add(newItem);
            }
        }
    }

    private void validateChecklistForFinalization(Checklist checklist) {
        long totalPontosDefinidos = pontoVerificacaoRepository.count();
        if (checklist.getItens().size() < totalPontosDefinidos) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Não é possível finalizar: Todos os " + totalPontosDefinidos + " pontos de verificação devem ser preenchidos.");
        }

        boolean hasNonConformeItem = checklist.getItens().stream()
                .anyMatch(item -> item.getStatusConformidade().getId() == STATUS_NAO_CONFORME_ID);
        if (hasNonConformeItem) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Não é possível finalizar: Todos os itens devem estar 'Conforme' ou 'N/A'.");
        }
    }

    private void updateExistingItem(ChecklistItem existingItem, ChecklistItemDto itemDto) {
        existingItem.setObservacoes(itemDto.getObservacoes());
        LookupValueData status = lookupValueDataRepository.findById(itemDto.getStatusConformidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Status de conformidade inválido: " + itemDto.getStatusConformidadeId()));
        existingItem.setStatusConformidade(status);
    }

    private ChecklistItem createAndSaveNewItem(Checklist checklist, ChecklistItemDto itemDto) {
        if (checklist == null) {
            throw new IllegalArgumentException("Checklist pai não pode ser nulo ao criar um novo item.");
        }
        ChecklistItem newItem = new ChecklistItem();
        newItem.setChecklist(checklist);
        newItem.setObservacoes(itemDto.getObservacoes());
        PontoVerificacao ponto = pontoVerificacaoRepository.findById(itemDto.getPontoVerificacaoId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Ponto de verificação inválido: " + itemDto.getPontoVerificacaoId()));
        newItem.setPontoVerificacao(ponto);
        LookupValueData status = lookupValueDataRepository.findById(itemDto.getStatusConformidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Status de conformidade inválido: " + itemDto.getStatusConformidadeId()));
        newItem.setStatusConformidade(status);
        
        ChecklistItem savedItem = checklistItemRepository.save(newItem);

        if (itemDto.getEvidencias() != null && !itemDto.getEvidencias().isEmpty()) {
            List<Evidencia> evidences = itemDto.getEvidencias().stream().map(evidenciaDto -> {
                Evidencia evidencia = new Evidencia();
                evidencia.setChecklistItem(savedItem);
                evidencia.setUrlImagem(evidenciaDto.getUrlImagem());
                evidencia.setDescricao(evidenciaDto.getDescricao());
                return evidencia;
            }).collect(Collectors.toList());
            evidenciaRepository.saveAll(evidences);
            savedItem.setEvidencias(evidences);
        }
        return savedItem;
    }
    
    private void mapCreateDtoToEntity(CreateChecklistDto dto, Checklist entity) {
        entity.setDataHoraInicio(dto.getDataHoraInicio());
        entity.setDataHoraTermino(dto.getDataHoraTermino());
        entity.setNLacreUagaPosInspecao(dto.getNLacreUagaPosInspecao());
        entity.setNLacreUagaPosCarregamento(dto.getNLacreUagaPosCarregamento());
        entity.setNomeRespLacre(dto.getNomeRespLacre());
        entity.setAssinaturaRespLacre(dto.getAssinaturaRespLacre());
        entity.setNomeRespDeslacrePosCarregamento(dto.getNomeRespDeslacrePosCarregamento());
        entity.setAssinaturaRespDeslacrePosCarregamento(dto.getAssinaturaRespDeslacrePosCarregamento());
        entity.setNLacreArmador(dto.getNLacreArmador());
        entity.setNLacreRfb(dto.getNLacreRfb());
        entity.setObservacoesGerais(dto.getObservacoesGerais());
        entity.setProvidenciasTomadas(dto.getProvidenciasTomadas());
        entity.setNomeRespInspecao(dto.getNomeRespInspecao());
        entity.setAssinaturaRespInspecao(dto.getAssinaturaRespInspecao());
        entity.setAssinaturaMotorista(dto.getAssinaturaMotorista());

        entity.setTipoInspecaoModalidade(lookupValueDataRepository.findById(dto.getTipoInspecaoModalidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tipo de Inspeção inválido: " + dto.getTipoInspecaoModalidadeId())));
        entity.setOperacao(lookupValueDataRepository.findById(dto.getOperacaoId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Operação inválida: " + dto.getOperacaoId())));
        entity.setTipoUnidade(lookupValueDataRepository.findById(dto.getTipoUnidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Tipo de Unidade inválido: " + dto.getTipoUnidadeId())));
    }

    private ChecklistResponseDto mapChecklistToResponseDto(Checklist checklist) {
        if (checklist == null) return null;
        ChecklistResponseDto dto = new ChecklistResponseDto();
        dto.setId(checklist.getId());
        dto.setDataHoraInicio(checklist.getDataHoraInicio());
        dto.setDataHoraTermino(checklist.getDataHoraTermino());
        dto.setObservacoesGerais(checklist.getObservacoesGerais());
        dto.setNomeRespInspecao(checklist.getNomeRespInspecao());
        // Mapear outros campos...

        if (checklist.getTipoInspecaoModalidade() != null) {
            dto.setTipoInspecaoModalidade(new LookupValueDataResponseDto(checklist.getTipoInspecaoModalidade().getId(), checklist.getTipoInspecaoModalidade().getType(), checklist.getTipoInspecaoModalidade().getDescription()));
        }
        if (checklist.getOperacao() != null) {
            dto.setOperacao(new LookupValueDataResponseDto(checklist.getOperacao().getId(), checklist.getOperacao().getType(), checklist.getOperacao().getDescription()));
        }
        if (checklist.getTipoUnidade() != null) {
            dto.setTipoUnidade(new LookupValueDataResponseDto(checklist.getTipoUnidade().getId(), checklist.getTipoUnidade().getType(), checklist.getTipoUnidade().getDescription()));
        }

        if (checklist.getItens() != null) {
            Hibernate.initialize(checklist.getItens());
            dto.setItens(checklist.getItens().stream().map(this::mapItemToDto).collect(Collectors.toList()));
        }

        return dto;
    }

    private ChecklistItemResponseDto mapItemToDto(ChecklistItem item) {
        if (item == null) return null;
        ChecklistItemResponseDto itemDto = new ChecklistItemResponseDto();
        itemDto.setId(item.getId());
        itemDto.setObservacoes(item.getObservacoes());
        if(item.getPontoVerificacao() != null) {
            itemDto.setPontoVerificacao(new PontoVerificacaoResponseDto(item.getPontoVerificacao().getId(), item.getPontoVerificacao().getDescricao()));
        }
        if(item.getStatusConformidade() != null) {
            itemDto.setStatusConformidade(new LookupValueDataResponseDto(item.getStatusConformidade().getId(), item.getStatusConformidade().getType(), item.getStatusConformidade().getDescription()));
        }
        if (item.getEvidencias() != null) {
            Hibernate.initialize(item.getEvidencias());
            itemDto.setEvidencias(item.getEvidencias().stream()
                    .map(ev -> new EvidenciaResponseDto(ev.getId(), ev.getUrlImagem(), ev.getDescricao()))
                    .collect(Collectors.toList()));
        }
        return itemDto;
    }
}
