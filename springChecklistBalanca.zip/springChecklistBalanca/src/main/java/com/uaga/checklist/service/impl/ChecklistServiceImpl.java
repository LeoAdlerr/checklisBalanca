package com.uaga.checklist.service.impl;

import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.*;
import com.uaga.checklist.entity.*;
import com.uaga.checklist.repository.*;
import com.uaga.checklist.service.ChecklistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ChecklistServiceImpl implements ChecklistService {

    private final ChecklistRepository checklistRepository;
    private final ChecklistItemRepository checklistItemRepository;
    private final EvidenciaRepository evidenciaRepository;
    private final LacreSaidaRepository lacreSaidaRepository;
    private final PontoVerificacaoRepository pontoVerificacaoRepository;
    private final StatusConformidadeLookupRepository statusConformidadeLookupRepository;
    private final TipoInspecaoModalidadeLookupRepository tipoInspecaoModalidadeLookupRepository;
    private final OperacaoLookupRepository operacaoLookupRepository;
    private final TipoUnidadeLookupRepository tipoUnidadeLookupRepository;
    private final LacreRfbLookupRepository lacreRfbLookupRepository;
    private final LacreArmadorPosUnitizacaoLookupRepository lacreArmadorPosUnitizacaoLookupRepository;
    private final FitaLacreUagaCompartimentoLookupRepository fitaLacreUagaCompartimentoLookupRepository;

    @Autowired
    public ChecklistServiceImpl(ChecklistRepository checklistRepository,
                                ChecklistItemRepository checklistItemRepository,
                                EvidenciaRepository evidenciaRepository,
                                LacreSaidaRepository lacreSaidaRepository,
                                PontoVerificacaoRepository pontoVerificacaoRepository,
                                StatusConformidadeLookupRepository statusConformidadeLookupRepository,
                                TipoInspecaoModalidadeLookupRepository tipoInspecaoModalidadeLookupRepository,
                                OperacaoLookupRepository operacaoLookupRepository,
                                TipoUnidadeLookupRepository tipoUnidadeLookupRepository,
                                LacreRfbLookupRepository lacreRfbLookupRepository,
                                LacreArmadorPosUnitizacaoLookupRepository lacreArmadorPosUnitizacaoLookupRepository,
                                FitaLacreUagaCompartimentoLookupRepository fitaLacreUagaCompartimentoLookupRepository) {
        this.checklistRepository = checklistRepository;
        this.checklistItemRepository = checklistItemRepository;
        this.evidenciaRepository = evidenciaRepository;
        this.lacreSaidaRepository = lacreSaidaRepository;
        this.pontoVerificacaoRepository = pontoVerificacaoRepository;
        this.statusConformidadeLookupRepository = statusConformidadeLookupRepository;
        this.tipoInspecaoModalidadeLookupRepository = tipoInspecaoModalidadeLookupRepository;
        this.operacaoLookupRepository = operacaoLookupRepository;
        this.tipoUnidadeLookupRepository = tipoUnidadeLookupRepository;
        this.lacreRfbLookupRepository = lacreRfbLookupRepository;
        this.lacreArmadorPosUnitizacaoLookupRepository = lacreArmadorPosUnitizacaoLookupRepository;
        this.fitaLacreUagaCompartimentoLookupRepository = fitaLacreUagaCompartimentoLookupRepository;
    }

    @Override
    @Transactional
    public ChecklistResponseDto createChecklist(CreateChecklistDto createChecklistDto) {
        Checklist checklist = new Checklist();
        checklist.setDataHoraInicio(createChecklistDto.getDataHoraInicio());
        checklist.setDataHoraTermino(createChecklistDto.getDataHoraTermino());
        checklist.setNLacreUagaPosInspecao(createChecklistDto.getNLacreUagaPosInspecao());
        checklist.setNLacreUagaPosCarregamento(createChecklistDto.getNLacreUagaPosCarregamento());
        checklist.setNomeRespLacre(createChecklistDto.getNomeRespLacre());
        checklist.setAssinaturaRespLacre(createChecklistDto.getAssinaturaRespLacre());
        checklist.setNomeRespDeslacrePosCarregamento(createChecklistDto.getNomeRespDeslacrePosCarregamento());
        checklist.setAssinaturaRespDeslacrePosCarregamento(createChecklistDto.getAssinaturaRespDeslacrePosCarregamento());
        checklist.setNLacreArmador(createChecklistDto.getNLacreArmador());
        checklist.setNLacreRfb(createChecklistDto.getNLacreRfb());
        checklist.setObservacoesGerais(createChecklistDto.getObservacoesGerais());
        checklist.setProvidenciasTomadas(createChecklistDto.getProvidenciasTomadas()); // CORRIGIDO AQUI
        checklist.setNomeRespInspecao(createChecklistDto.getNomeRespInspecao());
        checklist.setAssinaturaRespInspecao(createChecklistDto.getAssinaturaRespInspecao());
        checklist.setAssinaturaMotorista(createChecklistDto.getAssinaturaMotorista());

        checklist.setTipoInspecaoModalidade(tipoInspecaoModalidadeLookupRepository.findById(createChecklistDto.getTipoInspecaoModalidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Inspection Modality Type not found.")));
        checklist.setOperacao(operacaoLookupRepository.findById(createChecklistDto.getOperacaoId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Operation not found.")));
        checklist.setTipoUnidade(tipoUnidadeLookupRepository.findById(createChecklistDto.getTipoUnidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unit Type not found.")));

        Checklist savedChecklist = checklistRepository.save(checklist);

        if (createChecklistDto.getItens() != null && !createChecklistDto.getItens().isEmpty()) {
            List<ChecklistItem> checklistItems = createChecklistDto.getItens().stream().map(itemDto -> {
                ChecklistItem checklistItem = new ChecklistItem();
                checklistItem.setChecklist(savedChecklist);
                checklistItem.setObservacoes(itemDto.getObservacoes());

                checklistItem.setPontoVerificacao(pontoVerificacaoRepository.findById(itemDto.getPontoVerificacaoId())
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Verification Point not found.")));
                checklistItem.setStatusConformidade(statusConformidadeLookupRepository.findById(itemDto.getStatusConformidadeId())
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Compliance Status not found.")));

                ChecklistItem savedChecklistItem = checklistItemRepository.save(checklistItem);

                if (itemDto.getEvidencias() != null && !itemDto.getEvidencias().isEmpty()) {
                    List<Evidencia> evidences = itemDto.getEvidencias().stream().map(evidenciaDto -> {
                        Evidencia evidencia = new Evidencia();
                        evidencia.setChecklistItem(savedChecklistItem);
                        evidencia.setUrlImagem(evidenciaDto.getUrlImagem());
                        evidencia.setDescricao(evidenciaDto.getDescricao());
                        return evidencia;
                    }).collect(Collectors.toList());
                    evidenciaRepository.saveAll(evidences);
                }
                return savedChecklistItem;
            }).collect(Collectors.toList());
            savedChecklist.setItens(checklistItems);
        }

        if (createChecklistDto.getLacresSaida() != null) {
            LacreSaida lacreSaida = new LacreSaida();
            lacreSaida.setChecklist(savedChecklist);
            lacreSaida.setNomeRespVerificacao(createChecklistDto.getLacresSaida().getNomeRespVerificacao());
            lacreSaida.setAssinaturaRespVerificacao(createChecklistDto.getLacresSaida().getAssinaturaRespVerificacao());
            lacreSaida.setDataSaida(createChecklistDto.getLacresSaida().getDataSaida());

            lacreSaida.setLacreRfb(lacreRfbLookupRepository.findById(createChecklistDto.getLacresSaida().getLacreRfbId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "RFB Seal not found.")));
            lacreSaida.setLacreArmadorPosUnitizacao(lacreArmadorPosUnitizacaoLookupRepository.findById(createChecklistDto.getLacresSaida().getLacreArmadorPosUnitizacaoId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Armador Post-Unitization Seal not found.")));
            lacreSaida.setFitaLacreUagaCompartimento(fitaLacreUagaCompartimentoLookupRepository.findById(createChecklistDto.getLacresSaida().getFitaLacreUagaCompartimentoId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "UAGA Compartment Seal Tape not found.")));
            
            lacreSaidaRepository.save(lacreSaida);
            savedChecklist.setLacreSaida(lacreSaida);
        }

        return mapChecklistToResponseDto(savedChecklist);
    }

    @Override
    public List<ChecklistResponseDto> getAllChecklists() {
        return checklistRepository.findAll().stream()
                .map(this::mapChecklistToResponseDto)
                .collect(Collectors.toList());
    }

    @Override
    public ChecklistResponseDto getChecklistById(Long id) {
        Checklist checklist = checklistRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found with ID: " + id));
        return mapChecklistToResponseDto(checklist);
    }

    @Override
    @Transactional
    public ChecklistResponseDto updateChecklist(Long id, UpdateChecklistDto updateChecklistDto) {
        Checklist existingChecklist = checklistRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found with ID: " + id));

        Optional.ofNullable(updateChecklistDto.getDataHoraInicio()).ifPresent(existingChecklist::setDataHoraInicio);
        Optional.ofNullable(updateChecklistDto.getDataHoraTermino()).ifPresent(existingChecklist::setDataHoraTermino);
        Optional.ofNullable(updateChecklistDto.getNLacreUagaPosInspecao()).ifPresent(existingChecklist::setNLacreUagaPosInspecao);
        Optional.ofNullable(updateChecklistDto.getNLacreUagaPosCarregamento()).ifPresent(existingChecklist::setNLacreUagaPosCarregamento);
        Optional.ofNullable(updateChecklistDto.getNomeRespLacre()).ifPresent(existingChecklist::setNomeRespLacre);
        Optional.ofNullable(updateChecklistDto.getAssinaturaRespLacre()).ifPresent(existingChecklist::setAssinaturaRespLacre);
        Optional.ofNullable(updateChecklistDto.getNomeRespDeslacrePosCarregamento()).ifPresent(existingChecklist::setNomeRespDeslacrePosCarregamento);
        Optional.ofNullable(updateChecklistDto.getAssinaturaRespDeslacrePosCarregamento()).ifPresent(existingChecklist::setAssinaturaRespDeslacrePosCarregamento);
        Optional.ofNullable(updateChecklistDto.getNLacreArmador()).ifPresent(existingChecklist::setNLacreArmador);
        Optional.ofNullable(updateChecklistDto.getNLacreRfb()).ifPresent(existingChecklist::setNLacreRfb);
        Optional.ofNullable(updateChecklistDto.getObservacoesGerais()).ifPresent(existingChecklist::setObservacoesGerais);
        Optional.ofNullable(updateChecklistDto.getProvidenciasTomadas()).ifPresent(existingChecklist::setProvidenciasTomadas); // CORRIGIDO AQUI
        Optional.ofNullable(updateChecklistDto.getNomeRespInspecao()).ifPresent(existingChecklist::setNomeRespInspecao);
        Optional.ofNullable(updateChecklistDto.getAssinaturaRespInspecao()).ifPresent(existingChecklist::setAssinaturaRespInspecao);
        Optional.ofNullable(updateChecklistDto.getAssinaturaMotorista()).ifPresent(existingChecklist::setAssinaturaMotorista);

        Optional.ofNullable(updateChecklistDto.getTipoInspecaoModalidadeId()).ifPresent(idLookup ->
                existingChecklist.setTipoInspecaoModalidade(tipoInspecaoModalidadeLookupRepository.findById(idLookup)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Inspection Modality Type not found."))));
        Optional.ofNullable(updateChecklistDto.getOperacaoId()).ifPresent(idLookup ->
                existingChecklist.setOperacao(operacaoLookupRepository.findById(idLookup)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Operation not found."))));
        Optional.ofNullable(updateChecklistDto.getTipoUnidadeId()).ifPresent(idLookup ->
                existingChecklist.setTipoUnidade(tipoUnidadeLookupRepository.findById(idLookup)
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unit Type not found.")))); // Aqui deveria ser ResponseStatusException também.

        Checklist updatedChecklist = checklistRepository.save(existingChecklist);
        return mapChecklistToResponseDto(updatedChecklist);
    }

    @Override
    @Transactional
    public void deleteChecklist(Long id) {
        if (!checklistRepository.existsById(id)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found with ID: " + id);
        }
        checklistRepository.deleteById(id);
    }

    private ChecklistResponseDto mapChecklistToResponseDto(Checklist checklist) {
        ChecklistResponseDto dto = new ChecklistResponseDto();
        dto.setId(checklist.getId());
        dto.setDataHoraInicio(checklist.getDataHoraInicio());
        dto.setDataHoraTermino(checklist.getDataHoraTermino());
        dto.setNLacreUagaPosInspecao(checklist.getNLacreUagaPosInspecao());
        dto.setNLacreUagaPosCarregamento(checklist.getNLacreUagaPosCarregamento());
        dto.setNomeRespLacre(checklist.getNomeRespLacre());
        dto.setAssinaturaRespLacre(checklist.getAssinaturaRespLacre());
        dto.setNomeRespDeslacrePosCarregamento(checklist.getNomeRespDeslacrePosCarregamento());
        dto.setAssinaturaRespDeslacrePosCarregamento(checklist.getAssinaturaRespDeslacrePosCarregamento());
        dto.setNLacreArmador(checklist.getNLacreArmador());
        dto.setNLacreRfb(checklist.getNLacreRfb());
        dto.setObservacoesGerais(checklist.getObservacoesGerais());
        dto.setProvidenciasTomadas(checklist.getProvidenciasTomadas()); // CORRIGIDO AQUI
        dto.setNomeRespInspecao(checklist.getNomeRespInspecao());
        dto.setAssinaturaRespInspecao(checklist.getAssinaturaRespInspecao());
        dto.setAssinaturaMotorista(checklist.getAssinaturaMotorista());

        if (checklist.getTipoInspecaoModalidade() != null) {
            dto.setTipoInspecaoModalidade(new TipoInspecaoModalidadeResponseDto(checklist.getTipoInspecaoModalidade().getId(), checklist.getTipoInspecaoModalidade().getDescricao()));
        }
        if (checklist.getOperacao() != null) {
            dto.setOperacao(new OperacaoResponseDto(checklist.getOperacao().getId(), checklist.getOperacao().getDescricao()));
        }
        if (checklist.getTipoUnidade() != null) {
            dto.setTipoUnidade(new TipoUnidadeResponseDto(checklist.getTipoUnidade().getId(), checklist.getTipoUnidade().getDescricao()));
        }

        if (checklist.getItens() != null) {
            List<ChecklistItemResponseDto> itemDtos = checklist.getItens().stream().map(item -> {
                ChecklistItemResponseDto itemDto = new ChecklistItemResponseDto();
                itemDto.setId(item.getId());
                itemDto.setObservacoes(item.getObservacoes());

                if (item.getPontoVerificacao() != null) {
                    itemDto.setPontoVerificacao(new PontoVerificacaoResponseDto(item.getPontoVerificacao().getId(), item.getPontoVerificacao().getDescricao()));
                }
                if (item.getStatusConformidade() != null) {
                    itemDto.setStatusConformidade(new StatusConformidadeResponseDto(item.getStatusConformidade().getId(), item.getStatusConformidade().getDescricao()));
                }
                if (item.getEvidencias() != null) {
                    List<EvidenciaResponseDto> evidenceDtos = item.getEvidencias().stream()
                            .map(ev -> new EvidenciaResponseDto(ev.getId(), ev.getUrlImagem(), ev.getDescricao()))
                            .collect(Collectors.toList());
                    itemDto.setEvidencias(evidenceDtos);
                }
                return itemDto;
            }).collect(Collectors.toList());
            dto.setItens(itemDtos);
        }

        if (checklist.getLacreSaida() != null) {
            LacreSaidaResponseDto lacreSaidaDto = new LacreSaidaResponseDto();
            lacreSaidaDto.setId(checklist.getLacreSaida().getId());
            lacreSaidaDto.setNomeRespVerificacao(checklist.getLacreSaida().getNomeRespVerificacao());
            lacreSaidaDto.setAssinaturaRespVerificacao(checklist.getLacreSaida().getAssinaturaRespVerificacao());
            lacreSaidaDto.setDataSaida(checklist.getLacreSaida().getDataSaida());

            if (checklist.getLacreSaida().getLacreRfb() != null) {
                lacreSaidaDto.setLacreRfb(new LacreRfbResponseDto(checklist.getLacreSaida().getLacreRfb().getId(), checklist.getLacreSaida().getLacreRfb().getDescricao()));
            }
            if (checklist.getLacreSaida().getLacreArmadorPosUnitizacao() != null) {
                lacreSaidaDto.setLacreArmadorPosUnitizacao(new LacreArmadorPosUnitizacaoResponseDto(checklist.getLacreSaida().getLacreArmadorPosUnitizacao().getId(), checklist.getLacreSaida().getLacreArmadorPosUnitizacao().getDescricao()));
            }
            if (checklist.getLacreSaida().getFitaLacreUagaCompartimento() != null) {
                lacreSaidaDto.setFitaLacreUagaCompartimento(new FitaLacreUagaCompartimentoResponseDto(checklist.getLacreSaida().getFitaLacreUagaCompartimento().getId(), checklist.getLacreSaida().getFitaLacreUagaCompartimento().getDescricao()));
            }
            dto.setLacreSaida(lacreSaidaDto);
        }

        return dto;
    }
}
