package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

@Entity
@Table(name = "evidencias")
@Data
public class Evidencia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // BIGINT

    @Column(name = "checklist_item_id", nullable = false, insertable = false, updatable = false)
    private Long checklistItemId;

    @Column(name = "url_imagem", nullable = false, length = 255)
    private String urlImagem;

    @Column(name = "descricao", columnDefinition = "TEXT")
    private String descricao;

    // Relação ManyToOne com ChecklistItem
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "checklist_item_id", nullable = false) // Mapeia a FK 'checklist_item_id'
    @ToString.Exclude
    private ChecklistItem checklistItem;
    
    
}
