package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "fita_lacre_uaga_compartimento_lookup")
@Data
public class FitaLacreUagaCompartimentoLookup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "descricao", nullable = false, unique = true, length = 50)
    private String descricao;
    
    
}
