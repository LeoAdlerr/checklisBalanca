package com.uaga.checklist.repository;

import com.uaga.checklist.entity.OperacaoLookup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface OperacaoLookupRepository extends JpaRepository<OperacaoLookup, Integer> {
    // Optional<OperacaoLookup> findByDescricao(String descricao);
}
