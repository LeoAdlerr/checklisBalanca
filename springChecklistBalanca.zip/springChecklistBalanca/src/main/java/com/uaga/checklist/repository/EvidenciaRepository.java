package com.uaga.checklist.repository;

import com.uaga.checklist.entity.Evidencia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface EvidenciaRepository extends JpaRepository<Evidencia, Long> {
    // List<Evidencia> findByChecklistItemId(Long checklistItemId);
}
