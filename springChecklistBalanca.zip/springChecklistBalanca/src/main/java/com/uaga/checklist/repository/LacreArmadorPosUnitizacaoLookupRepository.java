package com.uaga.checklist.repository;

import com.uaga.checklist.entity.LacreArmadorPosUnitizacaoLookup;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

public interface LacreArmadorPosUnitizacaoLookupRepository extends JpaRepository<LacreArmadorPosUnitizacaoLookup, Integer> {
    // Optional<LacreArmadorPosUnitizacaoLookup> findByDescricao(String descricao);
}
