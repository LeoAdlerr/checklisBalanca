package com.uaga.checklist.controller;

import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.ChecklistResponseDto;
import com.uaga.checklist.service.ChecklistService; // Inject the interface
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController // Marks this as a REST controller
@RequestMapping("/api/checklists") // Base path for all endpoints in this controller
@Tag(name = "Checklists", description = "Operations related to Checklist management") // Swagger tag
public class ChecklistController {

    private final ChecklistService checklistService; // Inject the interface

    @Autowired // Inject via constructor
    public ChecklistController(ChecklistService checklistService) {
        this.checklistService = checklistService;
    }

    @PostMapping
    @Operation(summary = "Creates a new complete Checklist",
               description = "Creates a new Checklist including all its items, evidences, and seal out information.")
    @ApiResponse(responseCode = "201", description = "Checklist created successfully",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    @ApiResponse(responseCode = "400", description = "Invalid request data",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<ChecklistResponseDto> createChecklist(@Valid @RequestBody CreateChecklistDto createChecklistDto) {
        ChecklistResponseDto createdChecklist = checklistService.createChecklist(createChecklistDto);
        return new ResponseEntity<>(createdChecklist, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Retrieves all Checklists",
               description = "Returns a list of all Checklists with their associated details.")
    @ApiResponse(responseCode = "200", description = "List of checklists retrieved successfully",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    public ResponseEntity<List<ChecklistResponseDto>> getAllChecklists() {
        List<ChecklistResponseDto> checklists = checklistService.getAllChecklists();
        return new ResponseEntity<>(checklists, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Retrieves a specific Checklist by ID",
               description = "Returns a single Checklist based on its unique identifier.")
    @Parameter(name = "id", description = "ID of the Checklist to retrieve", required = true, schema = @Schema(type = "long"))
    @ApiResponse(responseCode = "200", description = "Checklist retrieved successfully",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "Checklist not found",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<ChecklistResponseDto> getChecklistById(@PathVariable Long id) {
        ChecklistResponseDto checklist = checklistService.getChecklistById(id);
        return new ResponseEntity<>(checklist, HttpStatus.OK);
    }

    @PutMapping("/{id}") // Using PUT for full replacement or major update
    @Operation(summary = "Updates an existing Checklist",
               description = "Updates the fields of an existing Checklist identified by its ID. Note: Complex nested updates (items, evidences) may require separate logic or endpoints.")
    @Parameter(name = "id", description = "ID of the Checklist to update", required = true, schema = @Schema(type = "long"))
    @ApiResponse(responseCode = "200", description = "Checklist updated successfully",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    @ApiResponse(responseCode = "400", description = "Invalid request data",
                 content = @Content(mediaType = "application/json"))
    @ApiResponse(responseCode = "404", description = "Checklist not found",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<ChecklistResponseDto> updateChecklist(@PathVariable Long id, @Valid @RequestBody UpdateChecklistDto updateChecklistDto) {
        ChecklistResponseDto updatedChecklist = checklistService.updateChecklist(id, updateChecklistDto);
        return new ResponseEntity<>(updatedChecklist, HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Deletes a Checklist by ID",
               description = "Deletes an existing Checklist and all its associated items, evidences, and seal out information.")
    @Parameter(name = "id", description = "ID of the Checklist to delete", required = true, schema = @Schema(type = "long"))
    @ApiResponse(responseCode = "204", description = "Checklist deleted successfully (No Content)")
    @ApiResponse(responseCode = "404", description = "Checklist not found",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<Void> deleteChecklist(@PathVariable Long id) {
        checklistService.deleteChecklist(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT); // 204 No Content
    }
}
