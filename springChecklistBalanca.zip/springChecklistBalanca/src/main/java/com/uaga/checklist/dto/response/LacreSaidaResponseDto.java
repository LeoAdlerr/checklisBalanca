package com.uaga.checklist.dto.response;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "DTO de Resposta para Lacres de Saída")
public class LacreSaidaResponseDto {
    private Long id;
    private String nomeRespVerificacao;
    private String assinaturaRespVerificacao;
    private LocalDate dataSaida;

    @Schema(description = "Detalhes do status do lacre RFB")
    private LacreRfbResponseDto lacreRfb;

    @Schema(description = "Detalhes do status do lacre Armador")
    private LacreArmadorPosUnitizacaoResponseDto lacreArmadorPosUnitizacao;

    @Schema(description = "Detalhes do status da fita lacre UAGA")
    private FitaLacreUagaCompartimentoResponseDto fitaLacreUagaCompartimento;
}
