package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Entity
@Table(name = "checklist_itens")
@Data
public class ChecklistItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // BIGINT

    @Column(name = "checklist_id", nullable = false, insertable = false, updatable = false)
    // insertable/updatable = false para que o JPA gerencie esta coluna via o objeto de relacionamento
    private Long checklistId;

    @Column(name = "ponto_verificacao_id", nullable = false, insertable = false, updatable = false)
    private Integer pontoVerificacaoId;

    @Column(name = "status_conformidade_id", nullable = false, insertable = false, updatable = false)
    private Integer statusConformidadeId;

    @Column(name = "observacoes", columnDefinition = "TEXT")
    private String observacoes;

    // Relações ManyToOne (FKs)
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "checklist_id", nullable = false) // Mapeia a FK 'checklist_id'
    @ToString.Exclude
    private Checklist checklist;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ponto_verificacao_id", nullable = false)
    @ToString.Exclude
    private PontoVerificacao pontoVerificacao;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "status_conformidade_id", nullable = false)
    @ToString.Exclude
    private StatusConformidadeLookup statusConformidade;

    // Relação OneToMany com Evidencia
    @OneToMany(mappedBy = "checklistItem", cascade = CascadeType.ALL, orphanRemoval = true)
    @ToString.Exclude
    private List<Evidencia> evidencias;

    
}
