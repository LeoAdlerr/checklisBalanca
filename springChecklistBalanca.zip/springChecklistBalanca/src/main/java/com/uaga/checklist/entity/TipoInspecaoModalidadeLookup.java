package com.uaga.checklist.entity;

import jakarta.persistence.*;
import lombok.Data; // Importa Lombok para getters/setters

@Entity
@Table(name = "tipo_inspecao_modalidade_lookup") // Nome exato da tabela no BD
@Data // Gera getters e setters, toString, equals e hashCode
public class TipoInspecaoModalidadeLookup {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // IDENTITY para AUTO_INCREMENT no MySQL
    private Integer id; // Integer para INT

    @Column(name = "descricao", nullable = false, unique = true, length = 50)
    private String descricao;
}
