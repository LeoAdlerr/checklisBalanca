package com.uaga.checklist;

public class ChecklistAlfandegarioTest {
    
}
