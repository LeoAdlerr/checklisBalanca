package com.uaga.checklist.service.impl;

import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.ChecklistItemDto;
import com.uaga.checklist.dto.LacreSaidaDto;
import com.uaga.checklist.dto.EvidenciaDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.*;
import com.uaga.checklist.entity.*;
import com.uaga.checklist.repository.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class) // Habilita o uso de Mockito para testes JUnit 5
public class ChecklistServiceImplTest {

    @Mock
    private ChecklistRepository checklistRepository;
    @Mock
    private ChecklistItemRepository checklistItemRepository;
    @Mock
    private EvidenciaRepository evidenciaRepository;
    @Mock
    private LacreSaidaRepository lacreSaidaRepository;
    @Mock
    private PontoVerificacaoRepository pontoVerificacaoRepository;
    @Mock
    private LookupValueDataRepository lookupValueDataRepository; // Mock para a tabela única de lookup

    @InjectMocks // Injeta os mocks criados acima na instância real do serviço
    private ChecklistServiceImpl checklistService;

    // --- Métodos Auxiliares para criação de DTOs e Entidades para Testes ---

    private CreateChecklistDto createSampleCreateChecklistDto() {
        EvidenciaDto evidenciaDto = new EvidenciaDto("https://example.com/foto1.jpg", "Rachadura na parede");
        ChecklistItemDto itemDto = new ChecklistItemDto(11, 402, "Observação item 1", Arrays.asList(evidenciaDto)); // StatusConformidade
                                                                                                                    // ID
                                                                                                                    // 402
                                                                                                                    // ("Não
                                                                                                                    // Conforme")
        LacreSaidaDto lacreSaidaDto = new LacreSaidaDto(2, 2, 1, "Resp Verif", "Assinatura Resp",
                LocalDate.of(2025, 6, 11)); // IDs de lookup comuns

        return new CreateChecklistDto(
                LocalDateTime.of(2025, 6, 11, 10, 0, 0),
                LocalDateTime.of(2025, 6, 11, 10, 30, 0),
                101, // TipoInspecaoModalidade ID 101 ("Rodoviário")
                201, // Operacao ID 201 ("Verde")
                301, // TipoUnidade ID 301 ("Container")
                "LacreUaga1", "LacreUaga2", "Nome Lacre", "Assinatura Lacre",
                "Nome Deslacre", "Assinatura Deslacre", "LacreArmador", "LacreRFB",
                "Obs Gerais", "Providencias", "Nome Inspetor", "Assinatura Inspetor", "Assinatura Motorista",
                Arrays.asList(itemDto), lacreSaidaDto);
    }

    private Checklist createSampleChecklistEntity(Long id) {
        Checklist checklist = new Checklist();
        checklist.setId(id);
        checklist.setDataHoraInicio(LocalDateTime.of(2025, 6, 11, 10, 0, 0));
        checklist.setDataHoraTermino(LocalDateTime.of(2025, 6, 11, 10, 30, 0));
        checklist.setNLacreUagaPosInspecao("LacreUaga1");
        checklist.setNLacreUagaPosCarregamento("LacreUaga2");
        checklist.setNomeRespLacre("Nome Lacre");
        checklist.setAssinaturaRespLacre("Assinatura Lacre");
        checklist.setNomeRespDeslacrePosCarregamento("Nome Deslacre");
        checklist.setAssinaturaRespDeslacrePosCarregamento("Assinatura Deslacre");
        checklist.setNLacreArmador("LacreArmador");
        checklist.setNLacreRfb("LacreRFB");
        checklist.setObservacoesGerais("Obs Gerais");
        checklist.setProvidenciasTomadas("Providencias");
        checklist.setNomeRespInspecao("Nome Inspetor");
        checklist.setAssinaturaRespInspecao("Assinatura Inspetor");
        checklist.setAssinaturaMotorista("Assinatura Motorista");

        // Lookups usando a nova entidade LookupValueData
        LookupValueData tipoInspecao = new LookupValueData(101, "TIPO_INSPECAO_MODALIDADE", "Rodoviário");
        checklist.setTipoInspecaoModalidade(tipoInspecao);

        LookupValueData operacao = new LookupValueData(201, "OPERACAO", "Verde");
        checklist.setOperacao(operacao);

        LookupValueData tipoUnidade = new LookupValueData(301, "TIPO_UNIDADE", "Container");
        checklist.setTipoUnidade(tipoUnidade);

        // Crie itens de checklist associados à entidade
        ChecklistItem item = new ChecklistItem();
        item.setId(1L);
        item.setChecklist(checklist);
        item.setObservacoes("Observação item 1");
        PontoVerificacao pontoVerificacao = new PontoVerificacao(11, "Pneus");
        item.setPontoVerificacao(pontoVerificacao);
        LookupValueData statusConformidade = new LookupValueData(402, "STATUS_CONFORMIDADE", "Não Conforme");
        item.setStatusConformidade(statusConformidade);
        item.setEvidencias(Arrays.asList(new Evidencia()));
        checklist.setItens(Arrays.asList(item));

        // Crie lacre de saída associado
        LacreSaida lacreSaida = new LacreSaida();
        lacreSaida.setId(1L);
        lacreSaida.setChecklist(checklist);
        lacreSaida.setNomeRespVerificacao("Resp Verif");
        lacreSaida.setAssinaturaRespVerificacao("Assinatura Resp");
        lacreSaida.setDataSaida(LocalDate.of(2025, 6, 11));

        LookupValueData lacreRfb = new LookupValueData(2, "COMUM", "OK");
        lacreSaida.setLacreRfb(lacreRfb);
        LookupValueData lacreArmador = new LookupValueData(2, "COMUM", "OK");
        lacreSaida.setLacreArmadorPosUnitizacao(lacreArmador);
        LookupValueData fitaLacre = new LookupValueData(1, "COMUM", "N/A");
        lacreSaida.setFitaLacreUagaCompartimento(fitaLacre);
        checklist.setLacreSaida(lacreSaida);

        return checklist;
    }

    // --- Testes para o método createChecklist ---

    @Test
    void createChecklist_shouldCreateAndReturnChecklist() {
        // Dado
        CreateChecklistDto createDto = createSampleCreateChecklistDto();
        Checklist checklistEntity = createSampleChecklistEntity(1L); // Entidade que o repo retornaria

        // Mocks para as lookups (agora usam LookupValueDataRepository)
        when(lookupValueDataRepository.findById(eq(createDto.getTipoInspecaoModalidadeId())))
                .thenReturn(Optional.of(checklistEntity.getTipoInspecaoModalidade()));
        when(lookupValueDataRepository.findById(eq(createDto.getOperacaoId())))
                .thenReturn(Optional.of(checklistEntity.getOperacao()));
        when(lookupValueDataRepository.findById(eq(createDto.getTipoUnidadeId())))
                .thenReturn(Optional.of(checklistEntity.getTipoUnidade()));

        when(pontoVerificacaoRepository.findById(any(Integer.class)))
                .thenReturn(Optional.of(checklistEntity.getItens().get(0).getPontoVerificacao()));
        when(lookupValueDataRepository.findById(eq(createDto.getItens().get(0).getStatusConformidadeId())))
                .thenReturn(Optional.of(checklistEntity.getItens().get(0).getStatusConformidade()));

        // CORREÇÃO: Usando lenient() para o stubbing do ID 2, pois ele é chamado duas
        // vezes no serviço (lacreRfb e lacreArmador)
        // Isso resolve o UnnecessaryStubbingException.
        lenient().when(lookupValueDataRepository.findById(eq(createDto.getLacresSaida().getLacreRfbId())))
                .thenReturn(Optional.of(checklistEntity.getLacreSaida().getLacreRfb()));
        lenient()
                .when(lookupValueDataRepository
                        .findById(eq(createDto.getLacresSaida().getLacreArmadorPosUnitizacaoId())))
                .thenReturn(Optional.of(checklistEntity.getLacreSaida().getLacreArmadorPosUnitizacao()));
        when(lookupValueDataRepository.findById(eq(createDto.getLacresSaida().getFitaLacreUagaCompartimentoId())))
                .thenReturn(Optional.of(checklistEntity.getLacreSaida().getFitaLacreUagaCompartimento()));

        // Mocks para saves
        when(checklistRepository.save(any(Checklist.class))).thenReturn(checklistEntity);
        when(checklistItemRepository.save(any(ChecklistItem.class))).thenAnswer(invocation -> {
            ChecklistItem item = invocation.getArgument(0);
            item.setId(1L);
            return item;
        });
        when(evidenciaRepository.saveAll(anyList())).thenReturn(Collections.emptyList());
        when(lacreSaidaRepository.save(any(LacreSaida.class))).thenAnswer(invocation -> {
            LacreSaida lacre = invocation.getArgument(0);
            lacre.setId(1L);
            return lacre;
        });

        // Quando
        ChecklistResponseDto result = checklistService.createChecklist(createDto);

        // Então
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Nome Inspetor", result.getNomeRespInspecao());
        assertNotNull(result.getItens());
        assertFalse(result.getItens().isEmpty());
        assertNotNull(result.getLacreSaida());

        // Verifica se os métodos do repositório foram chamados
        verify(checklistRepository, times(1)).save(any(Checklist.class));
        verify(checklistItemRepository, times(createDto.getItens().size())).save(any(ChecklistItem.class));
        verify(evidenciaRepository, times(1)).saveAll(anyList());
        verify(lacreSaidaRepository, times(1)).save(any(LacreSaida.class));
    }

    @Test
    void createChecklist_shouldThrowException_whenLookupNotFound() {
        // Dado
        CreateChecklistDto createDto = createSampleCreateChecklistDto();

        // Quando uma lookup específica não é encontrada (ex: tipoInspecaoModalidade)
        when(lookupValueDataRepository.findById(eq(createDto.getTipoInspecaoModalidadeId())))
                .thenReturn(Optional.empty());

        // Então
        assertThrows(ResponseStatusException.class, () -> checklistService.createChecklist(createDto));
        verify(checklistRepository, never()).save(any(Checklist.class));
    }

    // --- Testes para o método getAllChecklists ---
    // Dentro da classe ChecklistServiceImplTest.java

    @Test
    void getChecklistById_whenChecklistExists_shouldReturnChecklist() {
        // GIVEN
        Long checklistId = 1L;
        Checklist checklist = new Checklist(); // Crie uma entidade de amostra
        checklist.setId(checklistId);
        checklist.setNomeRespInspecao("Inspetor Teste");

        // Mock do repositório para simular que o checklist foi encontrado
        when(checklistRepository.findById(checklistId)).thenReturn(Optional.of(checklist));

        // WHEN
        ChecklistResponseDto foundDto = checklistService.getChecklistById(checklistId);

        // THEN
        assertNotNull(foundDto);
        assertEquals(checklistId, foundDto.getId());
        assertEquals("Inspetor Teste", foundDto.getNomeRespInspecao());
    }

    @Test
    void getChecklistById_whenChecklistDoesNotExist_shouldThrowException() {
        // GIVEN
        Long checklistId = 99L; // Um ID que não existe

        // Mock do repositório para simular que nada foi encontrado
        when(checklistRepository.findById(checklistId)).thenReturn(Optional.empty());

        // WHEN & THEN
        // Verifica se a exceção correta é lançada
        assertThrows(ResponseStatusException.class, () -> {
            checklistService.getChecklistById(checklistId);
        });
    }

    @Test
    void getAllChecklists_whenChecklistsExist_shouldReturnListOfChecklists() {
        // GIVEN
        Checklist checklist1 = new Checklist();
        checklist1.setId(1L);
        Checklist checklist2 = new Checklist();
        checklist2.setId(2L);
        List<Checklist> checklists = Arrays.asList(checklist1, checklist2);

        // Mock do repositório
        when(checklistRepository.findAll()).thenReturn(checklists);

        // WHEN
        List<ChecklistResponseDto> result = checklistService.getAllChecklists();

        // THEN
        assertNotNull(result);
        assertEquals(2, result.size());
    }

    @Test
    void getAllChecklists_whenNoChecklists_shouldReturnEmptyList() {
        // GIVEN
        // Mock para retornar uma lista vazia
        when(checklistRepository.findAll()).thenReturn(Collections.emptyList());

        // WHEN
        List<ChecklistResponseDto> result = checklistService.getAllChecklists();

        // THEN
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    // --- Testes para o método updateChecklist ---
    // --- Constantes para os Testes ---
    // Assumimos que o ID para o status de item "Conforme" é 401.
    private static final int STATUS_CONFORME_ID = 401;
    // Assumimos que o ID para o status "Não se Aplica" também é válido para
    // finalizar.
    private static final int STATUS_NAO_SE_APLICA_ID = 403;
    // Conforme seus requisitos, o total de pontos de verificação é 18.
    private static final long TOTAL_PONTOS_VERIFICACAO = 18L;

    @Test
    void updateChecklist_whenUpdatingSimpleField_shouldSucceed() {
        // GIVEN: Uma requisição para atualizar um campo de texto simples, sem finalizar
        // a inspeção.
        Long checklistId = 1L;
        String novasObservacoes = "Observações atualizadas pelo teste.";
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais(novasObservacoes);

        Checklist existingChecklist = new Checklist();
        existingChecklist.setId(checklistId);
        existingChecklist.setObservacoesGerais("Observações antigas.");

        when(checklistRepository.findById(checklistId)).thenReturn(Optional.of(existingChecklist));
        when(checklistRepository.save(any(Checklist.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // WHEN
        checklistService.updateChecklist(checklistId, updateDto);

        // THEN
        // Verifica se o método save foi chamado com o campo correto atualizado e SEM
        // data de término.
        verify(checklistRepository)
                .save(argThat(savedChecklist -> savedChecklist.getObservacoesGerais().equals(novasObservacoes) &&
                        savedChecklist.getDataHoraTermino() == null));
    }

    @Test
    void updateChecklist_whenFinalizingAndAllConditionsMet_shouldSucceed() {
        // GIVEN: Uma requisição para finalizar (definir data de término), com um
        // checklist que cumpre todas as regras.
        Long checklistId = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setDataHoraTermino(LocalDateTime.now());

        Checklist existingChecklist = new Checklist();
        existingChecklist.setId(checklistId);

        // Cria 18 itens, a maioria "Conforme" e alguns "N/A"
        List<ChecklistItem> items = new ArrayList<>();
        for (int i = 0; i < 15; i++) {
            ChecklistItem item = new ChecklistItem();
            item.setStatusConformidade(new LookupValueData(STATUS_CONFORME_ID, "STATUS_CONFORMIDADE", "Conforme"));
            items.add(item);
        }
        for (int i = 0; i < 3; i++) {
            ChecklistItem item = new ChecklistItem();
            item.setStatusConformidade(new LookupValueData(STATUS_NAO_SE_APLICA_ID, "STATUS_CONFORMIDADE", "N/A"));
            items.add(item);
        }
        existingChecklist.setItens(items);

        // Mocks
        when(checklistRepository.findById(checklistId)).thenReturn(Optional.of(existingChecklist));
        when(pontoVerificacaoRepository.count()).thenReturn(TOTAL_PONTOS_VERIFICACAO);
        when(checklistRepository.save(any(Checklist.class))).thenAnswer(invocation -> invocation.getArgument(0));

        // WHEN
        checklistService.updateChecklist(checklistId, updateDto);

        // THEN
        // Verifica se o método save foi chamado com a data de término preenchida.
        verify(checklistRepository).save(argThat(savedChecklist -> savedChecklist.getDataHoraTermino() != null));
    }

    @Test
    void updateChecklist_whenFinalizingButNotAllPointsArePresent_shouldThrowException() {
        // GIVEN: Checklist com menos de 18 itens.
        Long checklistId = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setDataHoraTermino(LocalDateTime.now());

        Checklist existingChecklist = new Checklist();
        existingChecklist.setId(checklistId);
        existingChecklist.setItens(Collections.singletonList(new ChecklistItem())); // Apenas 1 item

        when(checklistRepository.findById(checklistId)).thenReturn(Optional.of(existingChecklist));
        when(pontoVerificacaoRepository.count()).thenReturn(TOTAL_PONTOS_VERIFICACAO);

        // WHEN & THEN: Espera uma exceção de BAD_REQUEST.
        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> {
            checklistService.updateChecklist(checklistId, updateDto);
        });
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
        assertTrue(exception.getReason().contains("Todos os 18 pontos de verificação devem ser preenchidos"));
    }

    @Test
    void updateChecklist_whenFinalizingButOneItemIsNotConforme_shouldThrowException() {
        // GIVEN: Checklist com 18 itens, mas um deles é "Não Conforme".
        Long checklistId = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setDataHoraTermino(LocalDateTime.now());

        Checklist existingChecklist = new Checklist();
        existingChecklist.setId(checklistId);
        List<ChecklistItem> items = new ArrayList<>();
        for (int i = 0; i < TOTAL_PONTOS_VERIFICACAO - 1; i++) {
            ChecklistItem item = new ChecklistItem();
            item.setStatusConformidade(new LookupValueData(STATUS_CONFORME_ID, "STATUS_CONFORMIDADE", "Conforme"));
            items.add(item);
        }
        // Adiciona um item "Não Conforme"
        ChecklistItem nonConformeItem = new ChecklistItem();
        nonConformeItem.setStatusConformidade(new LookupValueData(402, "STATUS_CONFORMIDADE", "Não Conforme"));
        items.add(nonConformeItem);
        existingChecklist.setItens(items);

        when(checklistRepository.findById(checklistId)).thenReturn(Optional.of(existingChecklist));
        when(pontoVerificacaoRepository.count()).thenReturn(TOTAL_PONTOS_VERIFICACAO);

        // WHEN & THEN: Espera uma exceção de BAD_REQUEST.
        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> {
            checklistService.updateChecklist(checklistId, updateDto);
        });
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
        assertTrue(exception.getReason().contains("Todos os itens devem estar 'Conforme' ou 'N/A'"));
    }

    // --- Testes para o método deleteChecklist ---

    /*
     * @Test
     * void deleteChecklist_shouldDeleteChecklistWhenFound() {
     * Long id = 1L;
     * when(checklistRepository.existsById(id)).thenReturn(true);
     * 
     * checklistService.deleteChecklist(id);
     * 
     * verify(checklistRepository, times(1)).existsById(id);
     * verify(checklistRepository, times(1)).deleteById(id);
     * }
     * 
     * @Test
     * void deleteChecklist_shouldThrowNotFoundExceptionWhenNotFound() {
     * Long id = 99L;
     * when(checklistRepository.existsById(id)).thenReturn(false);
     * 
     * ResponseStatusException exception =
     * assertThrows(ResponseStatusException.class,
     * () -> checklistService.deleteChecklist(id));
     * assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
     * assertEquals("Checklist not found with ID: " + id, exception.getReason());
     * verify(checklistRepository, times(1)).existsById(id);
     * verify(checklistRepository, never()).deleteById(any(Long.class));
     * }
     */
}
