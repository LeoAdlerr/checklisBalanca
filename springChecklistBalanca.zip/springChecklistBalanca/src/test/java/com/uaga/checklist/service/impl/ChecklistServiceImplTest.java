package com.uaga.checklist.service.impl;

import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.ChecklistItemDto;
import com.uaga.checklist.dto.LacreSaidaDto;
import com.uaga.checklist.dto.EvidenciaDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.*;
import com.uaga.checklist.entity.*;
import com.uaga.checklist.repository.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class) // Habilita o uso de Mockito para testes JUnit 5
public class ChecklistServiceImplTest {

    @Mock
    private ChecklistRepository checklistRepository;
    @Mock
    private ChecklistItemRepository checklistItemRepository;
    @Mock
    private EvidenciaRepository evidenciaRepository;
    @Mock
    private LacreSaidaRepository lacreSaidaRepository;
    @Mock
    private PontoVerificacaoRepository pontoVerificacaoRepository;
    @Mock
    private StatusConformidadeLookupRepository statusConformidadeLookupRepository;
    @Mock
    private TipoInspecaoModalidadeLookupRepository tipoInspecaoModalidadeLookupRepository;
    @Mock
    private OperacaoLookupRepository operacaoLookupRepository;
    @Mock
    private TipoUnidadeLookupRepository tipoUnidadeLookupRepository;
    @Mock
    private LacreRfbLookupRepository lacreRfbLookupRepository;
    @Mock
    private LacreArmadorPosUnitizacaoLookupRepository lacreArmadorPosUnitizacaoLookupRepository;
    @Mock
    private FitaLacreUagaCompartimentoLookupRepository fitaLacreUagaCompartimentoLookupRepository;

    @InjectMocks
    private ChecklistServiceImpl checklistService;

    // --- Métodos Auxiliares para criação de DTOs e Entidades para Testes ---

    private CreateChecklistDto createSampleCreateChecklistDto() {
        EvidenciaDto evidenciaDto = new EvidenciaDto("https://example.com/foto1.jpg", "Rachadura na parede");
        ChecklistItemDto itemDto = new ChecklistItemDto(1, 2, "Observação item 1", Arrays.asList(evidenciaDto));
        LacreSaidaDto lacreSaidaDto = new LacreSaidaDto(2, 2, 1, "Resp Verif", "Assinatura Resp", LocalDate.of(2025, 6, 11));

        return new CreateChecklistDto(
                LocalDateTime.of(2025, 6, 11, 10, 0, 0),
                LocalDateTime.of(2025, 6, 11, 10, 30, 0),
                1, 1, 1, "LacreUaga1", "LacreUaga2", "Nome Lacre", "Assinatura Lacre",
                "Nome Deslacre", "Assinatura Deslacre", "LacreArmador", "LacreRFB",
                "Obs Gerais", "Providencias", "Nome Inspetor", "Assinatura Inspetor", "Assinatura Motorista",
                Arrays.asList(itemDto), lacreSaidaDto
        );
    }

    private Checklist createSampleChecklistEntity(Long id) {
        Checklist checklist = new Checklist();
        checklist.setId(id);
        checklist.setDataHoraInicio(LocalDateTime.of(2025, 6, 11, 10, 0, 0));
        checklist.setDataHoraTermino(LocalDateTime.of(2025, 6, 11, 10, 30, 0));
        checklist.setNLacreUagaPosInspecao("LacreUaga1");
        checklist.setNLacreUagaPosCarregamento("LacreUaga2");
        checklist.setNomeRespLacre("Nome Lacre");
        checklist.setAssinaturaRespLacre("Assinatura Lacre");
        checklist.setNomeRespDeslacrePosCarregamento("Nome Deslacre");
        checklist.setAssinaturaRespDeslacrePosCarregamento("Assinatura Deslacre");
        checklist.setNLacreArmador("LacreArmador");
        checklist.setNLacreRfb("LacreRFB");
        checklist.setObservacoesGerais("Obs Gerais");
        checklist.setProvidenciasTomadas("Providencias");
        checklist.setNomeRespInspecao("Nome Inspetor");
        checklist.setAssinaturaRespInspecao("Assinatura Inspetor");
        checklist.setAssinaturaMotorista("Assinatura Motorista");

        TipoInspecaoModalidadeLookup tipoInspecao = new TipoInspecaoModalidadeLookup();
        tipoInspecao.setId(1);
        tipoInspecao.setDescricao("Rodoviário");
        checklist.setTipoInspecaoModalidade(tipoInspecao);

        OperacaoLookup operacao = new OperacaoLookup();
        operacao.setId(1);
        operacao.setDescricao("Verde");
        checklist.setOperacao(operacao);

        // CORREÇÃO AQUI: Popula TipoUnidadeLookup com ID e Descrição
        TipoUnidadeLookup tipoUnidade = new TipoUnidadeLookup();
        tipoUnidade.setId(1); // Ou outro ID relevante
        tipoUnidade.setDescricao("Container"); // Ou outra descrição relevante
        checklist.setTipoUnidade(tipoUnidade);
        
        // Crie itens de checklist associados à entidade
        ChecklistItem item = new ChecklistItem();
        item.setId(1L);
        item.setChecklist(checklist);
        item.setObservacoes("Observação item 1");
        PontoVerificacao pontoVerificacao = new PontoVerificacao();
        pontoVerificacao.setId(11);
        pontoVerificacao.setDescricao("Pneus");
        item.setPontoVerificacao(pontoVerificacao);
        StatusConformidadeLookup statusConformidade = new StatusConformidadeLookup();
        statusConformidade.setId(2);
        statusConformidade.setDescricao("Não Conforme");
        item.setStatusConformidade(statusConformidade);
        item.setEvidencias(Arrays.asList(new Evidencia()));
        checklist.setItens(Arrays.asList(item));

        // Crie lacre de saída associado
        LacreSaida lacreSaida = new LacreSaida();
        lacreSaida.setId(1L);
        lacreSaida.setChecklist(checklist);
        lacreSaida.setNomeRespVerificacao("Resp Verif");
        lacreSaida.setAssinaturaRespVerificacao("Assinatura Resp");
        lacreSaida.setDataSaida(LocalDate.of(2025, 6, 11));
        LacreRfbLookup lacreRfb = new LacreRfbLookup();
        lacreRfb.setId(2);
        lacreRfb.setDescricao("OK");
        lacreSaida.setLacreRfb(lacreRfb);
        LacreArmadorPosUnitizacaoLookup lacreArmador = new LacreArmadorPosUnitizacaoLookup();
        lacreArmador.setId(2);
        lacreArmador.setDescricao("OK");
        lacreSaida.setLacreArmadorPosUnitizacao(lacreArmador);
        FitaLacreUagaCompartimentoLookup fitaLacre = new FitaLacreUagaCompartimentoLookup();
        fitaLacre.setId(1);
        fitaLacre.setDescricao("N/A");
        lacreSaida.setFitaLacreUagaCompartimento(fitaLacre);
        checklist.setLacreSaida(lacreSaida);

        return checklist;
    }

    // --- Testes para o método createChecklist ---

    @Test
    void createChecklist_shouldCreateAndReturnChecklist() {
        // Dado
        CreateChecklistDto createDto = createSampleCreateChecklistDto();
        Checklist checklistEntity = createSampleChecklistEntity(1L); // Entidade que o repo retornaria

        // Mocks para as lookups (retornam uma entidade completa, não apenas Optional.of(new Lookup()))
        when(tipoInspecaoModalidadeLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getTipoInspecaoModalidade()));
        when(operacaoLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getOperacao()));
        when(tipoUnidadeLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getTipoUnidade()));
        when(pontoVerificacaoRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getItens().get(0).getPontoVerificacao()));
        when(statusConformidadeLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getItens().get(0).getStatusConformidade()));
        when(lacreRfbLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getLacreSaida().getLacreRfb()));
        when(lacreArmadorPosUnitizacaoLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getLacreSaida().getLacreArmadorPosUnitizacao()));
        when(fitaLacreUagaCompartimentoLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getLacreSaida().getFitaLacreUagaCompartimento()));


        // Mocks para saves
        when(checklistRepository.save(any(Checklist.class))).thenReturn(checklistEntity); // Retorna a entidade salva
        when(checklistItemRepository.save(any(ChecklistItem.class))).thenAnswer(invocation -> {
            ChecklistItem item = invocation.getArgument(0);
            item.setId(1L); // Simula o ID gerado para o item
            return item;
        });
        when(evidenciaRepository.saveAll(anyList())).thenReturn(Collections.emptyList()); // Ou uma lista de Evidencia mock
        when(lacreSaidaRepository.save(any(LacreSaida.class))).thenAnswer(invocation -> {
            LacreSaida lacre = invocation.getArgument(0);
            lacre.setId(1L); // Simula o ID gerado para o lacre
            return lacre;
        });
        
        // CORREÇÃO: Remove a linha desnecessária que causava UnnecessaryStubbingException
        // A linha abaixo foi removida:
        // when(checklistRepository.findById(any(Long.class))).thenReturn(Optional.of(checklistEntity));


        // Quando
        ChecklistResponseDto result = checklistService.createChecklist(createDto);

        // Então
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Nome Inspetor", result.getNomeRespInspecao());
        assertNotNull(result.getItens());
        assertFalse(result.getItens().isEmpty());
        assertNotNull(result.getLacreSaida());

        // Verifica se os métodos do repositório foram chamados
        verify(checklistRepository, times(1)).save(any(Checklist.class));
        verify(checklistItemRepository, times(createDto.getItens().size())).save(any(ChecklistItem.class));
        verify(evidenciaRepository, times(1)).saveAll(anyList());
        verify(lacreSaidaRepository, times(1)).save(any(LacreSaida.class));
    }

    @Test
    void createChecklist_shouldThrowException_whenLookupNotFound() {
        // Dado
        CreateChecklistDto createDto = createSampleCreateChecklistDto();
        
        // Quando uma lookup específica não é encontrada
        when(tipoInspecaoModalidadeLookupRepository.findById(any(Integer.class))).thenReturn(Optional.empty());

        // Então
        assertThrows(ResponseStatusException.class, () -> checklistService.createChecklist(createDto)); // Espera ResponseStatusException
        verify(checklistRepository, never()).save(any(Checklist.class));
    }

    // --- Testes para o método getAllChecklists ---

    @Test
    void getAllChecklists_shouldReturnAllChecklists() {
        // Dado
        List<Checklist> checklists = Arrays.asList(createSampleChecklistEntity(1L), createSampleChecklistEntity(2L));
        when(checklistRepository.findAll()).thenReturn(checklists);

        // Quando
        List<ChecklistResponseDto> result = checklistService.getAllChecklists();

        // Então
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getId());
        assertEquals(2L, result.get(1).getId());
        verify(checklistRepository, times(1)).findAll();
    }

    @Test
    void getAllChecklists_shouldReturnEmptyList_whenNoChecklistsExist() {
        // Dado
        when(checklistRepository.findAll()).thenReturn(Collections.emptyList());

        // Quando
        List<ChecklistResponseDto> result = checklistService.getAllChecklists();

        // Então
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(checklistRepository, times(1)).findAll();
    }

    // --- Testes para o método getChecklistById ---

    @Test
    void getChecklistById_shouldReturnChecklistWhenFound() {
        // Dado
        Long id = 1L;
        Checklist checklistEntity = createSampleChecklistEntity(id);
        when(checklistRepository.findById(id)).thenReturn(Optional.of(checklistEntity));

        // Quando
        ChecklistResponseDto result = checklistService.getChecklistById(id);

        // Então
        assertNotNull(result);
        assertEquals(id, result.getId());
        verify(checklistRepository, times(1)).findById(id);
    }

    @Test
    void getChecklistById_shouldThrowNotFoundExceptionWhenNotFound() {
        // Dado
        Long id = 99L;
        when(checklistRepository.findById(id)).thenReturn(Optional.empty());

        // Então
        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.getChecklistById(id));
        assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
        assertEquals("Checklist not found with ID: " + id, exception.getReason());
        verify(checklistRepository, times(1)).findById(id);
    }

    // --- Testes para o método updateChecklist ---

    @Test
    void updateChecklist_shouldReturnUpdatedChecklist() {
        // Dado
        Long id = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Updated General Observations");
        updateDto.setNomeRespInspecao("Updated Inspector Name");
        updateDto.setTipoUnidadeId(2); // Baú

        Checklist existingChecklist = createSampleChecklistEntity(id); // Simula o estado atual do BD
        // Prepare a entidade atualizada que o serviço retornaria após o save
        Checklist updatedEntity = createSampleChecklistEntity(id);
        updatedEntity.setObservacoesGerais("Updated General Observations");
        updatedEntity.setNomeRespInspecao("Updated Inspector Name");
        
        // CORREÇÃO AQUI: Popula a TipoUnidadeLookup da updatedEntity com o ID e descrição corretos para o cenário do teste
        TipoUnidadeLookup updatedTipoUnidade = new TipoUnidadeLookup(); 
        updatedTipoUnidade.setId(updateDto.getTipoUnidadeId()); // ID do DTO de update (2)
        updatedTipoUnidade.setDescricao("Baú"); // Descrição esperada para o ID 2
        updatedEntity.setTipoUnidade(updatedTipoUnidade);


        // Mocks
        when(checklistRepository.findById(id)).thenReturn(Optional.of(existingChecklist));
        // O mock deve retornar o objeto TipoUnidadeLookup com o ID e descrição correta
        when(tipoUnidadeLookupRepository.findById(any(Integer.class))).thenReturn(Optional.of(updatedTipoUnidade)); 
        when(checklistRepository.save(any(Checklist.class))).thenReturn(updatedEntity); // Retorna a entidade atualizada

        // Quando
        ChecklistResponseDto result = checklistService.updateChecklist(id, updateDto);

        // Então
        assertNotNull(result);
        assertEquals(id, result.getId());
        assertEquals("Updated General Observations", result.getObservacoesGerais());
        assertEquals("Updated Inspector Name", result.getNomeRespInspecao());
        assertNotNull(result.getTipoUnidade()); // Verifica se o lookup foi mapeado no DTO de resposta
        assertEquals("Baú", result.getTipoUnidade().getDescricao()); // Verifica a descrição do lookup

        verify(checklistRepository, times(1)).findById(id);
        verify(checklistRepository, times(1)).save(any(Checklist.class));
        verify(tipoUnidadeLookupRepository, times(1)).findById(any(Integer.class));
    }

    @Test
    void updateChecklist_shouldThrowNotFoundException_whenChecklistToUpdateDoesNotExist() {
        // Dado
        Long nonExistentId = 99L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Test update");

        // Quando
        when(checklistRepository.findById(nonExistentId)).thenReturn(Optional.empty());

        // Então
        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.updateChecklist(nonExistentId, updateDto));
        assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
        assertEquals("Checklist not found with ID: " + nonExistentId, exception.getReason());
        verify(checklistRepository, times(1)).findById(nonExistentId);
        verify(checklistRepository, never()).save(any(Checklist.class));
    }

    @Test
    void updateChecklist_shouldThrowBadRequest_whenLookupNotFoundDuringUpdate() {
        // Dado
        Long id = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setTipoInspecaoModalidadeId(99); // ID de lookup inexistente

        Checklist existingChecklist = createSampleChecklistEntity(id);

        // Quando
        when(checklistRepository.findById(id)).thenReturn(Optional.of(existingChecklist));
        // AQUI: Mockando o repositório específico da lookup que falharia
        when(tipoInspecaoModalidadeLookupRepository.findById(any(Integer.class))).thenReturn(Optional.empty());

        // Então
        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.updateChecklist(id, updateDto));
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
        assertTrue(exception.getReason().contains("Inspection Modality Type not found."));

        verify(checklistRepository, times(1)).findById(id);
        verify(checklistRepository, never()).save(any(Checklist.class));
    }


    // --- Testes para o método deleteChecklist ---

    @Test
    void deleteChecklist_shouldDeleteChecklistWhenFound() {
        // Dado
        Long id = 1L;
        when(checklistRepository.existsById(id)).thenReturn(true);

        // Quando
        checklistService.deleteChecklist(id);

        // Então
        verify(checklistRepository, times(1)).existsById(id);
        verify(checklistRepository, times(1)).deleteById(id);
    }

    @Test
    void deleteChecklist_shouldThrowNotFoundExceptionWhenNotFound() {
        // Dado
        Long id = 99L;
        when(checklistRepository.existsById(id)).thenReturn(false);

        // Então
        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.deleteChecklist(id));
        assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
        assertEquals("Checklist not found with ID: " + id, exception.getReason());
        verify(checklistRepository, times(1)).existsById(id);
        verify(checklistRepository, never()).deleteById(any(Long.class));
    }
    
}