package com.uaga.checklist;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.ChecklistItemDto;
import com.uaga.checklist.dto.LacreSaidaDto;
import com.uaga.checklist.dto.EvidenciaDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.ChecklistResponseDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.http.MediaType;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class ChecklistE2ETest {

    @Autowired
    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    private static Long createdChecklistId;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    private CreateChecklistDto createSampleCreateChecklistDto() {
        // Usando LocalDateTime.now() e LocalDate.now() para garantir que as datas não sejam futuras.
        // Adicionando um pequeno delta de tempo para 'dataHoraTermino' para ser posterior à 'dataHoraInicio'.
        LocalDateTime now = LocalDateTime.now().minusSeconds(1); // Garante que a data de início é um pouco no passado
        LocalDate today = LocalDate.now();

        EvidenciaDto evidenciaDto = new EvidenciaDto("https://example.com/foto1_e2e.jpg", "Rachadura na parede detectada em E2E");
        
        ChecklistItemDto itemDto = new ChecklistItemDto(11, 2, "Observação item 1 E2E", Arrays.asList(evidenciaDto)); 
        
        // Garantir que todos os campos do LacreSaidaDto sejam populados para evitar nulls
        LacreSaidaDto lacreSaidaDto = new LacreSaidaDto(
            2, // lacreRfbId (2 para OK)
            2, // lacreArmadorPosUnitizacaoId (2 para OK)
            1, // fitaLacreUagaCompartimentoId (1 para N/A)
            "Resp Verif E2E", 
            "Assinatura Resp E2E", 
            today // dataSaida = hoje
        );

        return new CreateChecklistDto(
                now, // dataHoraInicio = agora (ou um pouco no passado)
                now.plusMinutes(45), // dataHoraTermino (45 minutos depois de agora)
                1, // tipoInspecaoModalidadeId (1 para Rodoviário)
                1, // operacaoId (1 para Verde)
                1, // tipoUnidadeId (1 para Container)
                "LacreUaga1_E2E", // nLacreUagaPosInspecao
                "LacreUaga2_E2E", // nLacreUagaPosCarregamento
                "Nome Lacre E2E", // nomeRespLacre
                "Assinatura Lacre E2E", // assinaturaRespLacre
                "Nome Deslacre E2E", // nomeRespDeslacrePosCarregamento
                "Assinatura Deslacre E2E", // assinaturaRespDeslacrePosCarregamento
                "LacreArmador_E2E", // nLacreArmador
                "LacreRFB_E2E", // nLacreRfb
                "Obs Gerais E2E", // observacoesGerais
                "Providencias E2E", // providenciasTomadas
                "Nome Inspetor E2E", // nomeRespInspecao (NotBlank)
                "Assinatura Inspetor E2E", // assinaturaRespInspecao (NotBlank)
                "Assinatura Motorista E2E", // assinaturaMotorista
                Arrays.asList(itemDto), // itens (NotEmpty, NotNull, Valid)
                lacreSaidaDto // lacresSaida (NotNull, Valid)
        );
    }

    @Test
    @Order(1)
    @Transactional
    void createChecklist_shouldCreateChecklistSuccessfully() throws Exception {
        CreateChecklistDto createDto = createSampleCreateChecklistDto();

        MvcResult result = mockMvc.perform(post("/api/checklists")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.nomeRespInspecao").value("Nome Inspetor E2E"))
                .andReturn();

        String responseString = result.getResponse().getContentAsString();
        ChecklistResponseDto responseDto = objectMapper.readValue(responseString, ChecklistResponseDto.class);
        createdChecklistId = responseDto.getId();
        assertNotNull(createdChecklistId);
        System.out.println("Checklist E2E criado com ID: " + createdChecklistId);
    }

    @Test
    @Order(2)
    @Transactional
    void getChecklistById_shouldReturnChecklist() throws Exception {
        assertNotNull(createdChecklistId, "ID do checklist não foi criado no teste anterior.");

        mockMvc.perform(get("/api/checklists/{id}", createdChecklistId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(createdChecklistId))
                .andExpect(jsonPath("$.nomeRespInspecao").value("Nome Inspetor E2E"))
                .andExpect(jsonPath("$.itens[0].pontoVerificacao.descricao").value("Pneus"))
                .andExpect(jsonPath("$.lacreSaida.dataSaida").value(LocalDate.now().toString())); 
    }

    @Test
    @Order(3)
    @Transactional
    void getChecklistById_shouldReturnNotFound_whenDoesNotExist() throws Exception {
        Long nonExistentId = 9999L;

        mockMvc.perform(get("/api/checklists/{id}", nonExistentId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @Order(4)
    @Transactional
    void getAllChecklists_shouldReturnListOfChecklists() throws Exception {
        mockMvc.perform(get("/api/checklists")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray())
                .andExpect(jsonPath("$.length()").value(1));
    }

    @Test
    @Order(5)
    @Transactional
    void updateChecklist_shouldUpdateChecklistSuccessfully() throws Exception {
        assertNotNull(createdChecklistId, "ID do checklist não foi criado no teste anterior.");

        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Observações atualizadas E2E");
        updateDto.setNomeRespInspecao("Inspetor Atualizado E2E");
        updateDto.setTipoUnidadeId(2); // Muda para Baú

        mockMvc.perform(put("/api/checklists/{id}", createdChecklistId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(createdChecklistId))
                .andExpect(jsonPath("$.observacoesGerais").value("Observações atualizadas E2E"))
                .andExpect(jsonPath("$.nomeRespInspecao").value("Inspetor Atualizado E2E"))
                .andExpect(jsonPath("$.tipoUnidade.descricao").value("Baú"));
    }

    @Test
    @Order(6)
    @Transactional
    void updateChecklist_shouldReturnNotFound_whenDoesNotExist() throws Exception {
        Long nonExistentId = 9999L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Update non-existent");

        mockMvc.perform(put("/api/checklists/{id}", nonExistentId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateDto)))
                .andExpect(status().isNotFound());
    }

    @Test
    @Order(7)
    @Transactional
    void deleteChecklist_shouldDeleteChecklistSuccessfully() throws Exception {
        assertNotNull(createdChecklistId, "ID do checklist não foi criado no teste anterior.");

        mockMvc.perform(delete("/api/checklists/{id}", createdChecklistId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/checklists/{id}", createdChecklistId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    @Test
    @Order(8)
    @Transactional
    void deleteChecklist_shouldReturnNotFound_whenDoesNotExist() throws Exception {
        Long nonExistentId = 9999L;

        mockMvc.perform(delete("/api/checklists/{id}", nonExistentId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }
}
