package com.uaga.checklist.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.ChecklistItemDto;
import com.uaga.checklist.dto.LacreSaidaDto;
import com.uaga.checklist.dto.EvidenciaDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.*;
import com.uaga.checklist.service.ChecklistService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus; // Import HttpStatus
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.server.ResponseStatusException; // Import ResponseStatusException

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ChecklistController.class)
public class ChecklistControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private ChecklistService checklistService;

    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());
        objectMapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
    }

    private CreateChecklistDto createSampleCreateChecklistDto() {
        EvidenciaDto evidenciaDto = new EvidenciaDto("https://example.com/foto1.jpg", "Rachadura na parede");
        ChecklistItemDto itemDto = new ChecklistItemDto(1, 2, "Observação item 1", Arrays.asList(evidenciaDto));
        LacreSaidaDto lacreSaidaDto = new LacreSaidaDto(2, 2, 1, "Resp Verif", "Assinatura Resp", LocalDate.of(2025, 6, 11));

        return new CreateChecklistDto(
                LocalDateTime.of(2025, 6, 11, 10, 0, 0),
                LocalDateTime.of(2025, 6, 11, 10, 30, 0),
                1, 1, 1, "LacreUaga1", "LacreUaga2", "Nome Lacre", "Assinatura Lacre",
                "Nome Deslacre", "Assinatura Deslacre", "LacreArmador", "LacreRFB",
                "Obs Gerais", "Providencias", "Nome Inspetor", "Assinatura Inspetor", "Assinatura Motorista",
                Arrays.asList(itemDto), lacreSaidaDto
        );
    }

    private ChecklistResponseDto createSampleChecklistResponseDto(Long id) {
        TipoInspecaoModalidadeResponseDto tipoInspecao = new TipoInspecaoModalidadeResponseDto(1, "Rodoviário");
        OperacaoResponseDto operacao = new OperacaoResponseDto(1, "Verde");
        TipoUnidadeResponseDto tipoUnidade = new TipoUnidadeResponseDto(1, "Container");

        PontoVerificacaoResponseDto pontoVerificacao = new PontoVerificacaoResponseDto(11, "Pneus");
        StatusConformidadeResponseDto statusConformidade = new StatusConformidadeResponseDto(2, "Não Conforme");
        EvidenciaResponseDto evidencia = new EvidenciaResponseDto(1L, "https://example.com/foto1.jpg", "Rachadura na parede");
        ChecklistItemResponseDto item = new ChecklistItemResponseDto(1L, "Observação item 1", pontoVerificacao, statusConformidade, Arrays.asList(evidencia));

        LacreRfbResponseDto lacreRfb = new LacreRfbResponseDto(2, "OK");
        LacreArmadorPosUnitizacaoResponseDto lacreArmador = new LacreArmadorPosUnitizacaoResponseDto(2, "OK");
        FitaLacreUagaCompartimentoResponseDto fitaLacre = new FitaLacreUagaCompartimentoResponseDto(1, "N/A");
        LacreSaidaResponseDto lacreSaida = new LacreSaidaResponseDto(1L, "Resp Verif", "Assinatura Resp", LocalDate.of(2025, 6, 11), lacreRfb, lacreArmador, fitaLacre);

        return new ChecklistResponseDto(
                id,
                LocalDateTime.of(2025, 6, 11, 10, 0, 0),
                LocalDateTime.of(2025, 6, 11, 10, 30, 0),
                "LacreUaga1",
                "LacreUaga2",
                "Nome Lacre",
                "Assinatura Lacre",
                "Nome Deslacre",
                "Assinatura Deslacre",
                "LacreArmador",
                "LacreRFB",
                "Obs Gerais",
                "Providencias",
                "Nome Inspetor",
                "Assinatura Inspetor",
                "Assinatura Motorista",
                tipoInspecao,
                operacao,
                tipoUnidade,
                Arrays.asList(item),
                lacreSaida
        );
    }

    // --- Testes para o Endpoint POST /api/checklists ---

    @Test
    void createChecklist_shouldReturnCreatedChecklist() throws Exception {
        CreateChecklistDto createDto = createSampleCreateChecklistDto();
        ChecklistResponseDto responseDto = createSampleChecklistResponseDto(1L);

        when(checklistService.createChecklist(any(CreateChecklistDto.class))).thenReturn(responseDto);

        mockMvc.perform(post("/api/checklists")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(createDto)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.nomeRespInspecao").value("Nome Inspetor"))
                .andExpect(jsonPath("$.itens[0].observacoes").value("Observação item 1"));
    }

    @Test
    void createChecklist_shouldReturnBadRequest_whenValidationFails() throws Exception {
        CreateChecklistDto invalidDto = new CreateChecklistDto();
        invalidDto.setNomeRespInspecao("");

        mockMvc.perform(post("/api/checklists")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidDto)))
                .andExpect(status().isBadRequest());
    }

    // --- Testes para o Endpoint GET /api/checklists ---

    @Test
    void getAllChecklists_shouldReturnListOfChecklists() throws Exception {
        ChecklistResponseDto checklist1 = createSampleChecklistResponseDto(1L);
        ChecklistResponseDto checklist2 = createSampleChecklistResponseDto(2L);
        List<ChecklistResponseDto> allChecklists = Arrays.asList(checklist1, checklist2);

        when(checklistService.getAllChecklists()).thenReturn(allChecklists);

        mockMvc.perform(get("/api/checklists")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1L))
                .andExpect(jsonPath("$[1].id").value(2L))
                .andExpect(jsonPath("$.length()").value(2));
    }

    @Test
    void getAllChecklists_shouldReturnEmptyList_whenNoChecklistsExist() throws Exception {
        List<ChecklistResponseDto> emptyList = Collections.emptyList();
        when(checklistService.getAllChecklists()).thenReturn(emptyList);
        mockMvc.perform(get("/api/checklists")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(0));
    }

    // --- Testes para o Endpoint GET /api/checklists/{id} ---

    @Test
    void getChecklistById_shouldReturnChecklist() throws Exception {
        Long checklistId = 1L;
        ChecklistResponseDto responseDto = createSampleChecklistResponseDto(checklistId);
        when(checklistService.getChecklistById(checklistId)).thenReturn(responseDto);
        mockMvc.perform(get("/api/checklists/{id}", checklistId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(checklistId))
                .andExpect(jsonPath("$.nomeRespInspecao").value("Nome Inspetor"));
    }

    @Test
    void getChecklistById_shouldReturnNotFound_whenChecklistDoesNotExist() throws Exception {
        Long nonExistentId = 99L;
        // MOCKANDO O SERVIÇO PARA LANÇAR ResponseStatusException
        doThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found")).when(checklistService).getChecklistById(nonExistentId);

        mockMvc.perform(get("/api/checklists/{id}", nonExistentId)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound());
    }

    // --- Testes para o Endpoint PUT /api/checklists/{id} ---

    @Test
    void updateChecklist_shouldReturnUpdatedChecklist() throws Exception {
        Long checklistId = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Novas observações gerais");
        ChecklistResponseDto updatedResponseDto = createSampleChecklistResponseDto(checklistId);
        updatedResponseDto.setObservacoesGerais("Novas observações gerais");

        when(checklistService.updateChecklist(eq(checklistId), any(UpdateChecklistDto.class)))
                .thenReturn(updatedResponseDto);

        mockMvc.perform(put("/api/checklists/{id}", checklistId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateDto)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(checklistId))
                .andExpect(jsonPath("$.observacoesGerais").value("Novas observações gerais"));
    }
    
    @Test
    void updateChecklist_shouldReturnNotFound_whenChecklistToUpdateDoesNotExist() throws Exception {
        Long nonExistentId = 99L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Update on non-existent");

        // MOCKANDO O SERVIÇO PARA LANÇAR ResponseStatusException
        doThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found")).when(checklistService).updateChecklist(eq(nonExistentId), any(UpdateChecklistDto.class));

        mockMvc.perform(put("/api/checklists/{id}", nonExistentId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateDto)))
                .andExpect(status().isNotFound());
    }

    // --- Testes para o Endpoint DELETE /api/checklists/{id} ---

    @Test
    void deleteChecklist_shouldReturnNoContent() throws Exception {
        Long checklistId = 1L;
        doNothing().when(checklistService).deleteChecklist(checklistId);
        mockMvc.perform(delete("/api/checklists/{id}", checklistId))
                .andExpect(status().isNoContent());
    }

    @Test
    void deleteChecklist_shouldReturnNotFound_whenChecklistToDeleteDoesNotExist() throws Exception {
        Long nonExistentId = 99L;
        // MOCKANDO O SERVIÇO PARA LANÇAR ResponseStatusException
        doThrow(new ResponseStatusException(HttpStatus.NOT_FOUND, "Checklist not found")).when(checklistService).deleteChecklist(nonExistentId);

        mockMvc.perform(delete("/api/checklists/{id}", nonExistentId))
                .andExpect(status().isNotFound());
    }
}
