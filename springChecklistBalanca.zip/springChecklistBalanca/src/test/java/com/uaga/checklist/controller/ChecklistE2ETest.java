package com.uaga.checklist.controller;

import com.uaga.checklist.AbstractIntegrationTest;
import com.uaga.checklist.dto.response.ChecklistResponseDto;
import com.uaga.checklist.entity.Checklist;
import com.uaga.checklist.repository.ChecklistRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class ChecklistE2ETest extends AbstractIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private ChecklistRepository checklistRepository;

    @BeforeEach
    void setUp() {
        // Limpa o repositório antes de cada teste para garantir a independência
        checklistRepository.deleteAll();
    }


    @Test
    void createChecklist_whenValidBody_shouldSaveAndReturnCreated() {
        String requestBody = createChecklistRequestBody("Ricardo Mendes", false); // false = não finalizado
        HttpEntity<String> requestEntity = createRequestEntity(requestBody);

        ResponseEntity<ChecklistResponseDto> response = restTemplate.exchange(
                getBaseUrl(), HttpMethod.POST, requestEntity, ChecklistResponseDto.class
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        ChecklistResponseDto responseBody = response.getBody();
        assertThat(responseBody).isNotNull();
        assertThat(responseBody.getId()).isNotNull();
        assertThat(responseBody.getNomeRespInspecao()).isEqualTo("Ricardo Mendes");

        Optional<Checklist> savedChecklistOpt = checklistRepository.findById(responseBody.getId());
        assertThat(savedChecklistOpt).isPresent();
        assertThat(savedChecklistOpt.get().getNomeRespInspecao()).isEqualTo("Ricardo Mendes");
    }

    @Test
    void getChecklistById_whenChecklistExists_shouldReturnChecklist() {
        ChecklistResponseDto createdChecklist = createTestChecklist("Inspetor GET by ID");
        Long checklistId = createdChecklist.getId();

        ResponseEntity<ChecklistResponseDto> response = restTemplate.getForEntity(
                getBaseUrl() + "/{id}", ChecklistResponseDto.class, checklistId
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        ChecklistResponseDto foundChecklist = response.getBody();
        assertThat(foundChecklist).isNotNull();
        assertThat(foundChecklist.getId()).isEqualTo(checklistId);
    }

    @Test
    void getChecklistById_whenChecklistDoesNotExist_shouldReturnNotFound() {
        ResponseEntity<Void> response = restTemplate.getForEntity(
                getBaseUrl() + "/{id}", Void.class, 999L
        );
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
    }

    @Test
    void getAllChecklists_shouldReturnAllCreatedChecklists() {
        createTestChecklist("Primeiro Inspetor");
        createTestChecklist("Segundo Inspetor");

        ResponseEntity<List<ChecklistResponseDto>> response = restTemplate.exchange(
                getBaseUrl(),
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<>() {}
        );

        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        List<ChecklistResponseDto> checklists = response.getBody();
        assertThat(checklists).isNotNull().hasSize(2);
    }

    // --- NOVOS TESTES PARA OS ENDPOINTS PUT ---

    @Test
    void updateChecklist_whenSimpleField_shouldSucceed() {
        // ARRANGE: Cria um checklist inicial
        ChecklistResponseDto createdChecklist = createTestChecklist("Inspetor Original");
        Long checklistId = createdChecklist.getId();

        // Cria o corpo da requisição de atualização
        String updateBody = """
        {
          "observacoesGerais": "Observação foi atualizada com sucesso."
        }
        """;
        HttpEntity<String> requestEntity = createRequestEntity(updateBody);

        // ACT: Executa a requisição PUT
        ResponseEntity<ChecklistResponseDto> response = restTemplate.exchange(
                getBaseUrl() + "/{id}", HttpMethod.PUT, requestEntity, ChecklistResponseDto.class, checklistId
        );

        // ASSERT: Verifica o sucesso da operação
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody().getObservacoesGerais()).isEqualTo("Observação foi atualizada com sucesso.");

        // Verifica diretamente no banco de dados
        Checklist updatedChecklist = checklistRepository.findById(checklistId).orElseThrow();
        assertThat(updatedChecklist.getObservacoesGerais()).isEqualTo("Observação foi atualizada com sucesso.");
    }
    
    @Test
    void updateChecklist_whenFinalizingWithIncompleteItems_shouldReturnBadRequest() {
        // ARRANGE: Cria um checklist com poucos itens (não os 18)
        ChecklistResponseDto createdChecklist = createTestChecklist("Inspetor Incompleto");
        Long checklistId = createdChecklist.getId();
    
        // Cria o corpo da requisição para tentar finalizar
        String updateBody = String.format("""
        {
          "dataHoraTermino": "%s"
        }
        """, LocalDateTime.now());
        HttpEntity<String> requestEntity = createRequestEntity(updateBody);
    
        // ACT
        ResponseEntity<Object> response = restTemplate.exchange(
                getBaseUrl() + "/{id}", HttpMethod.PUT, requestEntity, Object.class, checklistId
        );
    
        // ASSERT
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
    }


    // --- MÉTODOS AUXILIARES ---

    private String getBaseUrl() {
        return "http://localhost:" + port + "/api/checklists";
    }

    private HttpEntity<String> createRequestEntity(String body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new HttpEntity<>(body, headers);
    }
    
    // Método auxiliar para criar um checklist de teste simples via POST
    private ChecklistResponseDto createTestChecklist(String inspectorName) {
        String requestBody = createChecklistRequestBody(inspectorName, false); // false = não finalizado
        ResponseEntity<ChecklistResponseDto> response = restTemplate.postForEntity(
                getBaseUrl(), createRequestEntity(requestBody), ChecklistResponseDto.class
        );
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.CREATED);
        return response.getBody();
    }

    // Método auxiliar que gera o corpo JSON para a criação de um checklist
    private String createChecklistRequestBody(String inspectorName, boolean isFinal) {
        // Se for para um teste de finalização, poderia ter mais lógica para adicionar todos os 18 itens, etc.
        // Por agora, vamos manter simples.
        String dataTerminoJson = isFinal ? String.format("\"dataHoraTermino\": \"%s\",", LocalDateTime.now()) : "";

        return String.format("""
        {
          "dataHoraInicio": "2025-06-13T15:00:00",
          %s
          "tipoInspecaoModalidadeId": 101, "operacaoId": 201, "tipoUnidadeId": 301,
          "nomeRespInspecao": "%s",
          "assinaturaRespInspecao": "data:image/png;base64,iVBOR...",
          "itens": [{"pontoVerificacaoId": 1, "statusConformidadeId": 401, "observacoes": "OK", "evidencias": []}],
          "lacresSaida": {"lacreRfbId": 2, "lacreArmadorPosUnitizacaoId": 2, "fitaLacreUagaCompartimentoId": 1, "nomeRespVerificacao": "Resp", "assinaturaRespVerificacao": "data:image/png;base64,iVBOR...", "dataSaida": "2025-06-13"}
        }
        """, dataTerminoJson, inspectorName);
    }
}
