#!/bin/bash

# Carrega as variáveis do .env no shell atual
# Isso permite que os comandos subsequentes acessem $BDPASS, $BDDATABASE, etc.
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
else
    echo "Erro: Arquivo .env não encontrado!"
    exit 1
fi

# Define o nome da imagem e do contêiner para consistência
# Usando o nome "UagaMysql" para a imagem e o contêiner
IMAGE_NAME="uagamysql-db" # Mantém o nome da imagem como você já construiu
CONTAINER_NAME="UagaMysql"      # Novo nome para o contêiner

echo "Iniciando o contêiner Podman para o MySQL..."
echo "Nome do Banco de Dados: $BDDATABASE"
echo "Porta: $BDPORT"
echo "Nome do Contêiner: $CONTAINER_NAME"
echo "Nome da Imagem: $IMAGE_NAME"

# Rodar o contêiner usando as variáveis de ambiente carregadas
podman run --name $CONTAINER_NAME \
  -p ${BDPORT:-3306}:3306 \
  -e MYSQL_ROOT_PASSWORD=$BDPASS \
  -e MYSQL_DATABASE=$BDDATABASE \
  -d $IMAGE_NAME

if [ $? -eq 0 ]; then
    echo "Contêiner '$CONTAINER_NAME' iniciado com sucesso!"
    echo "Você pode verificar com: podman ps -a"
    echo "Para acessar o shell do MySQL: podman exec -it $CONTAINER_NAME mysql -u root -p"
else
    echo "Erro ao iniciar o contêiner '$CONTAINER_NAME'."
    echo "Verifique as mensagens de erro acima."
fi



uagamysql-db-image

$ podman run --name UagaMysql \
  -p 3306:3306 \
  -e MYSQL_ROOT_PASSWORD=my_secret_password \
  -e MYSQL_DATABASE=UagaBD \
  -d uagamysql-db-image
eeff74ecca3170dc7c43a3eee6df16cc9f7fe8d91a90841fb02882a922e353ae