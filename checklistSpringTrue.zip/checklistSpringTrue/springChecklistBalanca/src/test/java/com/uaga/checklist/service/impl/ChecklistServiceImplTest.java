package com.uaga.checklist.service.impl;

import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.ChecklistItemDto;
import com.uaga.checklist.dto.LacreSaidaDto;
import com.uaga.checklist.dto.EvidenciaDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.*;
import com.uaga.checklist.entity.*;
import com.uaga.checklist.repository.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class) // Habilita o uso de Mockito para testes JUnit 5
public class ChecklistServiceImplTest {

    @Mock
    private ChecklistRepository checklistRepository;
    @Mock
    private ChecklistItemRepository checklistItemRepository;
    @Mock
    private EvidenciaRepository evidenciaRepository;
    @Mock
    private LacreSaidaRepository lacreSaidaRepository;
    @Mock
    private PontoVerificacaoRepository pontoVerificacaoRepository;
    @Mock
    private LookupValueDataRepository lookupValueDataRepository; // Mock para a tabela única de lookup

    @InjectMocks // Injeta os mocks criados acima na instância real do serviço
    private ChecklistServiceImpl checklistService;

    // --- Métodos Auxiliares para criação de DTOs e Entidades para Testes ---

    private CreateChecklistDto createSampleCreateChecklistDto() {
        EvidenciaDto evidenciaDto = new EvidenciaDto("https://example.com/foto1.jpg", "Rachadura na parede");
        ChecklistItemDto itemDto = new ChecklistItemDto(11, 402, "Observação item 1", Arrays.asList(evidenciaDto)); // StatusConformidade ID 402 ("Não Conforme")
        LacreSaidaDto lacreSaidaDto = new LacreSaidaDto(2, 2, 1, "Resp Verif", "Assinatura Resp", LocalDate.of(2025, 6, 11)); // IDs de lookup comuns

        return new CreateChecklistDto(
                LocalDateTime.of(2025, 6, 11, 10, 0, 0),
                LocalDateTime.of(2025, 6, 11, 10, 30, 0),
                101, // TipoInspecaoModalidade ID 101 ("Rodoviário")
                201, // Operacao ID 201 ("Verde")
                301, // TipoUnidade ID 301 ("Container")
                "LacreUaga1", "LacreUaga2", "Nome Lacre", "Assinatura Lacre",
                "Nome Deslacre", "Assinatura Deslacre", "LacreArmador", "LacreRFB",
                "Obs Gerais", "Providencias", "Nome Inspetor", "Assinatura Inspetor", "Assinatura Motorista",
                Arrays.asList(itemDto), lacreSaidaDto
        );
    }

    private Checklist createSampleChecklistEntity(Long id) {
        Checklist checklist = new Checklist();
        checklist.setId(id);
        checklist.setDataHoraInicio(LocalDateTime.of(2025, 6, 11, 10, 0, 0));
        checklist.setDataHoraTermino(LocalDateTime.of(2025, 6, 11, 10, 30, 0));
        checklist.setNLacreUagaPosInspecao("LacreUaga1");
        checklist.setNLacreUagaPosCarregamento("LacreUaga2");
        checklist.setNomeRespLacre("Nome Lacre");
        checklist.setAssinaturaRespLacre("Assinatura Lacre");
        checklist.setNomeRespDeslacrePosCarregamento("Nome Deslacre");
        checklist.setAssinaturaRespDeslacrePosCarregamento("Assinatura Deslacre");
        checklist.setNLacreArmador("LacreArmador");
        checklist.setNLacreRfb("LacreRFB");
        checklist.setObservacoesGerais("Obs Gerais");
        checklist.setProvidenciasTomadas("Providencias");
        checklist.setNomeRespInspecao("Nome Inspetor");
        checklist.setAssinaturaRespInspecao("Assinatura Inspetor");
        checklist.setAssinaturaMotorista("Assinatura Motorista");

        // Lookups usando a nova entidade LookupValueData
        LookupValueData tipoInspecao = new LookupValueData(101, "TIPO_INSPECAO_MODALIDADE", "Rodoviário");
        checklist.setTipoInspecaoModalidade(tipoInspecao);

        LookupValueData operacao = new LookupValueData(201, "OPERACAO", "Verde");
        checklist.setOperacao(operacao);

        LookupValueData tipoUnidade = new LookupValueData(301, "TIPO_UNIDADE", "Container");
        checklist.setTipoUnidade(tipoUnidade);
        
        // Crie itens de checklist associados à entidade
        ChecklistItem item = new ChecklistItem();
        item.setId(1L);
        item.setChecklist(checklist);
        item.setObservacoes("Observação item 1");
        PontoVerificacao pontoVerificacao = new PontoVerificacao(11, "Pneus");
        item.setPontoVerificacao(pontoVerificacao);
        LookupValueData statusConformidade = new LookupValueData(402, "STATUS_CONFORMIDADE", "Não Conforme");
        item.setStatusConformidade(statusConformidade);
        item.setEvidencias(Arrays.asList(new Evidencia()));
        checklist.setItens(Arrays.asList(item));

        // Crie lacre de saída associado
        LacreSaida lacreSaida = new LacreSaida();
        lacreSaida.setId(1L);
        lacreSaida.setChecklist(checklist);
        lacreSaida.setNomeRespVerificacao("Resp Verif");
        lacreSaida.setAssinaturaRespVerificacao("Assinatura Resp");
        lacreSaida.setDataSaida(LocalDate.of(2025, 6, 11));
        
        LookupValueData lacreRfb = new LookupValueData(2, "COMUM", "OK");
        lacreSaida.setLacreRfb(lacreRfb);
        LookupValueData lacreArmador = new LookupValueData(2, "COMUM", "OK");
        lacreSaida.setLacreArmadorPosUnitizacao(lacreArmador);
        LookupValueData fitaLacre = new LookupValueData(1, "COMUM", "N/A");
        lacreSaida.setFitaLacreUagaCompartimento(fitaLacre);
        checklist.setLacreSaida(lacreSaida);

        return checklist;
    }

    // --- Testes para o método createChecklist ---

    @Test
    void createChecklist_shouldCreateAndReturnChecklist() {
        // Dado
        CreateChecklistDto createDto = createSampleCreateChecklistDto();
        Checklist checklistEntity = createSampleChecklistEntity(1L); // Entidade que o repo retornaria

        // Mocks para as lookups (agora usam LookupValueDataRepository)
        when(lookupValueDataRepository.findById(eq(createDto.getTipoInspecaoModalidadeId()))).thenReturn(Optional.of(checklistEntity.getTipoInspecaoModalidade()));
        when(lookupValueDataRepository.findById(eq(createDto.getOperacaoId()))).thenReturn(Optional.of(checklistEntity.getOperacao()));
        when(lookupValueDataRepository.findById(eq(createDto.getTipoUnidadeId()))).thenReturn(Optional.of(checklistEntity.getTipoUnidade()));
        
        when(pontoVerificacaoRepository.findById(any(Integer.class))).thenReturn(Optional.of(checklistEntity.getItens().get(0).getPontoVerificacao()));
        when(lookupValueDataRepository.findById(eq(createDto.getItens().get(0).getStatusConformidadeId()))).thenReturn(Optional.of(checklistEntity.getItens().get(0).getStatusConformidade()));
        
        // CORREÇÃO: Usando lenient() para o stubbing do ID 2, pois ele é chamado duas vezes no serviço (lacreRfb e lacreArmador)
        // Isso resolve o UnnecessaryStubbingException.
        lenient().when(lookupValueDataRepository.findById(eq(createDto.getLacresSaida().getLacreRfbId()))).thenReturn(Optional.of(checklistEntity.getLacreSaida().getLacreRfb())); 
        lenient().when(lookupValueDataRepository.findById(eq(createDto.getLacresSaida().getLacreArmadorPosUnitizacaoId()))).thenReturn(Optional.of(checklistEntity.getLacreSaida().getLacreArmadorPosUnitizacao()));
        when(lookupValueDataRepository.findById(eq(createDto.getLacresSaida().getFitaLacreUagaCompartimentoId()))).thenReturn(Optional.of(checklistEntity.getLacreSaida().getFitaLacreUagaCompartimento()));

        // Mocks para saves
        when(checklistRepository.save(any(Checklist.class))).thenReturn(checklistEntity);
        when(checklistItemRepository.save(any(ChecklistItem.class))).thenAnswer(invocation -> {
            ChecklistItem item = invocation.getArgument(0);
            item.setId(1L);
            return item;
        });
        when(evidenciaRepository.saveAll(anyList())).thenReturn(Collections.emptyList());
        when(lacreSaidaRepository.save(any(LacreSaida.class))).thenAnswer(invocation -> {
            LacreSaida lacre = invocation.getArgument(0);
            lacre.setId(1L);
            return lacre;
        });
        
        // Quando
        ChecklistResponseDto result = checklistService.createChecklist(createDto);

        // Então
        assertNotNull(result);
        assertEquals(1L, result.getId());
        assertEquals("Nome Inspetor", result.getNomeRespInspecao());
        assertNotNull(result.getItens());
        assertFalse(result.getItens().isEmpty());
        assertNotNull(result.getLacreSaida());

        // Verifica se os métodos do repositório foram chamados
        verify(checklistRepository, times(1)).save(any(Checklist.class));
        verify(checklistItemRepository, times(createDto.getItens().size())).save(any(ChecklistItem.class));
        verify(evidenciaRepository, times(1)).saveAll(anyList());
        verify(lacreSaidaRepository, times(1)).save(any(LacreSaida.class));
    }

    @Test
    void createChecklist_shouldThrowException_whenLookupNotFound() {
        // Dado
        CreateChecklistDto createDto = createSampleCreateChecklistDto();
        
        // Quando uma lookup específica não é encontrada (ex: tipoInspecaoModalidade)
        when(lookupValueDataRepository.findById(eq(createDto.getTipoInspecaoModalidadeId()))).thenReturn(Optional.empty());

        // Então
        assertThrows(ResponseStatusException.class, () -> checklistService.createChecklist(createDto));
        verify(checklistRepository, never()).save(any(Checklist.class));
    }

    // --- Testes para o método getAllChecklists ---

    @Test
    void getAllChecklists_shouldReturnAllChecklists() {
        // Dado
        List<Checklist> checklists = Arrays.asList(createSampleChecklistEntity(1L), createSampleChecklistEntity(2L));
        when(checklistRepository.findAllWithDetails()).thenReturn(checklists); // Usa o método customizado

        // Quando
        List<ChecklistResponseDto> result = checklistService.getAllChecklists();

        // Então
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(1L, result.get(0).getId());
        assertEquals(2L, result.get(1).getId());
        assertEquals("Rodoviário", result.get(0).getTipoInspecaoModalidade().getDescription());
        assertEquals("Não Conforme", result.get(0).getItens().get(0).getStatusConformidade().getDescription());
        assertNotNull(result.get(0).getItens().get(0).getEvidencias());
        verify(checklistRepository, times(1)).findAllWithDetails();
    }

    @Test
    void getAllChecklists_shouldReturnEmptyList_whenNoChecklistsExist() {
        // Dado
        when(checklistRepository.findAllWithDetails()).thenReturn(Collections.emptyList());

        // Quando
        List<ChecklistResponseDto> result = checklistService.getAllChecklists();

        // Então
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(checklistRepository, times(1)).findAllWithDetails();
    }

    // --- Testes para o método getChecklistById ---

    @Test
    void getChecklistById_shouldReturnChecklistWhenFound() {
        // Dado
        Long id = 1L;
        Checklist checklistEntity = createSampleChecklistEntity(id);
        when(checklistRepository.findById(id)).thenReturn(Optional.of(checklistEntity));

        // Quando
        ChecklistResponseDto result = checklistService.getChecklistById(id);

        // Então
        assertNotNull(result);
        assertEquals(id, result.getId());
        assertEquals("Rodoviário", result.getTipoInspecaoModalidade().getDescription());
        assertEquals("Pneus", result.getItens().get(0).getPontoVerificacao().getDescricao());
        assertNotNull(result.getItens().get(0).getEvidencias());
        verify(checklistRepository, times(1)).findById(id);
    }

    @Test
    void getChecklistById_shouldThrowNotFoundExceptionWhenNotFound() {
        Long id = 99L;
        when(checklistRepository.findById(id)).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.getChecklistById(id));
        assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
        assertEquals("Checklist not found with ID: " + id, exception.getReason());
        verify(checklistRepository, times(1)).findById(id);
    }

    // --- Testes para o método updateChecklist ---

    @Test
    void updateChecklist_shouldReturnUpdatedChecklist() {
        Long id = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Updated General Observations");
        updateDto.setNomeRespInspecao("Updated Inspector Name");
        updateDto.setTipoUnidadeId(302); // Baú (ID 302)

        Checklist existingChecklist = createSampleChecklistEntity(id);
        Checklist updatedEntity = createSampleChecklistEntity(id);
        updatedEntity.setObservacoesGerais("Updated General Observations");
        updatedEntity.setNomeRespInspecao("Updated Inspector Name");
        
        LookupValueData updatedTipoUnidade = new LookupValueData(302, "TIPO_UNIDADE", "Baú");
        updatedEntity.setTipoUnidade(updatedTipoUnidade);

        when(checklistRepository.findById(id)).thenReturn(Optional.of(existingChecklist));
        when(lookupValueDataRepository.findById(eq(updateDto.getTipoUnidadeId()))).thenReturn(Optional.of(updatedTipoUnidade));
        when(checklistRepository.save(any(Checklist.class))).thenReturn(updatedEntity);

        ChecklistResponseDto result = checklistService.updateChecklist(id, updateDto);

        assertNotNull(result);
        assertEquals(id, result.getId());
        assertEquals("Updated General Observations", result.getObservacoesGerais());
        assertEquals("Updated Inspector Name", result.getNomeRespInspecao());
        assertNotNull(result.getTipoUnidade());
        assertEquals("Baú", result.getTipoUnidade().getDescription());

        verify(checklistRepository, times(1)).findById(id);
        verify(checklistRepository, times(1)).save(any(Checklist.class));
        verify(lookupValueDataRepository, times(1)).findById(eq(updateDto.getTipoUnidadeId()));
    }

    @Test
    void updateChecklist_shouldThrowNotFoundException_whenChecklistToUpdateDoesNotExist() {
        Long nonExistentId = 99L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setObservacoesGerais("Test update");

        when(checklistRepository.findById(nonExistentId)).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.updateChecklist(nonExistentId, updateDto));
        assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
        assertEquals("Checklist not found with ID: " + nonExistentId, exception.getReason());
        verify(checklistRepository, times(1)).findById(nonExistentId);
        verify(checklistRepository, never()).save(any(Checklist.class));
    }

    @Test
    void updateChecklist_shouldThrowBadRequest_whenLookupNotFoundDuringUpdate() {
        Long id = 1L;
        UpdateChecklistDto updateDto = new UpdateChecklistDto();
        updateDto.setTipoInspecaoModalidadeId(999); // ID de lookup inexistente

        Checklist existingChecklist = createSampleChecklistEntity(id);

        when(checklistRepository.findById(id)).thenReturn(Optional.of(existingChecklist));
        when(lookupValueDataRepository.findById(any(Integer.class))).thenReturn(Optional.empty());

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.updateChecklist(id, updateDto));
        assertEquals(HttpStatus.BAD_REQUEST, exception.getStatusCode());
        assertTrue(exception.getReason().contains("Inspection Modality Type not found."));

        verify(checklistRepository, times(1)).findById(id);
        verify(checklistRepository, never()).save(any(Checklist.class));
    }


    // --- Testes para o método deleteChecklist ---

    @Test
    void deleteChecklist_shouldDeleteChecklistWhenFound() {
        Long id = 1L;
        when(checklistRepository.existsById(id)).thenReturn(true);

        checklistService.deleteChecklist(id);

        verify(checklistRepository, times(1)).existsById(id);
        verify(checklistRepository, times(1)).deleteById(id);
    }

    @Test
    void deleteChecklist_shouldThrowNotFoundExceptionWhenNotFound() {
        Long id = 99L;
        when(checklistRepository.existsById(id)).thenReturn(false);

        ResponseStatusException exception = assertThrows(ResponseStatusException.class, () -> checklistService.deleteChecklist(id));
        assertEquals(HttpStatus.NOT_FOUND, exception.getStatusCode());
        assertEquals("Checklist not found with ID: " + id, exception.getReason());
        verify(checklistRepository, times(1)).existsById(id);
        verify(checklistRepository, never()).deleteById(any(Long.class));
    }
}
