package com.uaga.checklist.service.impl;

import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.*;
import com.uaga.checklist.entity.*;
import com.uaga.checklist.repository.*;
import com.uaga.checklist.service.ChecklistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;
import org.hibernate.Hibernate; // Importar Hibernate para inicialização de proxy

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ChecklistServiceImpl implements ChecklistService {

    private final ChecklistRepository checklistRepository;
    private final ChecklistItemRepository checklistItemRepository;
    private final EvidenciaRepository evidenciaRepository;
    private final LacreSaidaRepository lacreSaidaRepository;
    private final PontoVerificacaoRepository pontoVerificacaoRepository;
    private final LookupValueDataRepository lookupValueDataRepository; // Repositório para a tabela única de lookup

    @Autowired
    public ChecklistServiceImpl(ChecklistRepository checklistRepository,
                                ChecklistItemRepository checklistItemRepository,
                                EvidenciaRepository evidenciaRepository,
                                LacreSaidaRepository lacreSaidaRepository,
                                PontoVerificacaoRepository pontoVerificacaoRepository,
                                LookupValueDataRepository lookupValueDataRepository) {
        this.checklistRepository = checklistRepository;
        this.checklistItemRepository = checklistItemRepository;
        this.evidenciaRepository = evidenciaRepository;
        this.lacreSaidaRepository = lacreSaidaRepository;
        this.pontoVerificacaoRepository = pontoVerificacaoRepository;
        this.lookupValueDataRepository = lookupValueDataRepository;
    }

    @Override
    @Transactional
    public ChecklistResponseDto createChecklist(CreateChecklistDto createChecklistDto) {
        Checklist checklist = new Checklist();
        checklist.setDataHoraInicio(createChecklistDto.getDataHoraInicio());
        checklist.setDataHoraTermino(createChecklistDto.getDataHoraTermino());
        checklist.setNLacreUagaPosInspecao(createChecklistDto.getNLacreUagaPosInspecao());
        checklist.setNLacreUagaPosCarregamento(createChecklistDto.getNLacreUagaPosCarregamento());
        checklist.setNomeRespLacre(createChecklistDto.getNomeRespLacre());
        checklist.setAssinaturaRespLacre(createChecklistDto.getAssinaturaRespLacre());
        checklist.setNomeRespDeslacrePosCarregamento(createChecklistDto.getNomeRespDeslacrePosCarregamento());
        checklist.setAssinaturaRespDeslacrePosCarregamento(createChecklistDto.getAssinaturaRespDeslacrePosCarregamento());
        checklist.setNLacreArmador(createChecklistDto.getNLacreArmador());
        checklist.setNLacreRfb(createChecklistDto.getNLacreRfb());
        checklist.setObservacoesGerais(createChecklistDto.getObservacoesGerais());
        checklist.setProvidenciasTomadas(createChecklistDto.getProvidenciasTomadas());
        checklist.setNomeRespInspecao(createChecklistDto.getNomeRespInspecao());
        checklist.setAssinaturaRespInspecao(createChecklistDto.getAssinaturaRespInspecao());
        checklist.setAssinaturaMotorista(createChecklistDto.getAssinaturaMotorista());

        // Usando lookupValueDataRepository para todos os lookups
        checklist.setTipoInspecaoModalidade(lookupValueDataRepository.findById(createChecklistDto.getTipoInspecaoModalidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Inspection Modality Type not found.")));
        checklist.setOperacao(lookupValueDataRepository.findById(createChecklistDto.getOperacaoId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Operation not found.")));
        checklist.setTipoUnidade(lookupValueDataRepository.findById(createChecklistDto.getTipoUnidadeId())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unit Type not found.")));

        Checklist savedChecklist = checklistRepository.save(checklist);

        if (createChecklistDto.getItens() != null && !createChecklistDto.getItens().isEmpty()) {
            List<ChecklistItem> checklistItems = createChecklistDto.getItens().stream().map(itemDto -> {
                ChecklistItem checklistItem = new ChecklistItem();
                checklistItem.setChecklist(savedChecklist);
                checklistItem.setObservacoes(itemDto.getObservacoes());

                checklistItem.setPontoVerificacao(pontoVerificacaoRepository.findById(itemDto.getPontoVerificacaoId())
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Verification Point not found.")));
                checklistItem.setStatusConformidade(lookupValueDataRepository.findById(itemDto.getStatusConformidadeId())
                        .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Compliance Status not found.")));

                ChecklistItem savedChecklistItem = checklistItemRepository.save(checklistItem);

                if (itemDto.getEvidencias() != null && !itemDto.getEvidencias().isEmpty()) {
                    List<Evidencia> evidences = itemDto.getEvidencias().stream().map(evidenciaDto -> {
                        Evidencia evidencia = new Evidencia();
                        evidencia.setChecklistItem(savedChecklistItem);
                        evidencia.setUrlImagem(evidenciaDto.getUrlImagem());
                        evidencia.setDescricao(evidenciaDto.getDescricao());
                        return evidencia;
                    }).collect(Collectors.toList());
                    evidenciaRepository.saveAll(evidences);
                }
                return savedChecklistItem;
            }).collect(Collectors.toList());
            savedChecklist.setItens(checklistItems);
        }

        if (createChecklistDto.getLacresSaida() != null) {
            LacreSaida lacreSaida = new LacreSaida();
            lacreSaida.setChecklist(savedChecklist);
            lacreSaida.setNomeRespVerificacao(createChecklistDto.getLacresSaida().getNomeRespVerificacao());
            lacreSaida.setAssinaturaRespVerificacao(createChecklistDto.getLacresSaida().getAssinaturaRespVerificacao());
            lacreSaida.setDataSaida(createChecklistDto.getLacresSaida().getDataSaida());

            lacreSaida.setLacreRfb(lookupValueDataRepository.findById(createChecklistDto.getLacresSaida().getLacreRfbId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "RFB Seal not found.")));
            lacreSaida.setLacreArmadorPosUnitizacao(lookupValueDataRepository.findById(createChecklistDto.getLacresSaida().getLacreArmadorPosUnitizacaoId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "Armador Post-Unitization Seal not found.")));
            lacreSaida.setFitaLacreUagaCompartimento(lookupValueDataRepository.findById(createChecklistDto.getLacresSaida().getFitaLacreUagaCompartimentoId())
                    .orElseThrow(() -> new ResponseStatusException(HttpStatus.BAD_REQUEST, "UAGA Compartment Seal Tape not found.")));
            
            lacreSaidaRepository.save(lacreSaida);
            savedChecklist.setLacreSaida(lacreSaida);
        }

        return mapChecklistToResponseDto(savedChecklist);
    }

    // --- Métodos restantes (ainda com UnsupportedOperationException por enquanto) ---

    @Override
    public List<ChecklistResponseDto> getAllChecklists() {
        throw new UnsupportedOperationException("Unimplemented method 'getAllChecklists'");
    }

    @Override
    public ChecklistResponseDto getChecklistById(Long id) {
        throw new UnsupportedOperationException("Unimplemented method 'getChecklistById'");
    }

    @Override
    public ChecklistResponseDto updateChecklist(Long id, UpdateChecklistDto updateChecklistDto) {
        throw new UnsupportedOperationException("Unimplemented method 'updateChecklist'");
    }

    @Override
    public void deleteChecklist(Long id) {
        throw new UnsupportedOperationException("Unimplemented method 'deleteChecklist'");
    }

    // --- Método auxiliar mapChecklistToResponseDto ---
    private ChecklistResponseDto mapChecklistToResponseDto(Checklist checklist) {
        ChecklistResponseDto dto = new ChecklistResponseDto();
        dto.setId(checklist.getId());
        dto.setDataHoraInicio(checklist.getDataHoraInicio());
        dto.setDataHoraTermino(checklist.getDataHoraTermino()); // CORREÇÃO AQUI
        dto.setNLacreUagaPosInspecao(checklist.getNLacreUagaPosInspecao());
        dto.setNLacreUagaPosCarregamento(checklist.getNLacreUagaPosCarregamento());
        dto.setNomeRespLacre(checklist.getNomeRespLacre());
        dto.setAssinaturaRespLacre(checklist.getAssinaturaRespLacre());
        dto.setNomeRespDeslacrePosCarregamento(checklist.getNomeRespDeslacrePosCarregamento());
        dto.setAssinaturaRespDeslacrePosCarregamento(checklist.getAssinaturaRespDeslacrePosCarregamento());
        dto.setNLacreArmador(checklist.getNLacreArmador());
        dto.setNLacreRfb(checklist.getNLacreRfb());
        dto.setObservacoesGerais(checklist.getObservacoesGerais());
        dto.setProvidenciasTomadas(checklist.getProvidenciasTomadas());
        dto.setNomeRespInspecao(checklist.getNomeRespInspecao());
        dto.setAssinaturaRespInspecao(checklist.getAssinaturaRespInspecao());
        dto.setAssinaturaMotorista(checklist.getAssinaturaMotorista());

        if (checklist.getTipoInspecaoModalidade() != null) {
            dto.setTipoInspecaoModalidade(new LookupValueDataResponseDto(checklist.getTipoInspecaoModalidade().getId(), checklist.getTipoInspecaoModalidade().getType(), checklist.getTipoInspecaoModalidade().getDescription()));
        }
        if (checklist.getOperacao() != null) {
            dto.setOperacao(new LookupValueDataResponseDto(checklist.getOperacao().getId(), checklist.getOperacao().getType(), checklist.getOperacao().getDescription()));
        }
        if (checklist.getTipoUnidade() != null) {
            dto.setTipoUnidade(new LookupValueDataResponseDto(checklist.getTipoUnidade().getId(), checklist.getTipoUnidade().getType(), checklist.getTipoUnidade().getDescription()));
        }

        if (checklist.getItens() != null) {
            Hibernate.initialize(checklist.getItens());
            List<ChecklistItemResponseDto> itemDtos = checklist.getItens().stream().map(item -> {
                ChecklistItemResponseDto itemDto = new ChecklistItemResponseDto();
                itemDto.setId(item.getId());
                itemDto.setObservacoes(item.getObservacoes());

                if (item.getPontoVerificacao() != null) {
                    itemDto.setPontoVerificacao(new PontoVerificacaoResponseDto(item.getPontoVerificacao().getId(), item.getPontoVerificacao().getDescricao()));
                }
                if (item.getStatusConformidade() != null) {
                    itemDto.setStatusConformidade(new LookupValueDataResponseDto(item.getStatusConformidade().getId(), item.getStatusConformidade().getType(), item.getStatusConformidade().getDescription()));
                }
                if (item.getEvidencias() != null) {
                    Hibernate.initialize(item.getEvidencias());
                    List<EvidenciaResponseDto> evidenceDtos = item.getEvidencias().stream()
                            .map(ev -> new EvidenciaResponseDto(ev.getId(), ev.getUrlImagem(), ev.getDescricao()))
                            .collect(Collectors.toList());
                    itemDto.setEvidencias(evidenceDtos);
                }
                return itemDto;
            }).collect(Collectors.toList());
            dto.setItens(itemDtos);
        }

        if (checklist.getLacreSaida() != null) {
            Hibernate.initialize(checklist.getLacreSaida());
            LacreSaidaResponseDto lacreSaidaDto = new LacreSaidaResponseDto();
            lacreSaidaDto.setId(checklist.getLacreSaida().getId());
            lacreSaidaDto.setNomeRespVerificacao(checklist.getLacreSaida().getNomeRespVerificacao());
            lacreSaidaDto.setAssinaturaRespVerificacao(checklist.getLacreSaida().getAssinaturaRespVerificacao());
            lacreSaidaDto.setDataSaida(checklist.getLacreSaida().getDataSaida());

            if (checklist.getLacreSaida().getLacreRfb() != null) {
                lacreSaidaDto.setLacreRfb(new LookupValueDataResponseDto(checklist.getLacreSaida().getLacreRfb().getId(), checklist.getLacreSaida().getLacreRfb().getType(), checklist.getLacreSaida().getLacreRfb().getDescription()));
            }
            if (checklist.getLacreSaida().getLacreArmadorPosUnitizacao() != null) {
                lacreSaidaDto.setLacreArmadorPosUnitizacao(new LookupValueDataResponseDto(checklist.getLacreSaida().getLacreArmadorPosUnitizacao().getId(), checklist.getLacreSaida().getLacreArmadorPosUnitizacao().getType(), checklist.getLacreSaida().getLacreArmadorPosUnitizacao().getDescription()));
            }
            if (checklist.getLacreSaida().getFitaLacreUagaCompartimento() != null) {
                lacreSaidaDto.setFitaLacreUagaCompartimento(new LookupValueDataResponseDto(checklist.getLacreSaida().getFitaLacreUagaCompartimento().getId(), checklist.getLacreSaida().getFitaLacreUagaCompartimento().getType(), checklist.getLacreSaida().getFitaLacreUagaCompartimento().getDescription()));
            }
            dto.setLacreSaida(lacreSaidaDto);
        }

        return dto;
    }
}
