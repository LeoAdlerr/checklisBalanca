package com.uaga.checklist.controller;

import com.uaga.checklist.dto.CreateChecklistDto;
import com.uaga.checklist.dto.UpdateChecklistDto;
import com.uaga.checklist.dto.response.ChecklistResponseDto;
import com.uaga.checklist.service.ChecklistService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/checklists")
@Tag(name = "Checklists", description = "Operações relacionadas ao gerenciamento de Checklists")
public class ChecklistController {

    private final ChecklistService checklistService;

    @Autowired
    public ChecklistController(ChecklistService checklistService) {
        this.checklistService = checklistService;
    }

    @PostMapping
    @Operation(summary = "Cria um novo checklist completo",
               description = "Cria um novo Checklist incluindo todos os seus itens, evidências e informações de lacre de saída.")
    @ApiResponse(responseCode = "201", description = "Checklist criado com sucesso",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    @ApiResponse(responseCode = "400", description = "Dados de requisição inválidos",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<ChecklistResponseDto> createChecklist(@Valid @RequestBody CreateChecklistDto createChecklistDto) {
        // 1. Chama o método do serviço para criar o checklist.
        ChecklistResponseDto createdChecklist = checklistService.createChecklist(createChecklistDto);

        // 2. Retorna a resposta do serviço com o status HTTP 201 (Created).
        return new ResponseEntity<>(createdChecklist, HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Recupera todos os Checklists",
               description = "Retorna uma lista de todos os Checklists com seus detalhes associados.")
    @ApiResponse(responseCode = "200", description = "Lista de checklists recuperada com sucesso",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    public ResponseEntity<List<ChecklistResponseDto>> getAllChecklists() {
        // Implementação inicial para TDD
        throw new UnsupportedOperationException("Unimplemented method 'getAllChecklists' in controller");
    }

    @GetMapping("/{id}")
    @Operation(summary = "Recupera um Checklist específico por ID",
               description = "Retorna um único Checklist com base em seu identificador único.")
    @Parameter(name = "id", description = "ID do Checklist a ser recuperado", required = true, schema = @Schema(type = "long"))
    @ApiResponse(responseCode = "200", description = "Checklist recuperado com sucesso",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    @ApiResponse(responseCode = "404", description = "Checklist não encontrado",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<ChecklistResponseDto> getChecklistById(@PathVariable Long id) {
        // Implementação inicial para TDD
        throw new UnsupportedOperationException("Unimplemented method 'getChecklistById' in controller");
    }

    @PutMapping("/{id}")
    @Operation(summary = "Atualiza um Checklist existente",
               description = "Atualiza os campos de um Checklist existente identificado por seu ID.")
    @Parameter(name = "id", description = "ID do Checklist a ser atualizado", required = true, schema = @Schema(type = "long"))
    @ApiResponse(responseCode = "200", description = "Checklist atualizado com sucesso",
                 content = @Content(mediaType = "application/json", schema = @Schema(implementation = ChecklistResponseDto.class)))
    @ApiResponse(responseCode = "400", description = "Dados de requisição inválidos",
                 content = @Content(mediaType = "application/json"))
    @ApiResponse(responseCode = "404", description = "Checklist não encontrado",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<ChecklistResponseDto> updateChecklist(@PathVariable Long id, @Valid @RequestBody UpdateChecklistDto updateChecklistDto) {
        // Implementação inicial para TDD
        throw new UnsupportedOperationException("Unimplemented method 'updateChecklist' in controller");
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Exclui um Checklist por ID",
               description = "Exclui um Checklist existente e todas as suas informações associadas.")
    @Parameter(name = "id", description = "ID do Checklist a ser excluído", required = true, schema = @Schema(type = "long"))
    @ApiResponse(responseCode = "204", description = "Checklist excluído com sucesso (Sem Conteúdo)")
    @ApiResponse(responseCode = "404", description = "Checklist não encontrado",
                 content = @Content(mediaType = "application/json"))
    public ResponseEntity<Void> deleteChecklist(@PathVariable Long id) {
        // Implementação inicial para TDD
        throw new UnsupportedOperationException("Unimplemented method 'deleteChecklist' in controller");
    }
}