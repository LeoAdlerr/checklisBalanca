import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ChecklistController } from './controllers/checklist.controller';

// Importe a CLASSE ABSTRATA e a IMPLEMENTAÇÃO
import { ChecklistService } from './services/checklist.service.abstract';
import { ChecklistServiceImpl } from './services/checklist.service';

// Importe as entidades que este módulo irá manipular
import { Checklist } from '../entities/checklist.entity';
import { ChecklistItem } from '../entities/checklist-item.entity';
import { LacreSaida } from '../entities/lacre-saida.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([Checklist, ChecklistItem, LacreSaida]) 
  ],
  controllers: [ChecklistController],
  providers: [
    // AQUI ESTÁ A CONFIGURAÇÃO DA INVERSÃO DE DEPENDÊNCIA
    {
      provide: ChecklistService, // QUANDO ALGUÉM PEDIR por 'ChecklistService' (a abstração)...
      useClass: ChecklistServiceImpl, // ...entregue uma instância de 'ChecklistServiceImpl' (a implementação).
    },
  ],
})
export class ChecklistModule {}