import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsDateString, IsInt, IsNotEmpty, IsOptional, IsString, ValidateNested } from 'class-validator';

// DTO Principal para a criação de um checklist completo
export class CreateChecklistDto {
  // --- Seção 1: Informações Iniciais ---
  @ApiProperty({ description: 'Data e hora de início da inspeção.'})
  @IsDateString()
  dataHoraInicio: string;

  @ApiProperty({ description: 'ID do Tipo da Inspeção por Modalidade (da tabela lookup_value_data).', example: 101 })
  @IsInt()
  tipoInspecaoModalidadeId: number;

  @ApiProperty({ description: 'ID da Operação (da tabela lookup_value_data).', example: 203 })
  @IsInt()
  operacaoId: number;

  @ApiProperty({ description: 'ID do Tipo de Unidade (da tabela lookup_value_data).', example: 301 })
  @IsInt()
  tipoUnidadeId: number;
  
  @ApiProperty({ description: 'Nome do responsável pela inspeção.' })
  @IsString()
  @IsNotEmpty()
  nomeRespInspecao: string;

  @ApiProperty({ description: 'Assinatura (em base64 ou URL) do responsável pela inspeção.' })
  @IsString()
  @IsNotEmpty()
  assinaturaRespInspecao: string;

  // --- Seção 2: Itens Verificados ---
  @ApiProperty({ type: () => [ChecklistItemDto], description: 'A lista dos 18 pontos verificados.' })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ChecklistItemDto)
  itens: ChecklistItemDto[];
  
  // --- Seção 3: Informações Finais (opcionais no momento da criação inicial) ---
  @ApiProperty({ required: false })
  @IsDateString()
  @IsOptional()
  dataHoraTermino?: string;
  
  @ApiProperty({ required: false }) @IsString() @IsOptional()
  nLacreUagaPosInspecao?: string;

  @ApiProperty({ required: false }) @IsString() @IsOptional()
  nLacreUagaPosCarregamento?: string;

  @ApiProperty({ required: false }) @IsString() @IsOptional()
  nomeRespLacre?: string;

  @ApiProperty({ required: false }) @IsString() @IsOptional()
  assinaturaRespLacre?: string;

  @ApiProperty({ required: false }) @IsString() @IsOptional()
  nomeRespDeslacrePosCarregamento?: string;
  
  @ApiProperty({ required: false }) @IsString() @IsOptional()
  assinaturaRespDeslacrePosCarregamento?: string;
  
  @ApiProperty({ required: false }) @IsString() @IsOptional()
  nLacreArmador?: string;
  
  @ApiProperty({ required: false }) @IsString() @IsOptional()
  nLacreRfb?: string;

  // --- Seção 4: Verificação de Saída (pode ser adicionada depois, por isso opcional) ---
  @ApiProperty({ type: () => LacreSaidaDto, required: false })
  @ValidateNested()
  @Type(() => LacreSaidaDto)
  @IsOptional()
  lacreSaida?: LacreSaidaDto;

  // --- Seção 5: Campos Adicionais ---
  @ApiProperty({ required: false }) @IsString() @IsOptional()
  observacoesGerais?: string;

  @ApiProperty({ required: false }) @IsString() @IsOptional()
  providenciasTomadas?: string;

  @ApiProperty({ required: false }) @IsString() @IsOptional()
  assinaturaMotorista?: string;
}