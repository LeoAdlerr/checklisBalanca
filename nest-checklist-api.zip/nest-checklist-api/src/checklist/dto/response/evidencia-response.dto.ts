import { ApiProperty } from '@nestjs/swagger';

export class EvidenciaResponseDto {
    @ApiProperty() id: number;
    @ApiProperty() urlImagem: string;
    @ApiProperty() descricao: string;
}