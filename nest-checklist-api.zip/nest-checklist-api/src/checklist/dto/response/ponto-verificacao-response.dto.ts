import { ApiProperty } from '@nestjs/swagger';

export class PontoVerificacaoResponseDto {
    @ApiProperty() id: number;
    @ApiProperty() descricao: string;
}