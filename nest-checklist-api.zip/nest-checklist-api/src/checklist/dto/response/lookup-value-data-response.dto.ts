import { ApiProperty } from '@nestjs/swagger';

export class LookupValueDataResponseDto {
    @ApiProperty() id: number;
    @ApiProperty() description: string;
}
