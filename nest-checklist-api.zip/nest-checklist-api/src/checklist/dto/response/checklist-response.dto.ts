import { ApiProperty } from '@nestjs/swagger';
import { Checklist } from '../../../entities/checklist.entity';

// Vamos criar um DTO de resposta para ter controle sobre os dados que saem da API.
// No futuro, podemos mapear a entidade para este DTO para ocultar ou transformar campos.
export class ChecklistResponseDto extends Checklist {}
