import { ApiProperty } from '@nestjs/swagger';

export class ChecklistItemResponseDto {
    @ApiProperty() id: number;
    @ApiProperty() observacoes: string;
    @ApiProperty({ type: PontoVerificacaoResponseDto }) pontoVerificacao: PontoVerificacaoResponseDto;
    @ApiProperty({ type: LookupValueDataResponseDto }) statusConformidade: LookupValueDataResponseDto;
    @ApiProperty({ type: [EvidenciaResponseDto] }) evidencias: EvidenciaResponseDto[];
}