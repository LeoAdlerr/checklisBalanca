import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsDateString, IsInt, IsNotEmpty, IsOptional, IsString, ValidateNested } from 'class-validator';


export class EvidenciaDto {
  @ApiProperty({ description: 'URL da imagem salva.', example: 'https://storage.googleapis.com/bucket-name/imagem123.jpg' })
  @IsString()
  @IsNotEmpty()
  urlImagem: string;

  @ApiProperty({ description: 'Descrição da evidência.', example: 'Lacre rompido.', required: false })
  @IsString()
  @IsOptional()
  descricao?: string;
}