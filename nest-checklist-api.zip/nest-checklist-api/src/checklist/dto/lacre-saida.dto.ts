import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsDateString, IsInt, IsNotEmpty, IsOptional, IsString, ValidateNested } from 'class-validator';


export class LacreSaidaDto {
    @ApiProperty({ description: 'ID do status do Lacre RFB (da tabela lookup_value_data).', example: 2 })
    @IsInt()
    lacreRfbId: number;

    @ApiProperty({ description: 'ID do status do Lacre Armador (da tabela lookup_value_data).', example: 1 })
    @IsInt()
    lacreArmadorPosUnitizacaoId: number;

    @ApiProperty({ description: 'ID do status da Fita Lacre UAGA (da tabela lookup_value_data).', example: 2 })
    @IsInt()
    fitaLacreUagaCompartimentoId: number;

    @ApiProperty({ description: 'Nome do responsável pela verificação de saída.' })
    @IsString()
    @IsNotEmpty()
    nomeRespVerificacao: string;

    @ApiProperty({ description: 'Assinatura (em base64 ou URL) do responsável pela verificação.' })
    @IsString()
    @IsNotEmpty()
    assinaturaRespVerificacao: string;

    @ApiProperty({ description: 'Data da saída do veículo.', example: '2024-10-28' })
    @IsDateString()
    dataSaida: string;
}