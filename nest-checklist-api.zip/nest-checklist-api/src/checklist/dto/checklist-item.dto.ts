import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { IsArray, IsDateString, IsInt, IsNotEmpty, IsOptional, IsString, ValidateNested } from 'class-validator';

export class ChecklistItemDto {
  @ApiProperty({ description: 'ID do ponto de verificação (da tabela pontos_verificacao).', example: 7 })
  @IsInt()
  pontoVerificacaoId: number;

  @ApiProperty({ description: 'ID do status de conformidade (da tabela lookup_value_data).', example: 402 })
  @IsInt()
  statusConformidadeId: number;
  
  @ApiProperty({ description: 'Observações sobre o item, especialmente se não conforme.', example: 'Piso com avarias.', required: false })
  @IsString()
  @IsOptional()
  observacoes?: string;

  @ApiProperty({ type: () => [EvidenciaDto], description: 'Lista de evidências para este item.', required: false })
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => EvidenciaDto)
  @IsOptional()
  evidencias?: EvidenciaDto[];
}