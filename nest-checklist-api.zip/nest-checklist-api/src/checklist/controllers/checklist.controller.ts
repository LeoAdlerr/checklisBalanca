import { Controller, Get, Post, Body, Param, ParseIntPipe, Delete, Put, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse } from '@nestjs/swagger';
import { ChecklistService } from '../services/checklist.service.abstract'; // Dependa da abstração!
import { CreateChecklistDto } from '../dto/create-checklist.dto';
import { ChecklistResponseDto } from '../dto/response/checklist-response.dto';
import { UpdateChecklistDto } from '../dto/update-checklist.dto';

@ApiTags('Checklist Alfandegário')
@Controller('checklists')
export class ChecklistController {
  // O construtor pede pela classe abstrata. O NestJS, graças à configuração no
  // módulo, saberá que deve injetar uma instância da ChecklistServiceImpl.
  constructor(private readonly checklistService: ChecklistService) {}

  @Post()
  @ApiOperation({ summary: 'Criar um novo checklist' })
  @ApiResponse({ status: 201, description: 'Checklist criado com sucesso.', type: ChecklistResponseDto })
  create(@Body() createChecklistDto: CreateChecklistDto): Promise<ChecklistResponseDto> {
    return this.checklistService.createChecklist(createChecklistDto);
  }

  @Get()
  @ApiOperation({ summary: 'Listar todos os checklists' })
  getAll(): Promise<ChecklistResponseDto[]> {
    return this.checklistService.getAllChecklists();
  }

  @Get(':id')
  @ApiOperation({ summary: 'Buscar um checklist pelo ID' })
  getById(@Param('id', ParseIntPipe) id: number): Promise<ChecklistResponseDto> {
    return this.checklistService.getChecklistById(id);
  }

  @Put(':id')
  @ApiOperation({ summary: 'Atualizar um checklist existente' })
  update(@Param('id', ParseIntPipe) id: number, @Body() updateDto: UpdateChecklistDto): Promise<ChecklistResponseDto> {
    return this.checklistService.updateChecklist(id, updateDto);
  }

  @Delete(':id')
  @HttpCode(HttpStatus.NO_CONTENT)
  @ApiOperation({ summary: 'Deletar um checklist' })
  delete(@Param('id', ParseIntPipe) id: number): Promise<void> {
    return this.checklistService.deleteChecklist(id);
  }
}