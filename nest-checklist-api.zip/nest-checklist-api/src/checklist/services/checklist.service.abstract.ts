import { ChecklistResponseDto } from '../dto/response/checklist-response.dto';
import { CreateChecklistDto } from '../dto/create-checklist.dto';
import { UpdateChecklistDto } from '../dto/update-checklist.dto';

export abstract class ChecklistService {
  abstract createChecklist(createChecklistDto: CreateChecklistDto): Promise<ChecklistResponseDto>;
  abstract getAllChecklists(): Promise<ChecklistResponseDto[]>;
  abstract getChecklistById(id: number): Promise<ChecklistResponseDto>;
  abstract updateChecklist(id: number, updateChecklistDto: UpdateChecklistDto): Promise<ChecklistResponseDto>;
  abstract deleteChecklist(id: number): Promise<void>;
}