import { Injectable, Logger, NotFoundException, BadRequestException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DataSource, Repository } from 'typeorm';
import { Checklist } from '../../../entities/checklist.entity';
import { ChecklistItem } from '../../../entities/checklist-item.entity';
import { Evidencia } from '../../../entities/evidencia.entity';
import { LacreSaida } from '../../../entities/lacre-saida.entity';
import { LookupValueData } from '../../../entities/lookup-value-data.entity';
import { PontoVerificacao } from '../../../entities/ponto-verificacao.entity';
import { CreateChecklistDto } from '../dto/create-checklist.dto';
import { UpdateChecklistDto } from '../dto/update-checklist.dto';
import { ChecklistResponseDto } from '../dto/response/checklist-response.dto';

@Injectable()
export class ChecklistServiceImpl extends ChecklistService {
  private readonly logger = new Logger(ChecklistServiceImpl.name);

  // Injetamos o DataSource para controlar as transações, e todos os repositórios necessários.
  constructor(
    private readonly dataSource: DataSource,
    @InjectRepository(Checklist) private readonly checklistRepository: Repository<Checklist>,
    @InjectRepository(ChecklistItem) private readonly checklistItemRepository: Repository<ChecklistItem>,
    @InjectRepository(Evidencia) private readonly evidenciaRepository: Repository<Evidencia>,
    @InjectRepository(LacreSaida) private readonly lacreSaidaRepository: Repository<LacreSaida>,
    @InjectRepository(PontoVerificacao) private readonly pontoVerificacaoRepository: Repository<PontoVerificacao>,
    @InjectRepository(LookupValueData) private readonly lookupRepository: Repository<LookupValueData>,
  ) {
    super();
  }

  /**
   * Cria um checklist completo, incluindo seus itens e evidências, dentro de uma única transação de banco de dados.
   * Equivalente ao seu método createChecklist com @Transactional.
   */
  async createChecklist(createChecklistDto: CreateChecklistDto): Promise<ChecklistResponseDto> {
    this.logger.log('Iniciando processo de criação de checklist transacional...');
    
    // O QueryRunner nos permite executar múltiplas operações em uma única transação.
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // 1. Criar e salvar a entidade Checklist principal
      const checklistEntity = queryRunner.manager.create(Checklist, {
        ...createChecklistDto,
        dataHoraInicio: new Date(createChecklistDto.dataHoraInicio),
        // Mapeia os IDs para objetos de relacionamento que o TypeORM entende
        tipoInspecaoModalidade: { id: createChecklistDto.tipoInspecaoModalidadeId },
        operacao: { id: createChecklistDto.operacaoId },
        tipoUnidade: { id: createChecklistDto.tipoUnidadeId },
      });
      const savedChecklist = await queryRunner.manager.save(checklistEntity);

      // 2. Criar e salvar os ChecklistItems e suas Evidencias
      if (createChecklistDto.itens && createChecklistDto.itens.length > 0) {
        for (const itemDto of createChecklistDto.itens) {
          const itemEntity = queryRunner.manager.create(ChecklistItem, {
            checklist: savedChecklist,
            observacoes: itemDto.observacoes,
            pontoVerificacao: { id: itemDto.pontoVerificacaoId },
            statusConformidade: { id: itemDto.statusConformidadeId },
          });
          const savedItem = await queryRunner.manager.save(itemEntity);

          if (itemDto.evidencias && itemDto.evidencias.length > 0) {
            const evidencias = itemDto.evidencias.map(evDto => 
              queryRunner.manager.create(Evidencia, {
                ...evDto,
                checklistItem: savedItem,
              })
            );
            await queryRunner.manager.save(evidencias);
          }
        }
      }

      // 3. (Opcional) Criar e salvar o Lacre de Saída
      if (createChecklistDto.lacreSaida) {
        const lacreEntity = queryRunner.manager.create(LacreSaida, {
            ...createChecklistDto.lacreSaida,
            checklist: savedChecklist,
            dataSaida: new Date(createChecklistDto.lacreSaida.dataSaida),
            lacreRfb: { id: createChecklistDto.lacreSaida.lacreRfbId },
            lacreArmadorPosUnitizacao: { id: createChecklistDto.lacreSaida.lacreArmadorPosUnitizacaoId },
            fitaLacreUagaCompartimento: { id: createChecklistDto.lacreSaida.fitaLacreUagaCompartimentoId },
        });
        await queryRunner.manager.save(lacreEntity);
      }

      // Se tudo correu bem, 'comita' a transação.
      await queryRunner.commitTransaction();
      this.logger.log(`Checklist ${savedChecklist.id} e suas relações foram salvos com sucesso.`);

      // Retorna o checklist completo para o cliente
      return this.getChecklistById(savedChecklist.id);

    } catch (err) {
      // Se qualquer erro ocorrer, desfaz todas as operações.
      this.logger.error(`Falha ao criar checklist. Desfazendo a transação. Erro: ${err.message}`, err.stack);
      await queryRunner.rollbackTransaction();
      throw new BadRequestException(`Erro ao criar o checklist: ${err.message}`);
    } finally {
      // Libera o queryRunner para o pool de conexões.
      await queryRunner.release();
    }
  }

  async getAllChecklists(): Promise<ChecklistResponseDto[]> {
    this.logger.log('Buscando todos os checklists.');
    const checklists = await this.checklistRepository.find({
        relations: ['tipoInspecaoModalidade', 'operacao', 'tipoUnidade'] // Carrega relações básicas para a lista
    });
    // Aqui um mapeador (como o AutoMapper.js) seria ideal, mas faremos manualmente por enquanto.
    return checklists.map(c => this.mapEntityToResponseDto(c)); 
  }

  async getChecklistById(id: number): Promise<ChecklistResponseDto> {
    this.logger.log(`Buscando checklist completo com ID: ${id}`);
    const checklist = await this.checklistRepository.findOne({
      where: { id },
      // Carrega todas as relações necessárias para a resposta completa
      relations: [
        'tipoInspecaoModalidade', 'operacao', 'tipoUnidade',
        'itens', 'itens.pontoVerificacao', 'itens.statusConformidade',
        'itens.evidencias', 'lacreSaida'
      ],
    });

    if (!checklist) {
      this.logger.warn(`Checklist com ID ${id} não encontrado.`);
      throw new NotFoundException(`Checklist com ID ${id} não encontrado.`);
    }
    return this.mapEntityToResponseDto(checklist);
  }

  async updateChecklist(id: number, updateChecklistDto: UpdateChecklistDto): Promise<ChecklistResponseDto> {
    // A lógica de atualização pode ser bem complexa, especialmente com relações aninhadas.
    // O uso do QueryRunner em uma transação também é recomendado aqui.
    // Por simplicidade, vamos usar o método `save` que também pode atualizar.
    const checklist = await this.checklistRepository.findOneBy({id});
    if (!checklist) {
      throw new NotFoundException(`Checklist com ID ${id} não encontrado.`);
    }

    // REGRA DE NEGÓCIO: Validação para finalização
    if (updateChecklistDto.dataHoraTermino && !checklist.dataHoraTermino) {
        const totalPontos = await this.pontoVerificacaoRepository.count();
        if(checklist.itens.length < totalPontos) {
            throw new BadRequestException(`Não é possível finalizar: Todos os ${totalPontos} pontos de verificação devem ser preenchidos.`);
        }
    }
    
    // O TypeORM é inteligente o suficiente para atualizar a entidade e suas relações em cascata se configurado.
    const updatedChecklist = await this.checklistRepository.save({
        ...checklist, // Pega o estado atual
        ...updateChecklistDto, // Sobrescreve com os novos dados
    });

    return this.getChecklistById(updatedChecklist.id);
  }

  async deleteChecklist(id: number): Promise<void> {
    this.logger.log(`Verificando para deletar checklist com ID: ${id}`);
    const checklist = await this.checklistRepository.findOneBy({ id });

    if (!checklist) {
      throw new NotFoundException(`Checklist com ID ${id} não encontrado.`);
    }

    // REGRA DE NEGÓCIO: Não permitir exclusão de checklist finalizado.
    if (checklist.dataHoraTermino) {
        throw new BadRequestException("Checklists finalizados não podem ser excluídos.");
    }
    
    await this.checklistRepository.delete(id);
    this.logger.log(`Checklist com ID ${id} deletado com sucesso.`);
  }

  /**
   * Mapeia a entidade Checklist completa para um DTO de resposta limpo.
   */
  private mapEntityToResponseDto(checklist: Checklist): ChecklistResponseDto {
    // Este método é o equivalente direto do seu mapChecklistToResponseDto
    // Ele garante que apenas os dados necessários sejam expostos pela API.
    return {
      id: checklist.id,
      dataHoraInicio: checklist.dataHoraInicio,
      dataHoraTermino: checklist.dataHoraTermino,
      tipoInspecaoModalidade: checklist.tipoInspecaoModalidade,
      operacao: checklist.operacao,
      tipoUnidade: checklist.tipoUnidade,
      itens: checklist.itens?.map(item => ({
        id: item.id,
        observacoes: item.observacoes,
        pontoVerificacao: item.pontoVerificacao,
        statusConformidade: item.statusConformidade,
        evidencias: item.evidencias,
      })) || [],
    };
  }
}