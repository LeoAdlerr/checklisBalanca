import { Controller } from '@nestjs/common';

@Controller('checklist')
export class ChecklistController {}
