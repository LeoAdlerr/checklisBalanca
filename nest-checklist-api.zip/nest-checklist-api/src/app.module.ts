import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ChecklistModule } from './checklist/checklist.module';

// Importe os arquivos de configuração
import appConfig from './config/app.config';
import databaseConfig from './config/database.config';

// Importe TODAS as suas entidades
import { Checklist } from './entities/checklist.entity';
import { ChecklistItem } from './entities/checklist-item.entity';
import { Evidencia } from './entities/evidencia.entity';
import { LacreSaida } from './entities/lacre-saida.entity';
import { LookupValueData } from './entities/lookup-value-data.entity';
import { PontoVerificacao } from './entities/ponto-verificacao.entity';

@Module({
  imports: [
    // 1. Carrega os arquivos de configuração e o .env
    ConfigModule.forRoot({
      isGlobal: true, // Torna o ConfigModule disponível globalmente
      load: [appConfig, databaseConfig], // Carrega nossas configurações tipadas
    }),
    
    // 2. Configura o TypeORM de forma assíncrona, injetando o serviço de config
    TypeOrmModule.forRootAsync({
      imports: [ConfigModule], // Importa o ConfigModule para poder injetar o ConfigService
      inject: [ConfigService], // Injeta o ConfigService
      useFactory: (configService: ConfigService) => ({
        type: 'mysql',
        host: configService.get<string>('database.host'),
        port: configService.get<number>('database.port'),
        username: configService.get<string>('database.username'),
        password: configService.get<string>('database.password'),
        database: configService.get<string>('database.database'),
        entities: [
            Checklist,
            ChecklistItem,
            Evidencia,
            LacreSaida,
            LookupValueData,
            PontoVerificacao,
        ],
        synchronize: configService.get<boolean>('database.synchronize'),
      }),
    }),
    
    ChecklistModule,
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}