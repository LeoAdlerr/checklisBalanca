import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { ValidationPipe } from '@nestjs/common';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import { ConfigService } from '@nestjs/config'; // Importe o ConfigService

async function bootstrap() {
  const app = await NestFactory.create(AppModule);
  
  // Obtenha a instância do ConfigService a partir da aplicação
  const configService = app.get(ConfigService);
  const port = configService.get<number>('app.port'); // Obtenha a porta do nosso arquivo de config

  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,
    forbidNonWhitelisted: true,
    transform: true,
  }));

  const config = new DocumentBuilder()
    .setTitle('Checklist Alfandegário API')
    .setDescription('API para o sistema de checklist 8/18')
    .setVersion('1.0')
    .addTag('Checklist Alfandegário')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api-docs', app, document);

  await app.listen(port); // Use a porta configurada
  console.log(`Application is running on: http://localhost:${port}`);
  console.log(`Swagger UI is available on: http://localhost:${port}/api-docs`);
}
bootstrap();
