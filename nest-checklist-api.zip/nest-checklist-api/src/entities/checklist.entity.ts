import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany, OneToOne } from 'typeorm';
import { LookupValueData } from './lookup-value-data.entity';
import { ChecklistItem } from './checklist-item.entity';
import { LacreSaida } from './lacre-saida.entity';

@Entity('checklists')
export class Checklist {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  id: number;

  @Column({ type: 'datetime', name: 'data_hora_inicio', nullable: false })
  dataHoraInicio: Date;

  @Column({ type: 'datetime', name: 'data_hora_termino', nullable: true })
  dataHoraTermino: Date;

  @Column({ name: 'n_lacre_uaga_pos_inspecao', length: 255, nullable: true })
  nLacreUagaPosInspecao: string;

  @Column({ name: 'n_lacre_uaga_pos_carregamento', length: 255, nullable: true })
  nLacreUagaPosCarregamento: string;
  
  // ... resto das colunas diretas ...
  @Column({ name: 'nome_resp_lacre', length: 255, nullable: true })
  nomeRespLacre: string;

  @Column({ type: 'text', name: 'assinatura_resp_lacre', nullable: true })
  assinaturaRespLacre: string;

  @Column({ name: 'nome_resp_deslacre_pos_carregamento', length: 255, nullable: true })
  nomeRespDeslacrePosCarregamento: string;
  
  @Column({ type: 'text', name: 'assinatura_resp_deslacre_pos_carregamento', nullable: true })
  assinaturaRespDeslacrePosCarregamento: string;

  @Column({ name: 'n_lacre_armador', length: 255, nullable: true })
  nLacreArmador: string;

  @Column({ name: 'n_lacre_rfb', length: 255, nullable: true })
  nLacreRfb: string;

  @Column({ type: 'text', name: 'observacoes_gerais', nullable: true })
  observacoesGerais: string;

  @Column({ type: 'text', name: 'providencias_tomadas', nullable: true })
  providenciasTomadas: string;

  @Column({ name: 'nome_resp_inspecao', length: 255, nullable: false })
  nomeRespInspecao: string;
  
  @Column({ type: 'text', name: 'assinatura_resp_inspecao', nullable: false })
  assinaturaRespInspecao: string;

  @Column({ type: 'text', name: 'assinatura_motorista', nullable: true })
  assinaturaMotorista: string;

  // --- Relacionamentos ManyToOne com a tabela de Lookup ---
  @ManyToOne(() => LookupValueData, { eager: true }) // eager: true carrega o objeto junto, como no seu JPA.
  @JoinColumn({ name: 'tipo_inspecao_modalidade_id' })
  tipoInspecaoModalidade: LookupValueData;

  @ManyToOne(() => LookupValueData, { eager: true })
  @JoinColumn({ name: 'operacao_id' })
  operacao: LookupValueData;
  
  @ManyToOne(() => LookupValueData, { eager: true })
  @JoinColumn({ name: 'tipo_unidade_id' })
  tipoUnidade: LookupValueData;

  // --- Relacionamentos com tabelas filhas ---
  @OneToMany(() => ChecklistItem, (item) => item.checklist, { cascade: true })
  itens: ChecklistItem[];

  @OneToOne(() => LacreSaida, (lacre) => lacre.checklist, { cascade: true })
  lacreSaida: LacreSaida;
}