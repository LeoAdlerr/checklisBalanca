import { Entity, PrimaryColumn, Column } from 'typeorm';

@Entity('lookup_value_data')
export class LookupValueData {
  @PrimaryColumn('int') // Chave primária, mas não é auto-incrementada, pois os valores são fixos (DML).
  id: number;

  @Column({ type: 'varchar', length: 50, nullable: false })
  type: string;

  @Column({ type: 'varchar', length: 255, nullable: false })
  description: string;
}