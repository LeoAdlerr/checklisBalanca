import { Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn, ManyToOne } from 'typeorm';
import { Checklist } from './checklist.entity'; // Já importado acima
import { LookupValueData } from './lookup-value-data.entity'; // Já importado acima

@Entity('lacres_saida')
export class LacreSaida {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    id: number;

    @Column({ type: 'date', name: 'data_saida', nullable: false })
    dataSaida: Date;

    @Column({ name: 'nome_resp_verificacao', length: 255, nullable: false })
    nomeRespVerificacao: string;

    @Column({ type: 'text', name: 'assinatura_resp_verificacao', nullable: false })
    assinaturaRespVerificacao: string;

    // --- Relacionamento OneToOne com Checklist (lado "dono" da relação) ---
    @OneToOne(() => Checklist, { onDelete: 'CASCADE', nullable: false })
    @JoinColumn({ name: 'checklist_id' })
    checklist: Checklist;
    
    // --- Relacionamentos com a tabela de Lookup ---
    @ManyToOne(() => LookupValueData, { eager: true, nullable: false })
    @JoinColumn({ name: 'lacre_rfb_id' })
    lacreRfb: LookupValueData;

    @ManyToOne(() => LookupValueData, { eager: true, nullable: false })
    @JoinColumn({ name: 'lacre_armador_pos_unitizacao_id' })
    lacreArmadorPosUnitizacao: LookupValueData;

    @ManyToOne(() => LookupValueData, { eager: true, nullable: false })
    @JoinColumn({ name: 'fita_lacre_uaga_compartimento_id' })
    fitaLacreUagaCompartimento: LookupValueData;
}