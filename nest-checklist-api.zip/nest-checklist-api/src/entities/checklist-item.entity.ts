import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, OneToMany } from 'typeorm';
import { Checklist } from './checklist.entity'; // Já importado acima
import { PontoVerificacao } from './ponto-verificacao.entity'; // Já importado acima
import { LookupValueData } from './lookup-value-data.entity'; // Já importado acima
import { Evidencia } from './evidencia.entity';

@Entity('checklist_itens')
export class ChecklistItem {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    id: number;

    @Column({ type: 'text', nullable: true })
    observacoes: string;
    
    // --- Relacionamentos ---
    @ManyToOne(() => Checklist, (checklist) => checklist.itens, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'checklist_id' })
    checklist: Checklist;

    @ManyToOne(() => PontoVerificacao, { eager: true, nullable: false })
    @JoinColumn({ name: 'ponto_verificacao_id' })
    pontoVerificacao: PontoVerificacao;

    @ManyToOne(() => LookupValueData, { eager: true, nullable: false })
    @JoinColumn({ name: 'status_conformidade_id' })
    statusConformidade: LookupValueData;
    
    @OneToMany(() => Evidencia, (evidencia) => evidencia.checklistItem, { cascade: true })
    evidencias: Evidencia[];
}