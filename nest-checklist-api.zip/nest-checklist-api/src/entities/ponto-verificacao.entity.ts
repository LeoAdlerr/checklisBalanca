import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('pontos_verificacao')
export class PontoVerificacao {
  @PrimaryGeneratedColumn('increment') // Usa a estratégia 'increment' para INT AUTO_INCREMENT.
  id: number;

  @Column({ type: 'varchar', length: 255, unique: true, nullable: false })
  descricao: string;
}