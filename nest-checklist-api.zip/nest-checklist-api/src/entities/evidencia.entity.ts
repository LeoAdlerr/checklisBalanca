import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn } from 'typeorm';
import { ChecklistItem } from './checklist-item.entity'; // Já importado acima

@Entity('evidencias')
export class Evidencia {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    id: number;

    @Column({ name: 'url_imagem', length: 255, nullable: false })
    urlImagem: string;

    @Column({ type: 'text', nullable: true })
    descricao: string;

    @ManyToOne(() => ChecklistItem, (item) => item.evidencias, { onDelete: 'CASCADE' })
    @JoinColumn({ name: 'checklist_item_id' })
    checklistItem: ChecklistItem;
}